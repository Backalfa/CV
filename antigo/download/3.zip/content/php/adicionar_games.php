<!-- Save adicionar sem imagem -->

<?php

require('conecçao.php');

// Verifica se o formulário foi submetido
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Realize as validações e processamento dos dados enviados pelo formulário
    // ...

    // Após processar os dados, você pode inserir o novo produto no banco de dados
    // Substitua as variáveis $conn pelas suas próprias configurações de conexão

    $nome = $_POST['nome'];
    $url = $_POST['url'];

    // Consulta SQL para verificar se já existe um produto com a mesma referência
    $checkQuery = "SELECT nome FROM games WHERE nome = '$nome'";
    $checkResult = $conn->query($checkQuery);

    if ($checkResult->num_rows > 0) {
        // Já existe um produto com a mesma referência
        echo "Já existe um produto com essa referência.";
    } else {
        // Verifica se uma imagem foi enviada
        if (isset($_FILES['imagem']) && $_FILES['imagem']['error'] === UPLOAD_ERR_OK) {
            // Obtém informações sobre a imagem enviada
            $imagem = $_FILES['imagem'];
            $imagemNome = $imagem['name'];
            $imagemTipo = $imagem['type'];
            $imagemTamanho = $imagem['size'];
            $imagemTmpName = $imagem['tmp_name'];

            // Lê o conteúdo da imagem em bytes
            $imagemConteudo = file_get_contents($imagemTmpName);

            // Escapa os caracteres especiais para evitar problemas de SQL Injection
            $nome = $conn->real_escape_string($nome);
            $url = $conn->real_escape_string($url);
            $imagemConteudo = $conn->real_escape_string($imagemConteudo);

            // Consulta SQL para inserir o novo produto na tabela, incluindo a imagem
            $sql = "INSERT INTO games (nome, url, imagem)
                    VALUES ('$nome', '$url', '$imagemConteudo')";

            // Executa a consulta SQL
            if ($conn->query($sql) === TRUE) {
                // O produto foi inserido com sucesso na tabela temporária
                echo "Game added successfully.";
            } else {
                // Ocorreu um erro ao inserir o produto na tabela temporária
                echo "Error adding game: " . $conn->error;
            }
        } else {
            // Nenhuma imagem foi enviada
            echo "No image has been selected.";
        }
    }

}
?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <title>All Games</title>
        <meta charset="UTF-8" />
        <meta http-equiv="Content-Language" content="en">
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <!-- FALTA ADICIONAR PARA A PESQUISA-->
        <link rel="website icon" type="png" href="../imgs/iconlogo.png" />
        <link rel="stylesheet" href="../css/bases/base_w3.css" />
        <link rel="stylesheet" href="../css/bases/cards.css" />
        <link rel="stylesheet" href="../css/main.css" />
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto" />
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <style>
            .imgsfree{
                background-image: url(../imgs/Games/main/solder_main.png);
                background-repeat: no-repeat;
                background-size: contain;
                background-position-x: 80%;
            }
        </style>
    </head>
    <body>
        <!-- Sidebar/menu -->
        <nav class="w3-sidebar w3-bar-block w3-collapse w3-top slidebar" style="z-index: 3; width: 250px;" id="mySidebar">
            <div class="w3-display-container w3-container">
                <div class="w3-container w3-display-container w3-padding-16">
                    <i onclick="w3_close()" class="fa fa-remove w3-hide-large w3-button w3-display-topright"></i>
                    <img src="../imgs/Logo.png" style="width: 100%;"/>
                </div>
                    <a class="w3-bar-item w3-button w3-padding w3-round-xxlarge" href="#" onclick="document.getElementById('profile').style.display='block'">
                        <span>
                            <svg width="30" height="30" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                                <path d="M12 3a4 4 0 1 0 0 8 4 4 0 1 0 0-8z"></path>
                            </svg>
                        </span>
                        <span>Profile</span>
                    </a>
                    <a class="w3-bar-item w3-button w3-padding w3-round-xxlarge" href="#">
                        <span>
                            <svg width="30" height="30" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path d="M11 3a8 8 0 1 0 0 16 8 8 0 1 0 0-16z"></path>
                                <path d="m21 21-4.35-4.35"></path>
                            </svg>
                        </span>
                        <span>Search</span>
                    </a>
                    <a class="w3-bar-item w3-button w3-padding w3-round-xxlarge" href="#">
                        <span>
                            <svg width="30" height="30" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path d="M21 8v13H3V8"></path>
                                <path d="M1 3h22v5H1z"></path>
                                <path d="M10 12h4"></path>
                            </svg>
                        </span>
                        <span>Store</span>
                    </a>
                    <a class="w3-bar-item w3-button w3-padding w3-round-xxlarge" href="#">
                        <span>
                            <svg width="30" height="30" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path d="M9 20a1 1 0 1 0 0 2 1 1 0 1 0 0-2z"></path>
                                <path d="M20 20a1 1 0 1 0 0 2 1 1 0 1 0 0-2z"></path>
                                <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
                            </svg>
                        </span>
                        <span>Cart</span>
                    </a>
                    <a class="w3-bar-item w3-button w3-padding w3-round-xxlarge" href="#">
                        <span>
                            <svg width="30" height="30" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"></path>
                                <path d="m10 17 5-5-5-5"></path>
                                <path d="M15 12H3"></path>
                            </svg>
                        </span>
                        <span>Log In</span>
                    </a>
                    <a class="w3-bar-item w3-button w3-padding w3-round-xxlarge" href="#">
                        <span>
                            <svg width="30" height="30" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path d="M12 2a10 10 0 1 0 0 20 10 10 0 1 0 0-20z"></path>
                                <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path>
                                <path d="M12 17h.01"></path>
                            </svg>
                        </span>
                        <span>Help</span>
                    </a>
                    <a class="w3-bar-item w3-button w3-padding w3-round-xxlarge" href="#">
                        <span>
                            <svg width="30" height="30" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path d="M12 2a10 10 0 1 0 0 20 10 10 0 1 0 0-20z"></path>
                                <path d="M12 8v4"></path>
                                <path d="M12 16h.01"></path>
                            </svg>
                        </span>
                        <span>Conditions</span>
                    </a>
            </div>
        </nav>

        <!-- Profile -->
        <div id="profile" class="w3-modal">
            <div class="w3-modal-content w3-round-xlarge" style="background-color: #323232;">
                <div class="w3-container">
                    <span onclick="document.getElementById('profile').style.display='none'" class="w3-button w3-display-topright">&times;</span>
                    <p>Some text. Some text. Some text.</p>
                    <p>Some text. Some text. Some text.</p>
                </div>
            </div>
        </div>

        <!-- Top menu on small screens -->
        <header class="w3-bar w3-top w3-hide-large w3-xlarge slidebar">
            <div class="w3-bar-item w3-padding-24 w3-wide"></div>
            <a href="javascript:void(0)" class="w3-bar-item w3-button w3-padding-24 w3-right bars" onclick="w3_open()"><i class="fa fa-bars"></i></a>
        </header>

        <!-- Overlay effect when opening sidebar on small screens -->
        <div class="w3-overlay w3-hide-large" onclick="w3_close()" style="cursor: pointer;" title="close side menu" id="myOverlay"></div>

        <!-- Main Content -->
        <div class="w3-main" style="margin-left: 250px;">
            <div class="w3-display-container w3-container">
                    <h2><strong>Add Game</strong></h2>
                <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>" enctype="multipart/form-data">
                    <table>
                        <tr>
                            <td>Name:</td>
                            <td><input type="text" name="nome"></td>
                        </tr>
                        <tr>
                            <td>Download:</td>
                            <td><input type="text" name="url"></td>
                        </tr>
                        <tr>
                            <td>Image:</td>
                            <td><input type="file" name="imagem" accept-language="en"></td>
                        </tr>
                        <tr>
                            <td colspan="2" class="w3-center">
                                <button type="submit">Add</button>
                                <a href="javascript:history.back()"><button type="button">Back</button></a>
                                <a href="../html/Main.php"><button type="button">Main</button></a>
                            </td>
                        </tr>
                    </table>
                </form>
            </div>
        </div>
        <!-- End Main Content -->

        <!-- Accordion -->
        <script>
            function myAccFunc() {
                var x = document.getElementById("demoAcc");
                if (x.className.indexOf("w3-show") == -1) {
                    x.className += " w3-show";
                } else {
                    x.className = x.className.replace(" w3-show", "");
                }
            }

            // Open and close sidebar
            function w3_open() {
                document.getElementById("mySidebar").style.display = "block";
                document.getElementById("myOverlay").style.display = "block";
            }

            function w3_close() {
                document.getElementById("mySidebar").style.display = "none";
                document.getElementById("myOverlay").style.display = "none";
            }
        </script>
    </body>
</html>
