let logo = document.getElementById('logo');

if (logo) {
    logo.addEventListener("click", function() {
        window.location.href = "/content/html/Main.html";
    });
}
