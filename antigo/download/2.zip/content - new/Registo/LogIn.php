<?php
session_start();

require('../php/conecçao.php');

// Obter os valores do formulário
$email = mysqli_real_escape_string($conn, $_POST["user_email"]);
$senha = mysqli_real_escape_string($conn, $_POST["user_pass"]);

// Verificar se o User e senha estão corretos
$sql = "SELECT * FROM users WHERE email='$email' AND senha='$senha'";
$result = $conn->query($sql);

if ($result->num_rows == 1) {
    // User e senha corretos
    $row = $result->fetch_assoc();
    $_SESSION['user_id'] = $row['id'];
    $_SESSION['user_name'] = $row['nome'];
    $_SESSION['user_email'] = $row['email'];
    $_SESSION['user_passe'] = $row['senha'];
    $_SESSION['is_admin'] = $row['is_admin'];
    $_SESSION['user_tele'] = $row['telefone'];
    $_SESSION['user_ani'] = $row['aniversario'];
    echo '<script>window.location.href = "../html/Index.php";</script>';
    exit;
} else {
    // User ou senha incorretos
    echo '<script>alert("Email ou senha incorretos."); window.location.href = "../Login.html";</script>';
}

$conn->close();
?>
