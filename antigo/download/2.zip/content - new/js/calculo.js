var previousHTML = "";
var content = document.getElementById("content");


// Vai buscar os dados ao SQL das Tabelas de Preço
function changeHTML(service) {
    let buttons = document.querySelectorAll(".box_main button");

    previousHTML = content.innerHTML;

    buttons.forEach(function (button) {
        button.style.display = "none";
    });

    let html = "";

    console.log(service);

    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            var html = this.responseText;

            changeHTMLContent(html);

            block();
        }
    };
    xhttp.open("GET", "../php/dados/get_dados_" + service + ".php", true);
    xhttp.send();

    content.innerHTML = html;
}

//Muda o display
function changeHTMLContent(html) {
    if (content) {
        content.innerHTML = html;
    }
}

//Volta atras
function goBack() {
    if (previousHTML !== "") {
        if (content) {
            content.innerHTML = previousHTML;
        }
    }

    localStorage.removeItem("service_data");
    localStorage.removeItem("service");
    localStorage.removeItem("service_price");
    localStorage.removeItem("service_time");
}

function updatename(nome){
    var testeDiv = document.getElementById(nome);
    testeDiv.textContent = "Selecionado: " + nome + " ";

    // Desabilita escolher novamente
    var button = document.getElementById(nome);
    button.classList.add('disabled');
    //button.disabled = true;
}

function total(preco) {
    let totalElement = $("#total")[0];

    var storedDataPrice = localStorage.getItem("service_price");

    // Verifica se o total atual já foi definido
    let totalAtual = parseFloat(totalElement.textContent);
    if (isNaN(totalAtual)) {
        totalAtual = 0;
    }

    // Soma o preço atual ao total
    let novoTotal = totalAtual + parseFloat(preco);

    // Formata o novo total com o símbolo "€"
    let novoTotalFormatado = novoTotal.toFixed(2) + " €";

    // Atualiza o elemento do total com o novo valor formatado
    totalElement.textContent = novoTotalFormatado;

    localStorage.setItem("service_price", novoTotal);
}

function confirmarseta() {
    var confir = $('#confir');
    if (confir.length > 0) {
        confir[0].addEventListener("click", function() {
            window.location.href = "marcacao_table.php";
        }, false);
    }
}

function getservice(nome, preco, tempo) {

    var button = document.getElementById(nome);

    if(button.classList.contains('disabled')){
        disabled(nome, preco);
        // add a seta
        ableseta();
        // retirar a duração
        rettempo(nome, tempo);
    }else{
        able(nome, preco);
        // add a seta
        ableseta();
        // meter a duração
        addtempo(nome, tempo);
    }
}

function able(nome, preco){
    
    
    //Store 
        console.log(nome);
        
        var storedData = localStorage.getItem("service_data");
        var data = [];

        if (storedData) {
            // O valor já existe no localStorage, recupere-o e converta para array
            data = JSON.parse(storedData);
        }

        // Adicione o novo valor ao array
        data.push(nome);
        console.log(data);

        // Salve o array atualizado no localStorage
        localStorage.setItem("service_data", JSON.stringify(data));

    // Alterar a cor para os que foram selecionados
        updatename(nome);

    // Mostrar o Total das compras
        total(preco);

    // Caso a seta seja selecionada
        confirmarseta();
}

function block(){
    var storedData = localStorage.getItem("service_data");
    //console.log(storedData);

    if (storedData) {
        data = JSON.parse(storedData); // Converte a string JSON em um array
      
        // Itera sobre os elementos do array
        data.forEach(function(nome) {

            //altera o content dos botoes
            updatename(nome);
        });

        //mostra o total
        new_total();

        //muda de pagina ao carregar na seta
        confirmarseta();

        // retira a seta
        notconfirm();
    }
}

function new_total(){
    let totalElement = $("#total")[0];

    var storedDataPrice = localStorage.getItem("service_price");

    // Verifica se o total atual já foi definido
    let totalAtual = parseFloat(totalElement.textContent);
    if (isNaN(totalAtual)) {
        totalAtual = 0;
    }

    // Soma o preço atual ao total
    let novoTotal = totalAtual + parseFloat(storedDataPrice);

    console.log(novoTotal);

    // Formata o novo total com o símbolo "€"
    let novoTotalFormatado = novoTotal.toFixed(2) + " €";

    // Atualiza o elemento do total com o novo valor formatado
    totalElement.textContent = novoTotalFormatado;
}

function disabled(nome, preco){

    console.log('removeu ' + nome);

    // cria novamente o display antigo dos botoes
    var testeDiv = document.getElementById(nome);
    testeDiv.textContent = "";

    var nomeSpan = document.createElement("span");
    nomeSpan.style.float = "left";
    nomeSpan.textContent = nome;

    var precoSpan = document.createElement("span");
    precoSpan.style.float = "right";
    precoSpan.textContent = preco + " €";

    testeDiv.appendChild(nomeSpan);
    testeDiv.appendChild(precoSpan);


    // Retira a class
    var button = document.getElementById(nome);
    button.classList.remove('disabled');

    // Retirar Nome do localstorage
    retirarnome_local(nome);

    //Retirar preço do LocalStorage
    retirarprice_local(preco);

    //atualizar o preço nas retiradas
    disabled_price(preco);

}

function retirarprice_local(preco){

    let totalElement = $("#total")[0];

    let totalAtual = parseFloat(totalElement.textContent);
    if (totalAtual === 0) {
        localStorage.removeItem("service_price");
    }
}

function retirarnome_local(nome){
    var storedData = localStorage.getItem("service_data");

    if (storedData && storedData.includes(nome)) {
        var dataArr = JSON.parse(storedData);
        var index = dataArr.indexOf(nome);
        if (index !== -1) {
          dataArr.splice(index, 1);
          var updatedData = JSON.stringify(dataArr);
          localStorage.setItem("service_data", updatedData);
        }
    }
}

function disabled_price(preco){

    let totalElement = $("#total")[0];

    var storedDataPrice = localStorage.getItem("service_price");

    // Verifica se o total atual já foi definido
    let totalAtual = parseFloat(totalElement.textContent);
    if (isNaN(totalAtual)) {
        totalAtual = 0;
    }

    console.log(preco);

    // Soma o preço atual ao total
    let novoTotal = totalAtual - parseFloat(preco);

    console.log(novoTotal);

    if (novoTotal === 0) {
        localStorage.setItem('service_price', '0');
      }
      

    // Formata o novo total com o símbolo "€"
    let novoTotalFormatado = novoTotal.toFixed(2) + " €";

    // Atualiza o elemento do total com o novo valor formatado
    totalElement.textContent = novoTotalFormatado;

    notconfirm();
}

// Apagar o confir se o preço for 0

function notconfirm(){
    
    let totalElement = $("#total")[0];
    let text = totalElement.textContent;
    var divTeste = document.getElementById("confir");
    
    if(text === '0.00 €'){
        
    divTeste.style.display = "none";
    }
}

function ableseta(){
    
    let totalElement = $("#total")[0];
    let text = totalElement.textContent;
    var divTeste = document.getElementById("confir");
    
    if(text != '0.00 €'){
        
    divTeste.style.display = "block";
    }
}

function addtempo(nome, tempo) {
    console.log('acrescenta ' + nome + ' ' + tempo + ' minutos');
    var storedDataTime = localStorage.getItem("service_time");

    if (storedDataTime === null || storedDataTime === "0") {
        localStorage.setItem("service_time", tempo);
        console.log(localStorage.getItem("service_time"));
    } else {
        let novoTotal = parseFloat(tempo) + parseFloat(storedDataTime);
        localStorage.setItem("service_time", novoTotal);
        console.log(localStorage.getItem("service_time"));
    }
}


function rettempo(nome, tempo){
    console.log('retira ' + nome + ' ' + tempo + ' minutos');
    var storedDataTime = localStorage.getItem("service_time");

    
    let novoTotal = parseFloat(storedDataTime) - parseFloat(tempo);
    localStorage.setItem("service_time", novoTotal);
    console.log(localStorage.service_time);
}
