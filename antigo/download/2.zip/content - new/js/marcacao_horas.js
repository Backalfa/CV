function scure(time) {
    var button = document.getElementById(time);
    
    // Faz uma requisição assíncrona usando AJAX
    var xhr = new XMLHttpRequest();
    xhr.open('GET', '../php/marcacao/check_appointment.php?time=' + encodeURIComponent(time), true);
    xhr.onreadystatechange = function() {
        if (xhr.readyState === XMLHttpRequest.DONE) {
          if (xhr.status === 200) {
            // Parseia a resposta JSON
            var response = JSON.parse(xhr.responseText);
  
            // Se a resposta for true, desabilita o botão
            if (response === true) {
              button.disabled = true;
            }
          } else {
            console.error('Ocorreu um erro na requisição: ' + xhr.status);
          }
        }
      };
      xhr.send();
    }
  
    // Chama a função scure() para o horário '9:00' quando a página é carregada
    window.onload = function() {
      scure('9:00:00');
      scure('9:30:00');
      scure('10:00:00');
      scure('10:30:00');
      scure('11:00:00');
      scure('11:30:00');
      scure('12:00:00');
      scure('12:30:00');
      scure('13:00:00');
      scure('13:30:00');
      scure('14:00:00');
      scure('14:30:00');
      scure('15:00:00');
      scure('15:30:00');
      scure('16:00:00');
      scure('16:30:00');
      scure('17:00:00');
      scure('17:30:00');
      scure('18:00:00');
      scure('18:30:00');
      scure('19:00:00');
      scure('19:30:00');
    };