
function servicos_data() {
    var servicos = localStorage.getItem('service_data'); // Obtém a string do localStorage
    var serviceArray = JSON.parse(servicos); // Converte a string em um array JavaScript

    // Cria uma variável para armazenar a concatenação dos itens
    var servicosConcatenados = '';

    for (var i = 0; i < serviceArray.length; i++) {
        var item = serviceArray[i];
        console.log(item);

        // Concatena o item atual com os itens anteriores e adiciona a quebra de linha
        servicosConcatenados += item + '<br>';
    }

    // Define o conteúdo do elemento HTML
    document.getElementById('servicos').innerHTML = servicosConcatenados;
}

function servicos_price(){
    
    let preco = localStorage.getItem("service_price");

    document.getElementById('preco').textContent = parseInt(preco) + ' €';
}

function service_datas(){

    let dia = localStorage.getItem("dia");
    let dia_semana = localStorage.getItem("dia_semana");
    let horas = localStorage.getItem("service_hora");
    let duracao = localStorage.getItem("service_time");

    // Separar a hora e os minutos da string
    var partesHora = horas.split(':');
    var horaAtual = parseInt(partesHora[0]);
    var minutosAtual = parseInt(partesHora[1]);

    // Adicionar os minutos ao valor atual
    var novaHora = new Date();
    novaHora.setHours(horaAtual);
    novaHora.setMinutes(minutosAtual + duracao);

    var novaHoraString = novaHora.getHours().toString().padStart(2, '0') + ':' + novaHora.getMinutes().toString().padStart(2, '0');


    document.getElementById('datas').innerHTML = dia_semana + ' <br> ' + dia + '<p> Das ' + horas + 'h até as ' + novaHoraString + 'h </p>';


}

servicos_data();
servicos_price();
service_datas();