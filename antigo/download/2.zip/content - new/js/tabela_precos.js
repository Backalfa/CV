$(document).ready(function() {
    var zeroValues = $('table').find('td').filter(function() {
      return $(this).text().trim() === '0.00€';
    });
  
    console.log(zeroValues, "OK");
    
    zeroValues.text(' ');
  });
  