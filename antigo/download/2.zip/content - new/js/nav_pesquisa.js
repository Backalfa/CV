// Obter o elemento do ícone de pesquisa
var searchIcon = document.getElementById("search-icon");

// Obter o elemento do input de pesquisa
var searchInput = document.getElementById("search-input");

// Adicionar um ouvinte de eventos ao ícone de pesquisa para alternar a exibição do input de pesquisa
searchIcon.addEventListener("click", function() {
  searchInput.classList.toggle("show");
});

