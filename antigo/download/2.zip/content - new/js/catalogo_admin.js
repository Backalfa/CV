genero();
pesq();

function genero(){
    const homens = document.querySelectorAll("td:nth-child(6)");
    const mulheres = document.querySelectorAll("td:nth-child(7)");


    homens.forEach(homem => {
        if (homem.textContent === '1') {
            homem.textContent = 'Sim';
        }else if(homem.textContent === '0') {
            homem.textContent = 'Não';
        }else{
            homem.textContent = 'Erro';
        }
    });

    mulheres.forEach(mulher => {
        if (mulher.textContent === '1') {
            mulher.textContent = 'Sim';
        }else if(mulher.textContent === '0') {
            mulher.textContent = 'Não';
        }else{
            mulher.textContent = 'Erro';
        }
    });
}

function pesq(){
    $('#pesq').on('keyup', function() {
        var valor = $(this).val().toLowerCase(); // Valor digitado, convertido para minúsculo
        $('#tabela tbody tr').filter(function() {
          // Ocultar as linhas que não correspondem ao filtro
          $(this).toggle($(this).text().toLowerCase().indexOf(valor) > -1);
        });
      });
}