genero();

function genero(){
    const homens = document.querySelectorAll("td:nth-child(7)");
    const mulheres = document.querySelectorAll("td:nth-child(8)");


    homens.forEach(homem => {
        if (homem.textContent === '1') {
            homem.textContent = 'Sim';
        }else if(homem.textContent === '0') {
            homem.textContent = 'Não';
        }else{
            homem.textContent = 'Erro';
        }
    });

    mulheres.forEach(mulher => {
        if (mulher.textContent === '1') {
            mulher.textContent = 'Sim';
        }else if(mulher.textContent === '0') {
            mulher.textContent = 'Não';
        }else{
            mulher.textContent = 'Erro';
        }
    });
}