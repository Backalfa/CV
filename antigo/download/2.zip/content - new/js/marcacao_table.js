function goBack(){
    window.location.href = "marcacao.php";
}