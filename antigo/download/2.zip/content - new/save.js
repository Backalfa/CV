if (time <= 30) {
    console.log('1 a 1');
} else if (time > 30 && time <= 60) {
    console.log('2 a 2');
} else if (time > 60 && time <= 90) {
    console.log('Time entre 60 e 90, botoes de 3 a 3');
} else if (time > 90 && time <= 120) {
    console.log('4 a 4');
} else if (time > 120 && time <= 150) {
    console.log('5 a 5');
} else if (time > 150 && time <= 180) {
    console.log('6 a 6');
} else if (time > 180 && time <= 210) {
    console.log('7 a 7');
} else if (time > 210 && time <= 240) {
    console.log('8 a 8');
} else if (time > 240 && time <= 270) {
    console.log('9 a 9');
} else if (time > 270 && time <= 300) {
    console.log('10 a 10');
} else if (time > 300 && time <= 330) {
    console.log('11 a 11');
} else if (time > 330 && time <= 360) {
    console.log('12 a 12');
} else if (time > 360 && time <= 390) {
    console.log('13 a 13');
} else if (time > 390 && time <= 420) {
    console.log('14 a 14');
} else if (time > 420 && time <= 450) {
    console.log('15 a 15');
} else if (time > 450 && time <= 480) {
    console.log('16 a 16');
} else {
    console.log('Valor inválido');
}
