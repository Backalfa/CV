<?php
session_start();

// Verificar se a referência foi enviada
if (isset($_POST['referencia'])) {
    $referencia = $_POST['referencia'];

    // Remover todas as ocorrências da referência do array do carrinho
    $_SESSION["carrinho"] = array_filter($_SESSION["carrinho"], function ($item) use ($referencia) {
        return $item !== $referencia;
    });

    // Responder com sucesso (código HTTP 200)
    http_response_code(200);
    exit();
}

// Responder com erro (código HTTP 400)
http_response_code(400);
exit();
?>
