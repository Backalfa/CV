<!DOCTYPE html>
<html>
    <head>
        <title>Beatriz Miranda Oriflame</title>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="website icon" type="png" href="../imgs/icontab.png" />
    </head>
    <body>
    <?php
    require('conecçao.php');

    // Verifica se os dados foram enviados por meio do método POST
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Obtém os valores atualizados dos campos do formulário
        $ref = $_POST['ref'];
        $nome = $_POST['nome'];
        $preco = $_POST['preco'];
        $preco_novo = $_POST['preco_novo'];
        $quantidade = $_POST['quantidade'];
        $homem = $_POST['homem'];
        $mulher = $_POST['mulher'];
        $categ = $_POST['categ'];

        // Verifica se uma nova imagem foi enviada
        if (isset($_FILES['imagem']) && $_FILES['imagem']['error'] === UPLOAD_ERR_OK) {
            // Obtém informações sobre a imagem enviada
            $imagem = $_FILES['imagem'];
            $imagemNome = $imagem['name'];
            $imagemTipo = $imagem['type'];
            $imagemTamanho = $imagem['size'];
            $imagemTmpName = $imagem['tmp_name'];

            // Lê o conteúdo da imagem em bytes
            $imagemConteudo = file_get_contents($imagemTmpName);
            // Escapa os caracteres especiais para evitar problemas de SQL Injection
            $imagemConteudo = $conn->real_escape_string($imagemConteudo);

            // Atualiza a imagem no banco de dados
            $sql = "UPDATE produtos SET nome = '$nome', preco = '$preco', preco_novo = '$preco_novo', quantidade = '$quantidade', homem = '$homem', mulher = '$mulher', categ = '$categ', imagem = '$imagemConteudo' WHERE ref = '$ref'";
        } else {
            // Atualiza os outros campos sem alterar a imagem
            $sql = "UPDATE produtos SET nome = '$nome', preco = '$preco', preco_novo = '$preco_novo', quantidade = '$quantidade', homem = '$homem', mulher = '$mulher', categ = '$categ' WHERE ref = '$ref'";
        }

        // Execute a consulta SQL para atualizar o registro
        // Substitua a variável $conn pela sua conexão real com o banco de dados
        if ($conn->query($sql) === TRUE) {
            echo "Registro atualizado com sucesso.";
            echo '<br><button type="button" onclick="window.history.back()">Voltar</button>';
        } else {
            echo "Erro ao atualizar o registro: " . $conn->error;
        }

        // Fecha a conexão com o banco de dados
        $conn->close();
    }
    ?>
    </body>
</html>
