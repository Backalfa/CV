<?php
// Verifica se o formulário foi submetido e se o valor do botão "adicionar_carrinho" está definido
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["adicionar_carrinho"])) {
    // Obtém o valor da referência do item do botão "adicionar_carrinho"
    $referencia = $_POST["adicionar_carrinho"];

    // Aqui você pode realizar as ações necessárias para adicionar o item ao carrinho
    // Por exemplo, você pode armazenar a referência em uma sessão ou em um banco de dados

    // Exemplo: armazenar a referência em uma sessão
    session_start();
    $_SESSION["carrinho"][] = $referencia;

    // Redireciona de volta para a página do catálogo ou para a página de carrinho de compras
    header("Location: ../html/catalogo.php");
    exit();
}
?>