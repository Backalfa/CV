<?php

    require('../conecçao.php');

    $diaSemana = $_POST['diaSemana'];

    // Escapar o valor da variável para evitar injeção de SQL
    $diaSemana = $conn->real_escape_string($diaSemana);

    // Consulta os horários disponíveis para o dia da semana na tabela WorkTime
    $sql = "SELECT * FROM worktime WHERE weekday = '$diaSemana'";

    $result = $conn->query($sql);

    $response = array();

    if ($result->num_rows > 0) {
        $manha = array();
        $tarde = array();

        while ($row = $result->fetch_assoc()) {
            // Obter horários da manhã
            $start_day = strtotime($row['start_time']);
            $start_lunch = strtotime($row['start_lunch']);

            while ($start_day < $start_lunch) {
                $horario = date('H:i', $start_day);
                $manha[] = $horario;
                $start_day = strtotime('+30 minutes', $start_day);
            }

            // Obter horários da tarde
            $horario_atual = strtotime($row['end_lunch']);
            $horario_fim = strtotime($row['end_time']);

            while ($horario_atual < $horario_fim) {
                $horario = date('H:i', $horario_atual);
                $tarde[] = $horario;
                $horario_atual = strtotime('+30 minutes', $horario_atual);
            }
        }

        $response['manha'] = $manha;
        $response['tarde'] = $tarde;
    } else {
        $response['error'] = 'Nenhum horário disponível para o dia da semana.';
    }

    // Retorna a resposta como um JSON
    echo json_encode($response);

?>