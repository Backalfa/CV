<?php
// Recupera o valor da variável "dia" passada na URL
$dia = $_GET['dia'];

require('../conecçao.php');

// Escapa o valor da variável "dia" para evitar injeção de SQL
$dia = $conn->real_escape_string($dia);

// Remove o último caractere da string
$dia = substr($dia, 0, -1);

// Monta a consulta SQL para buscar os dados na tabela "worktime" com base no valor da variável "dia"
$sql = "SELECT is_day_off FROM worktime WHERE weekday = '$dia'";

// Executa a consulta SQL
$result = $conn->query($sql);

// Verifica se a consulta retornou algum resultado
if ($result->num_rows > 0) {
  // Existe um resultado na consulta
  $row = $result->fetch_assoc();
  $isDayOff = $row["is_day_off"];

  if ($isDayOff == 1) {
    $folga = true; // Dia de folga
  } else {
    $folga = false; // Dia disponível
  }
} else {
  // Não há resultado na consulta
  $folga = false; // Dia disponível
}

// Retorna o resultado como uma resposta JSON
echo json_encode($folga);

// Fecha a conexão com o banco de dados
$conn->close();
?>
