<?php
    // Recupera o valor da variável "time" e "dia" passadas na URL
    $time = $_GET['time'];
    $dia = $_GET['dia'];

    require('../conecçao.php');

    // Escapa os valores das variáveis "time" e "dia" para evitar injeção de SQL
    $time = $conn->real_escape_string($time);
    $dia = $conn->real_escape_string($dia);

    // Monta a consulta SQL para buscar os dados na tabela "appointments" com base no valor de "time" e "dia"
    $sql = "SELECT * FROM appointments WHERE dia = '$dia' AND '$time' >= horas_inicio AND '$time' < horas_fim";

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $response = true; // Há uma reserva no horário especificado
    } else {
        $response = false; // Não há reserva no horário especificado
    }

    // Retorna o valor booleano como resposta JSON
    echo json_encode($response);

    // Fecha a conexão com o banco de dados
    $conn->close();
?>
