<?php

require('conecçao.php');

// Verifica se a variável 'ref' foi passada via GET
if (isset($_GET['ref'])) {
    // Obtém o valor de 'ref' da solicitação
    $ref = $_GET['ref'];

    // Prepara a instrução SQL DELETE
    $sql = "DELETE FROM produtos WHERE ref = '$ref'";

    // Executa a instrução SQL DELETE
    if ($conn->query($sql) === TRUE) {
        // Redireciona o usuário de volta para a página onde a tabela é exibida
        header("Location: ../html/catalogo.php");
        exit;
    } else {
        echo "Erro ao excluir registro: " . $conn->error;
    }
} else {
    echo "Erro: referência não fornecida.";
}

// Fecha a conexão com o banco de dados
$conn->close();
?>
