<!-- Save adicionar sem imagem -->

<?php

require('conecçao.php');

// Verifica se o formulário foi submetido
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Realize as validações e processamento dos dados enviados pelo formulário
    // ...

    // Após processar os dados, você pode inserir o novo produto no banco de dados
    // Substitua as variáveis $conn pelas suas próprias configurações de conexão

    $ref = $_POST['ref'];
    $nome = $_POST['nome'];
    $preco = $_POST['preco'];
    $preco_novo = $_POST['preco_novo'];
    $quantidade = $_POST['quantidade'];
    $homem = $_POST['homem'];
    $mulher = $_POST['mulher'];
    $categ = $_POST['categ'];

    // Consulta SQL para verificar se já existe um produto com a mesma referência
    $checkQuery = "SELECT ref FROM produtos WHERE ref = '$ref'";
    $checkResult = $conn->query($checkQuery);

    if ($checkResult->num_rows > 0) {
        // Já existe um produto com a mesma referência
        echo "Já existe um produto com essa referência.";
    } else {
        // Verifica se uma imagem foi enviada
        if (isset($_FILES['imagem']) && $_FILES['imagem']['error'] === UPLOAD_ERR_OK) {
            // Obtém informações sobre a imagem enviada
            $imagem = $_FILES['imagem'];
            $imagemNome = $imagem['name'];
            $imagemTipo = $imagem['type'];
            $imagemTamanho = $imagem['size'];
            $imagemTmpName = $imagem['tmp_name'];

            // Lê o conteúdo da imagem em bytes
            $imagemConteudo = file_get_contents($imagemTmpName);

            // Escapa os caracteres especiais para evitar problemas de SQL Injection
            $ref = $conn->real_escape_string($ref);
            $nome = $conn->real_escape_string($nome);
            $preco = $conn->real_escape_string($preco);
            $preco_novo = $conn->real_escape_string($preco_novo);
            $quantidade = $conn->real_escape_string($quantidade);
            $homem = $conn->real_escape_string($homem);
            $mulher = $conn->real_escape_string($mulher);
            $categ = $conn->real_escape_string($categ);
            $imagemConteudo = $conn->real_escape_string($imagemConteudo);

            // Consulta SQL para inserir o novo produto na tabela, incluindo a imagem
            $sql = "INSERT INTO temp_produtos (ref, nome, preco, preco_novo, quantidade, homem, mulher, categ, imagem)
                    VALUES ('$ref', '$nome', '$preco', '$preco_novo', '$quantidade', '$homem', '$mulher', '$categ', '$imagemConteudo')";

            // Executa a consulta SQL
            if ($conn->query($sql) === TRUE) {
                // O produto foi inserido com sucesso na tabela temporária
                echo "Produto adicionado com sucesso para revisão. Aguarde a aprovação do administrador.";
            } else {
                // Ocorreu um erro ao inserir o produto na tabela temporária
                echo "Erro ao adicionar o produto: " . $conn->error;
            }
        } else {
            // Nenhuma imagem foi enviada
            echo "Nenhuma imagem foi selecionada.";
        }
    }

}
?>


<!DOCTYPE html>
<html>
    <head>
        <title>Beatriz Miranda Oriflame</title>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="website icon" type="png" href="../imgs/icontab.png" />
        <link rel="stylesheet" href="../css/base_w3.css" />

    </head>
    <body>
        
        <div class="w3-row-padding">
            <div class="w3-col s12 m12 l6 w3-center">
                <h2>Adicionar Produto</h2>
                <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>" enctype="multipart/form-data">
                    <table>
                        <tr>
                            <td>Referência:</td>
                            <td><input type="text" name="ref"></td>
                        </tr>
                        <tr>
                            <td>Nome:</td>
                            <td><input type="text" name="nome"></td>
                        </tr>
                        <tr>
                            <td>Preço:</td>
                            <td><input type="text" name="preco"></td>
                        </tr>
                        <tr>
                            <td>Preço Novo:</td>
                            <td><input type="text" name="preco_novo"></td>
                        </tr>
                        <tr>
                            <td>Quantidade:</td>
                            <td><input type="text" name="quantidade"></td>
                        </tr>
                        <tr>
                            <td>Homem:</td>
                            <td><input type="text" name="homem"></td>
                        </tr>
                        <tr>
                            <td>Mulher:</td>
                            <td><input type="text" name="mulher"></td>
                        </tr>
                        <tr>
                            <td>Categoria:</td>
                            <td><input type="text" name="categ"></td>
                        </tr>
                        <tr>
                            <td>Imagem:</td>
                            <td><input type="file" name="imagem"></td>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <button type="submit">Adicionar</button>
                                <a href="javascript:history.back()"><button type="button">Voltar</button></a>
                                <a href="../html/catalogo.php"><button type="button">Início</button></a>
                            </td>
                        </tr>
                    </table>
                </form>
            </div>
            <div class="w3-col s12 m12 l6">
                <h2>Demonstração</h2>
                <?php
                // Exibir a lista de produtos da tabela temporária para revisão

                $sql = "SELECT * FROM temp_produtos";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        if ($row["homem"] == 1 && $row["mulher"] == 1){
                            $genero = '<span class="w3-tag w3-display-topright" style="background-color: transparent;">
                                            <span style="background-color: rgb(155, 201, 231); border-radius: 50%;padding: 5px;">H</span>
                                            <span style="background-color: rgb(252, 166, 233); border-radius: 50%;padding: 5px;">M</span>
                                        </span>';
                        }elseif ($row["homem"] == 1 || $row["mulher"] == 1){
                            if ($row["homem"] == 1) {
                                $genero = '<span class="w3-tag w3-display-topright" style="background-color: transparent;">
                                                <span style="background-color: rgb(155, 201, 231); border-radius: 50%;padding: 5px;">H</span>
                                            </span>';
                            } elseif ($row["mulher"] == 1) {
                                $genero = '<span class="w3-tag w3-display-topright" style="background-color: transparent;">
                                                <span style="background-color: rgb(252, 166, 233); border-radius: 50%;padding: 5px;">M</span>
                                            </span>';
                            }
                        } else {
                            $genero = "";
                        }
                        
                        // Se a quantidade do produto for 0 então está vendido
                        if ($row["quantidade"] == 0){
                            $quantidade = '<span class="w3-tag" style="position: absolute; top: 0;left:0;">Vendido!</span>';
                            $nquantidade = '';
                        } else {
                            $quantidade = '<span class="w3-tag" style="position: absolute; top: 0;left:0;"></span>';
                            $nquantidade = $row["quantidade"];
                        }

                        // Se o preço novo é mais baixo que o antigo o artigo está em promoção
                        if ($row["preco"] > $row["preco_novo"]){
                            $prom = '<span class="w3-tag w3-display-topleft" style="background-color: rgb(255, 0, 0);">Promoção</span>';
                            $prompreco = '<s>'.$row["preco"].'€</s><b><span style="color:rgb(255, 0, 0); margin-left: 5%;">'.$row["preco_novo"].'€</span></b>';
                        } else {
                            $prom = '';
                            $prompreco = '<b>'.$row["preco"].' €</b></p>';
                        }

                        // Botão carrinho de compras
                        $carrinho = '<span class="" style="position: absolute; bottom: 0;left: 0;">
                                        <button class="w3-button w3-teal w3-round-large" type="submit" name="adicionar_carrinho" value="' . $row["ref"] . '">
                                            <script src="https://cdn.lordicon.com/bhenfmcm.js"></script>
                                            <lord-icon
                                                src="https://cdn.lordicon.com/udbbfuld.json"
                                                trigger="hover"
                                                colors="primary:#000000"
                                                style="width:20px;height:20px">
                                            </lord-icon> Carrinho
                                            </button>
                                        </span>';

                        echo '<div class="w3-col l6 s6 count">
                            <div class="w3-container">
                                <div class="w3-display-container">'. $quantidade . $prom .'
                                    <img src="data:image/jpeg;base64,' . base64_encode($row['imagem']) . '" style="width: 90%;" />
                                    ' . $carrinho . '
                                    <span class="w3-tag" style="position: absolute; bottom: 0;"><div>'. $nquantidade .'</div></span>
                                    '.$genero.'
                                </div>
                                <div>
                                    <p><span style="font-size: smaller;">Ref: '.$row["ref"].'</span><br />
                                    '.$row["nome"].'<br />
                                    '. $prompreco .'
                                </div>
                                <form method="POST" action="aprovar_produto.php">
                                    <input type="hidden" name="produto_ref" value="' . $row["ref"] . '">
                                    <button type="submit">Aprovar</button>
                                    <button type="button" onclick="rejeitarProduto(' . $row["ref"] . ')">Rejeitar</button>
                                </form>
                            </div>
                        </div>';
                    }
                } else {
                    echo "Nenhum produto para revisão no momento.";
                }
            ?>
            </div>
    </body>
</html>
