<!DOCTYPE html>
<html>
    <head>
        <title>Beatriz Miranda Oriflame</title>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="website icon" type="png" href="../imgs/icontab.png" />
    </head>
    <body>
        <?php

        require('conecçao.php');


        // Verifica se a referência (ref) do registro foi passada como parâmetro
        if (isset($_GET['ref'])) {
            // Obtém a referência do registro a ser editado
            $ref = $_GET['ref'];

            // Aqui você pode escrever o código para buscar os dados do registro no banco de dados, com base na referência fornecida

            // Exemplo de consulta SQL para buscar o registro no banco de dados
            $sql = "SELECT * FROM produtos WHERE ref = '$ref'";

            // Execute a consulta SQL e obtenha os dados do registro
            // Substitua a variável $conn pela sua conexão real com o banco de dados
            $result = $conn->query($sql);

            // Verifique se o registro foi encontrado
            if ($result->num_rows > 0) {
                // O registro foi encontrado, você pode recuperar os dados aqui

                // Exemplo de como exibir os dados em um formulário de edição
                while ($row = $result->fetch_assoc()) {
                    $ref = $row['ref'];
                    $nome = $row['nome'];
                    $preco = $row['preco'];
                    $preco_novo = $row["preco_novo"];
                    $quantidade = $row["quantidade"];
                    $homem = $row["homem"];
                    $mulher = $row["mulher"];
                    $categ = $row["categ"];
                    $imagem = $row["imagem"];

                    // Exiba o formulário de edição com os campos preenchidos
                    echo '
                        <form method="POST" action="atualizar_catalogo.php" enctype="multipart/form-data">
                            <input type="text" name="ref" value="' . $ref . '">
                            <table>
                                <tr>
                                    <td>Nome:</td>
                                    <td><input type="text" name="nome" value="' . $nome . '"></td>
                                </tr>
                                <tr>
                                    <td>Preço:</td>
                                    <td><input type="text" name="preco" value="' . $preco . '"></td>
                                </tr>
                                <tr>
                                    <td>Preço Novo:</td>
                                    <td><input type="text" name="preco_novo" value="' . $preco_novo . '"></td>
                                </tr>
                                <tr>
                                    <td>Quantidade:</td>
                                    <td><input type="text" name="quantidade" value="' . $quantidade . '"></td>
                                </tr>
                                <tr>
                                    <td>Homem:</td>
                                    <td><input type="text" name="homem" value="' . $homem . '"></td>
                                </tr>
                                <tr>
                                    <td>Mulher:</td>
                                    <td><input type="text" name="mulher" value="' . $mulher . '"></td>
                                </tr>
                                <tr>
                                    <td>Categoria:</td>
                                    <td><input type="text" name="categ" value="' . $categ . '"></td>
                                </tr>
                                <tr>
                                    <td>Imagem:</td>
                                    <td><img src="data:image/jpeg;base64,' . base64_encode($row['imagem']) . '" style="width: 100px;" /><input type="file" name="imagem"></td>
                                </tr>
                                <tr>
                                    <td colspan="2">
                                        <button type="submit">Atualizar</button>
                                        <a href="javascript:history.back()"><button type="button">Voltar</button></a>
                                        <a href="../html/catalogo.php"><button type="button">Início</button></a>
                                    </td>
                                </tr>
                            </table>
                        </form>';
                }



                } else {
                    echo "Registro não encontrado.";
                }

            } else {
                echo "Referência do registro não fornecida.";
            }
        ?>
    </body>
</html>