<?php
session_start();

// Verificar se a referência do produto foi fornecida
if (isset($_POST['referencia'])) {
  $referencia = $_POST['referencia'];

  // Adicionar a referência ao carrinho
  $_SESSION['carrinho'][] = $referencia;
  
  // Retornar os dados atualizados do carrinho
  $dadosAtualizados = array(
    'carrinho' => $_SESSION['carrinho']
  );
  
  // Retornar os dados atualizados como JSON
  echo json_encode($dadosAtualizados);
} else {
  echo 'Referência do produto não fornecida.';
}
?>
