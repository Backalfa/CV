<?php

require('../conecçao.php');

// Execute a consulta SQL para buscar os dados da tabela epilacao
$sql = "SELECT * FROM nail_art";
$result = $conn->query($sql);

// Verifique se a consulta retornou algum resultado
if ($result->num_rows > 0) {
    // Inicialize uma variável para armazenar o HTML
    $html = "";

    $html.= "<h3>Caixa</h3>
            <div class='w3-row' style='width: 90%;'>
                <div class='w3-col s2 m2 l2 w3-center'>
                    <button class='w3-button w3-block w3-light-grey' type='button' onclick='goBack()'>
                    <script src='https://cdn.lordicon.com/bhenfmcm.js'></script>
                    <lord-icon
                        src='https://cdn.lordicon.com/nhfyhmlt.json'
                        trigger='hover'
                        colors='primary:#000000'
                        style='width:40px;height:40px;cursor:pointer;'>
                    </lord-icon></button>
                </div>
                <div class='w3-col s8 m8 l8 w3-center'>
                    <h5>Nail Art</h5>
                    <p id='total'></p>
                </div>
                <div class='w3-col s2 m2 l2 w3-center'>
                    <div id='confir'></div>
                </div>
            </div><br/>

    ";

    // Itere sobre os resultados da consulta
    while ($row = $result->fetch_assoc()) {
        $nome = $row["nome"];
        $preco = $row["preco"];
        $tempo = $row["tempo"];
        
        if ($tempo === null) {
            $tempo = 30; // Definir o valor padrão como 30
        }
        
        // Construa o HTML com base nos dados obtidos
        $html .= "<button id='$nome' value='$preco' class='w3-button w3-block w3-light-grey' type='button' onclick=\"getservice('$nome','$preco','$tempo')\" style='width:90%; cursor:pointer;'><span style='float:left'>$nome</span> <span style='float:right'>$preco €</span></button><br/>";
    }

    // Retorne o HTML
    echo $html;
    
} else {
    // Caso não haja resultados
    echo "<p>Nenhum resultado encontrado.</p>";
}

// Feche a conexão com o banco de dados
$conn->close();
?>