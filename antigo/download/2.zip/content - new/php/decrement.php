<?php
session_start();

// Verificar se a referência foi enviada
if (isset($_POST['retirar_carrinho'])) {
    $retirar = $_POST['retirar_carrinho'];

    // Encontre a primeira ocorrência da referência no array
    $key = array_search($retirar, $_SESSION["carrinho"]);

    // Verifique se a referência foi encontrada
    if ($key !== false) {
        // Remova a referência do array na posição encontrada
        unset($_SESSION["carrinho"][$key]);
        echo 'Referência removida com sucesso do carrinho.';
    }

    // Redireciona de volta para a página do carrinho de compras
    header("Location: ../html/main_carrinho.php");
    exit();
}

// Responder com erro (código HTTP 400)
http_response_code(400);
exit();
?>
