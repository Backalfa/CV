<?php
require('../php/conecçao.php');

// Obter os valores do formulário
$nome = mysqli_real_escape_string($conn, $_POST["Name"]);
$email = mysqli_real_escape_string($conn, $_POST["Email"]);
$assunto = mysqli_real_escape_string($conn, $_POST["Subject"]);
$mensagem = mysqli_real_escape_string($conn, $_POST["Message"]);

// Inserir os valores na tabela
$sql = "INSERT INTO contacto_index (nome, email, assunto, mensagem) VALUES ('$nome', '$email', '$assunto', '$mensagem')";

if ($conn->query($sql) === TRUE) {
    // Registro bem-sucedido, redirecionar para a mesma página com uma mensagem
    header("Location: ../html/Index.php");
    exit(); // Certifique-se de sair após o redirecionamento
} else {
    echo "Erro ao Enviar: " . $conn->error;
}

$conn->close();
?>
