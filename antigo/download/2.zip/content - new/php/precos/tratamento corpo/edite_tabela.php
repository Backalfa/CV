<!DOCTYPE html>
<html>
    <head>
        <title>Beatriz Miranda Oriflame</title>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="website icon" type="png" href="../../../imgs/icontab.png" />
    </head>
    <body>
        <?php

        require('../../conecçao.php');


        // Verifica se a referência (nome) do registro foi passada como parâmetro
        if (isset($_GET['nome'])) {
            // Obtém a referência do registro a ser editado
            $nome = $_GET['nome'];

            // Exemplo de consulta SQL para buscar o registro no banco de dados
            $sql = "SELECT * FROM tratamentos_corpo WHERE nome = '$nome'";

            // Execute a consulta SQL e obtenha os dados do registro
            $result = $conn->query($sql);

            // Verifique se o registro foi encontrado
            if ($result->num_rows > 0) {
                // O registro foi encontrado, você pode recuperar os dados aqui

                // Exemplo de como exibir os dados em um formulário de edição
                while ($row = $result->fetch_assoc()) {
                    $preco = $row['preco'];
                    $tempo = $row['tempo'];

                    echo '
                        <h2>Editar Serviço Tratamentos Corpo</h2>
                        <p><b>Atenção:</b> Ao alterar o nome, não poderá usar simbolos ( + - ! ? etc)</p>
                        <form method="POST" action="atualizar_tabela.php">
                            <table>
                                <tr>
                                    <td>Nome:</td>
                                    <td><input type="text" name="nome" value="' . $nome . '"></td>
                                </tr>
                                <tr>
                                    <td>Preço:</td>
                                    <td><input type="text" name="preco" value="' . $preco . '"></td>
                                </tr>
                                <tr>
                                    <td>Tempo:</td>
                                    <td><input type="text" name="tempo" value="' . $tempo . '"></td>
                                </tr>
                                <tr>
                                    <td colspan="2">
                                        <button type="submit">Atualizar</button>
                                        <a href="javascript:history.back()"><button type="button">Voltar</button></a>
                                        <a href="../../../html/tabela_precos.php"><button type="button">Início</button></a>
                                    </td>
                                </tr>
                            </table>
                        </form>';
                }
            } else {
                echo 'Registro não encontrado.';
            }
        } else {
            echo "Referência do registro não fornecida.";
        }

        ?>
    </body>
</html>