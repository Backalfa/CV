<?php

require('../../conecçao.php');

    // Verifica se a referência (nome) do registro foi passada como parâmetro
    if (isset($_GET['nome'])) {
        // Obtém a referência do registro a ser editado
        $nome = $_GET['nome'];

    // Prepara a instrução SQL DELETE
    $sql = "DELETE FROM tratamentos_corpo WHERE nome = '$nome'";

    // Executa a instrução SQL DELETE
    if ($conn->query($sql) === TRUE) {
        // Redireciona o usuário de volta para a página onde a tabela é exibida
        header("Location: ../../../html/tabela_precos.php");
        exit;
    } else {
        echo "Erro ao excluir registro: " . $conn->error;
    }
} else {
    echo "Erro: referência não fornecida.";
}

// Fecha a conexão com o banco de dados
$conn->close();
?>
