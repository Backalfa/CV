<!DOCTYPE html>
<html>
    <head>
        <title>Beatriz Miranda Oriflame</title>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="website icon" type="png" href="../../../imgs/icontab.png" />
    </head>
    <body>
    <?php

    require('../../conecçao.php');

    // Verifica se os dados foram enviados por meio do método POST
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Obtém os valores atualizados dos campos do formulário
        $nome = $_POST['nome'];
        $preco = $_POST['preco'];
        $tempo = $_POST['tempo'];

        $sql = "UPDATE massagens SET nome = '$nome', preco = '$preco', tempo = '$tempo'";
        $sql .= " WHERE nome = '$nome'";

        

        // Execute a consulta SQL para atualizar o registro
        if ($conn->query($sql) === TRUE) {
            echo "Registro atualizado com sucesso.";
            echo '<br><button type="button" onclick="window.history.back()">Voltar</button>';
            echo '<a href="../../../html/tabela_precos.php"><button type="button">Início</button></a>';
        } else {
            echo "Erro ao atualizar o registro: " . $conn->error;
        }

        // Fecha a conexão com o banco de dados
        $conn->close();
    }
    ?>
    </body>
</html>
