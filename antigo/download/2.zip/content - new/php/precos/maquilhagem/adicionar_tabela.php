<?php

require('../../conecçao.php');

// Verifica se o formulário foi submetido
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Realize as validações e processamento dos dados enviados pelo formulário

    $nome = $_POST['nome'];
    $preco = $_POST['preco'];
    $tempo = $_POST['tempo'];

    // Consulta SQL para verificar se já existe um produto com a mesma referência
    $checkQuery = "SELECT nome FROM maquilhagem WHERE nome = '$nome'";
    $checkResult = $conn->query($checkQuery);

    if ($checkResult->num_rows > 0) {
        // Já existe um produto com a mesma referência
        echo "Já existe um produto com essa referência.";
    } else {

        // Escapa os caracteres especiais para evitar problemas de SQL Injection
        $nome = $conn->real_escape_string($nome);
        $preco = $conn->real_escape_string($preco);
        $tempo = $conn->real_escape_string($tempo);

        // Consulta SQL para inserir o novo produto na tabela, incluindo a imagem
        $sql = "INSERT INTO maquilhagem (nome, preco, tempo)
                VALUES ('$nome', '$preco', '$tempo')";

        // Executa a consulta SQL
        if ($conn->query($sql) === TRUE) {
            // O produto foi inserido com sucesso na tabela temporária
            echo "Serviço adicionado com sucesso.";
        } else {
            // Ocorreu um erro ao inserir o produto na tabela temporária
            echo "Erro ao adicionar o Serviço: " . $conn->error;
        }
    }

}
?>


<!DOCTYPE html>
<html>
    <head>
        <title>Beatriz Miranda Oriflame</title>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="website icon" type="png" href="../../../imgs/icontab.png" />

    </head>
    <body>
        <h2>Adicionar Serviço</h2>
        <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
            <table>
                <tr>
                    <td>Nome:</td>
                    <td><input type="text" name="nome"></td>
                </tr>
                <tr>
                    <td>Preço:</td>
                    <td><input type="text" name="preco"></td>
                </tr>
                
                <tr>
                    <td colspan="2">
                        <button type="submit">Adicionar</button>
                        <a href="javascript:history.back()"><button type="button">Voltar</button></a>
                        <a href="../../../html/tabela_precos.php"><button type="button">Início</button></a>
                    </td>
                </tr>
            </table>
        </form>
    </body>
</html>
