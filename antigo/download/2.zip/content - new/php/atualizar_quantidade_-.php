<?php
session_start();

// Verificar se a referência do produto foi fornecida
if (isset($_POST['referencia'])) {
  $referencia = $_POST['referencia'];

  // Remover a referência do carrinho
  if (($key = array_search($referencia, $_SESSION['carrinho'])) !== false) {
    unset($_SESSION['carrinho'][$key]);
    echo 'Referência removida do carrinho com sucesso.';
  } else {
    echo 'Referência não encontrada no carrinho.';
  }
} else {
  echo 'Referência do produto não fornecida.';
}
?>
