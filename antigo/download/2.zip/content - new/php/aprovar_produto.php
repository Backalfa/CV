<?php

require('conecçao.php');

// Verifica se o formulário foi submetido
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtém o ID do produto enviado pelo formulário
    $ref = $_POST['produto_ref'];

    // Consulta SQL para selecionar o produto da tabela temporária pelo ID
    $sql = "SELECT * FROM temp_produtos WHERE ref = '$ref'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // O produto foi encontrado na tabela temporária

        // Recupere os dados do produto
        $row = $result->fetch_assoc();
        $ref = $row['ref'];
        $nome = $row['nome'];
        $preco = $row['preco'];
        $preco_novo = $row['preco_novo'];
        $quantidade = $row['quantidade'];
        $homem = $row['homem'];
        $mulher = $row['mulher'];
        $categ = $row['categ'];
        $imagem = $row['imagem'];

        // Escapa os caracteres especiais para evitar problemas de SQL Injection
        $ref = $conn->real_escape_string($ref);
        $nome = $conn->real_escape_string($nome);
        $preco = $conn->real_escape_string($preco);
        $preco_novo = $conn->real_escape_string($preco_novo);
        $quantidade = $conn->real_escape_string($quantidade);
        $homem = $conn->real_escape_string($homem);
        $mulher = $conn->real_escape_string($mulher);
        $categ = $conn->real_escape_string($categ);
        $imagem = $conn->real_escape_string($imagem);

        // Consulta SQL para inserir o produto na tabela de produtos
        $insertQuery = "INSERT INTO produtos (ref, nome, preco, preco_novo, quantidade, homem, mulher, categ, imagem)
                        VALUES ('$ref', '$nome', '$preco', '$preco_novo', '$quantidade', '$homem', '$mulher', '$categ', '$imagem')";

        // Executa a consulta SQL para inserir o produto na tabela de produtos
        if ($conn->query($insertQuery) === TRUE) {
            // O produto foi aprovado e inserido na tabela de produtos

            // Consulta SQL para excluir o produto da tabela temporária
            $deleteQuery = "DELETE FROM temp_produtos WHERE ref = '$ref'";

            // Executa a consulta SQL para excluir o produto da tabela temporária
            if ($conn->query($deleteQuery) === TRUE) {
                // O produto foi excluído com sucesso da tabela temporária
                echo "Produto aprovado e adicionado à base de dados.";
            } else {
                // Ocorreu um erro ao excluir o produto da tabela temporária
                echo "Erro ao excluir o produto da tabela temporária: " . $conn->error;
            }
        } else {
            // Ocorreu um erro ao inserir o produto na tabela de produtos
            echo "Erro ao aprovar o produto: " . $conn->error;
        }
    } else {
        // O produto não foi encontrado na tabela temporária
        echo "Produto não encontrado na tabela temporária.";
    }
}

// Fecha a conexão com o banco de dados
$conn->close();

?>