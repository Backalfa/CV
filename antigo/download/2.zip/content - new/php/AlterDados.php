<?php
// Verificar se os dados foram enviados via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $dados = json_decode(file_get_contents('php://input'), true);

    // Recuperar os valores individuais
    $nome = $dados['nome'];
    $telemovel = $dados['telemovel'];
    $aniversario = $dados['aniversario'];
    $email = $dados['email'];
    $passe = $dados['passe'];


    require('conecçao.php');

    // Montar a query de atualização
    $sql = "UPDATE users SET nome = '$nome', email = '$email', telemovel = '$telemovel', aniversario = '$aniversario' WHERE email = '$email'";

    // Executar a query de atualização
    if ($conn->query($sql) === TRUE) {
        echo "Dados atualizados com sucesso.";
    } else {
        echo "Erro ao atualizar os dados: " . $conn->error;
    }

    $conn->close();
}
?>
