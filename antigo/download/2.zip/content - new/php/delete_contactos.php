<?php

require('conecçao.php');

// Verifica se a variável 'id' foi passada via GET
if (isset($_GET['id'])) {
  // Obtém o valor de 'id' da solicitação
  $id = $_GET['id'];
  // Prepara a instrução SQL DELETE
  $sql = "DELETE FROM contacto_index WHERE id = $id";

  // Executa a instrução SQL DELETE
  if ($conn->query($sql) === TRUE) {
    // Redireciona o usuário de volta para a página onde a tabela é exibida
    header("Location: ../html/Index.php");
    exit;
  } else {
    echo "Erro ao excluir registro: " . $conn->error;
  }

} else {
  echo "Erro: referência não fornecida.";
}
// Fecha a conexão com o banco de dados
$conn->close();
?>
