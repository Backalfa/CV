<?php

    session_start(); // Iniciar a sessão

    require('../php/conecçao.php');

    // Para saber se está logado
    if (!isset($_SESSION['user_email'])) {
        echo '<script>console.log("Sem Sessão Iniciada!")</script>';
    }else{
        echo '<script>console.log("Bem vindo, '. $_SESSION['user_email'] . '!")</script>';
        echo '<script>console.log("O user é '. $_SESSION['is_admin'] . ' !")</script>';
    }

    // Query para selecionar todos os produtos
    $sql = "SELECT * FROM produtos";
    $result = $conn->query($sql);

    // Obtém a URL atual
    $url = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

    // Analisa os parâmetros da URL
    parse_str(parse_url($url, PHP_URL_QUERY), $params);

    // Obtém o valor do parâmetro 'categoria' e verifica se está vazio
    $categoria = isset($params['categoria']) ? $params['categoria'] : '';
    if ($categoria === '') {
        $categoria = 'Todas as categorias';
    }

    // Obtém o valor do parâmetro 'genero'
    $genero = isset($params['genero']) ? $params['genero'] : '';
    if ($genero === '') {
        $genero = 'Todos os generos';
    }else if ($genero === 'homem'){
        $genero = 'Masculino';
    }else if ($genero === 'mulher'){
        $genero = 'Feminino';
    }

?>


<!DOCTYPE html>
<html>
    <head>
        <title>Beatriz Miranda Oriflame</title>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <!-- FALTA ADICIONAR PARA A PESQUISA-->
        <link rel="website icon" type="png" href="../imgs/icontab.png" />
        <link rel="stylesheet" href="../css/base_main/base_catalogo.css" />
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto" />
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <!-- JQUERY -->
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <style>
            *{
                font-family: 'Merriweather', serif;
            }
        </style>
    </head>
    <body class="w3-content" style="max-width: 1200px;">
        <!-- Sidebar/menu -->
        <nav class="w3-sidebar w3-bar-block w3-white w3-collapse w3-top" style="z-index: 3; width: 250px;" id="mySidebar">
            <div class="w3-container w3-display-container w3-padding-16">
                <i onclick="w3_close()" class="fa fa-remove w3-hide-large w3-button w3-display-topright"></i>
                <img src="../imgs/LOGO.jpg" style="width: 100%;" />
            </div>
            <a class="w3-bar-item w3-button w3-padding" href="Index.php">Início</a>
            <a class="w3-bar-item w3-button w3-padding" href="#">Sobre Nós</a>
            <?php
                // Para saber se tem sessão
                if (!isset($_SESSION['user_email'])) {
                    // Sem Sessão
                }else{
                    // Para sair da sessão
                    echo '<a class="w3-bar-item w3-button w3-padding" href="tabela_precos.php">Serviços</a>';
                }
            ?>
            <a class="w3-bar-item w3-button w3-padding" href="#Contact">Contacte-nos</a>
            <a onclick="myAccFunc()" href="javascript:void(0)" class="w3-button w3-block w3-white w3-left-align" id="myBtn">
                Catálogo <i class="fa fa-caret-down"></i>
            </a>
            <div id="demoAcc" class="w3-bar-block w3-hide w3-padding-large w3-medium w3-show">
                <a href="catalogo.php?categoria=" class="w3-bar-item w3-button">Catálogo</a>
                <a href="https://pt.oriflame.com/products/digital-catalogue-current?PageNumber=1" class="w3-bar-item w3-button">Catálogo - Oriflame</a>
            </div>
            <a href="https://pt.oriflame.com/catalogue?cataloguecode=Norrsken%2F2023-norrsken-spring" class="w3-bar-item w3-button w3-padding" target="_blank">NORRSKEN - Jóias</a>
            <a href="https://pt.oriflame.com/catalogue?cataloguecode=FlyerC04&PageNumber=1" class="w3-bar-item w3-button w3-padding" target="_blank">Oportunidades</a>
        </nav>

        <!-- Top menu on small screens -->
        <header class="w3-bar w3-top w3-hide-large w3-black w3-xlarge">
            <div class="w3-bar-item w3-padding-24 w3-wide"></div>
            <a href="javascript:void(0)" class="w3-bar-item w3-button w3-padding-24 w3-right" onclick="w3_open()"><i class="fa fa-bars"></i></a>
        </header>

        <!-- Overlay effect when opening sidebar on small screens -->
        <div class="w3-overlay w3-hide-large" onclick="w3_close()" style="cursor: pointer;" title="close side menu" id="myOverlay"></div>

        <!-- !PAGE CONTENT! -->
        <div class="w3-main" style="margin-left: 250px;">
            <!-- Push down content on small screens -->
            <div class="w3-hide-large" style="margin-top: 83px;"></div>

            <!-- TOP HEADER / NAV BAR -->
            <header class="w3-container w3-xlarge">
                <p class="w3-right gap">
                    <script src="https://cdn.lordicon.com/bhenfmcm.js"></script>
                    <span style="position: relative; color: red;">
                    <!-- Conta Carrinho -->
                    <?php
                        if (isset($_SESSION["carrinho"])) {
                            if (count($_SESSION["carrinho"]) != 0) {
                                echo count($_SESSION["carrinho"]);
                            } else {
                                echo '';
                            }
                        } else {
                            echo '';
                        }
                        ?>
                    </span>
                    <?php
                    // Para saber se tem sessão
                    if (!isset($_SESSION['user_email'])) {
                        // Para fazer Log In
                        echo '<a class="nav-link" href="../login.html">Log In</a>';
                    } else {
                        // Para sair da sessão
                        echo '
                            <a href="main_carrinho.php" ><lord-icon
                                src="https://cdn.lordicon.com/lqsduwhb.json"
                                trigger="hover"
                                colors="primary:#000000"
                                style="width:40px;height:40px">
                            </lord-icon></a>
                            <a class="nav-link" href="#" onclick="confirmLogout()">Sair</a>';
                    }
                    ?>
                </p>
            </header>


            <!-- Image header -->
            <div class="w3-display-container w3-container">
                <img class="w3-hide-small" src="../imgs/top-view-salts-cream-container.jpg" alt="logo_pagina_centro" style="width: 100%;" />
                <img class="w3-hide-large w3-hide-medium" src="../imgs/top-view-salts-cream-container.jpg" alt="logo_pagina_centro" style="width: 100%;" />
                <div class="w3-display-topleft w3-text-black" style="padding: 24px 48px;">
                    <h1 class="w3-jumbo w3-hide-small">Beatriz Miranda</h1>
                    <h1 class="w3-hide-large w3-hide-medium">Beatriz Miranda</h1>
                    <p><a href="marcacao.php" class="w3-button w3-black w3-padding-large w3-large">AGENDA A TUA MARCAÇÃO!</a></p>
                </div>
            </div>

            <!-- MAIN CONTENT -->
            
            <h1 class="w3-center" style="margin-top: 40px;">Lista de Produtos com Entrega Imediata</h1>

            
            <?php
                // Para saber se é admin
                if (isset($_SESSION['user_email']) && ($_SESSION['is_admin'] == 1)) {
                    echo '<div id="content_value_admin" align="center">
                            <input type="text" id="pesq" placeholder="Nome ou Referência" style="margin-top: 40px"><br>
                            <button type="button" class="w3-button w3-green w3-small" onclick="addProduct()" style="margin-top: 40px">
                                <span class="w3-button-icon">
                                    <i class="fa fa-plus"></i>
                                </span>
                                Adicionar Produto
                            </button>
                            <table class="w3-table w3-striped w3-bordered" id="tabela" style="margin-top: 60px">
                                <thead>
                                    <tr class="w3-light-grey">
                                        <th>Referência</th>
                                        <th>Nome</th>
                                        <th>Preço Antigo</th>
                                        <th>Preço Atual</th>
                                        <th>Quantidade</th>
                                        <th id="homem">Homem</th>
                                        <th id="mulher">Mulher</th>
                                        <th>Categoria</th>
                                        <th>Imagem</th>
                                        <th>Ações</th>
                                    </tr>
                                </thead>
                                <tbody>';

                    require('../php/conecçao.php');

                            // Executar consulta SQL para recuperar os registros da tabela
                            $sql = "SELECT * FROM produtos";
                            $result = $conn->query($sql);

                            // Verificar se existem registros retornados
                            if ($result->num_rows > 0) {
                                // Iterar sobre os registros e exibir as informações
                                while($row = $result->fetch_assoc()) {
                                    echo '<tr>';
                                    echo "<td>" . $row["ref"] . "</td>";
                                    echo "<td>" . $row["nome"] . "</td>";
                                    echo "<td>" . $row["preco"] . "€ </td>";
                                    echo "<td>" . $row["preco_novo"] . "€ </td>";
                                    echo "<td>" . $row["quantidade"] . "</td>";
                                    echo "<td>" . $row["homem"] . "</td>";
                                    echo "<td>" . $row["mulher"] . "</td>";
                                    echo "<td>" . $row["categ"] . "</td>";
                                    echo "<td><img src='data:image/jpeg;base64," . base64_encode($row['imagem']) . "' alt='Imagem do Produto' style='width: 100px;'></td>";
                                    echo '<td>
                                                <button type="button" class="w3-button w3-blue w3-small" onclick="editRecord(\'' . $row["ref"] . '\')">
                                                <span class="w3-button-icon">
                                                    <i class="fa fa-pencil"></i>
                                                </span>
                                                Editar
                                                </button>
                                                <button type="button" class="w3-button w3-red w3-small" onclick="deleteRecord(\'' . $row["ref"] . '\')">
                                                <span class="w3-button-icon">
                                                    <i class="fa fa-trash"></i>
                                                </span>
                                                Excluir
                                                </button>
                                            </td>
                                        ';
                                    echo "</tr>";
                                }
                                
                              } else {
                                echo "<tr><td colspan='9'>Nenhum resultado encontrado.</td></tr>";
                              }
                        
                              // Fecha a conexão com o banco de dados
                              $conn->close();
                              echo '
                                    </tbody>
                                </table>
                            </div>
                        
                            <script>
                                function addProduct() {
                                    // Redireciona para a página de adicionar produto
                                    window.location.href = "../php/adicionar_produto.php";
                                }
                                function editRecord(ref) {
                                    // Redireciona para a página de edição do registro com a referência especificada
                                    window.location.href = "../php/edite_catalogo.php?ref=" + ref;
                                }
                                
                                function deleteRecord(ref) {
                                    // Exibe uma caixa de diálogo de confirmação antes de excluir o registro
                                    if (confirm("Tem certeza que deseja excluir este registro?")) {
                                        // Redireciona para o arquivo que processa a exclusão do registro
                                        window.location.href = "../php/delete_catalogo.php?ref=" + ref;
                                    }
                                }
                            </script>
                        ';
                }else{
                    // ADICIONAR FILTRO 
                    
                        // busca as categorias disponíveis
                        $sql_categorias = "SELECT DISTINCT categ FROM produtos ORDER BY categ";
                        $result_categorias = $conn->query($sql_categorias);
                        $categorias = array();
                        if ($result_categorias->num_rows > 0) {
                            while($row_categorias = $result_categorias->fetch_assoc()) {
                                $categorias[] = $row_categorias["categ"];
                            }
                        }

                        echo '
                        <p><u>Filtrado para:</u> ' . $categoria . ' e ' . $genero . '</p>
                        <table style="width:100%">
                            <thead class="toggle filtro">
                                <tr>
                                    <th style="float:left">Filtros:</th>
                                </tr>
                            </thead>
                            <tbody id="hide">
                                <tr>
                                    <td>
                                        <form method="get">
                                            <label for="categoria">Categoria:</label>
                                            <select id="categoria" name="categoria">
                                                <option value="">Todas as categorias</option>';
                        
                                        foreach ($categorias as $categoria) {
                                            echo '<option value="' . $categoria . '">' . $categoria . '</option>';
                                        }
                                        
                                        echo '
                                            </select>
                        
                                            <label for="genero">Gênero:</label>
                                            <select id="genero" name="genero">
                                                <option value="">Todos os generos </option>
                                                <option value="homem">Masculino</option>
                                                <option value="mulher">Feminino</option>
                                            </select>
                        
                                            <button type="submit">Filtrar</button>
                                        </form>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        
                        <!-- Contagem de Itens -->
                        <p><span id="countitens"></span></p>';
                    

                    // Para saber se tem sessão
                    if (!isset($_SESSION['user_email'])) {
                    // Sem Sessão

                        // monta a consulta SQL com filtro por categoria (se houver)
                        $sql = "SELECT * FROM produtos";
                        if (!empty($_GET['categoria'])) {
                            $categoria = $conn->real_escape_string($_GET['categoria']);
                            $sql .= " WHERE categ = '$categoria'";
                        }

                        // monta a consulta SQL com filtro por genero (se houver)
                        if (!empty($_GET['genero']) && ($_GET['genero'] == 'homem' || $_GET['genero'] == 'mulher')) {
                            $genero = $_GET['genero'];
                            if (strpos($sql, 'WHERE') !== false) {
                                $sql .= " AND $genero = 1";
                            } else {
                                $sql .= " WHERE $genero = 1";
                            }
                        }

                        $sql .= " ORDER BY nome";
                        $result = $conn->query($sql);

                
                        // número máximo de elementos por linha
                        $elementos_por_linha = 4;

                        $contador = 0;

                        // Loop através de todos os produtos
                        while($row = $result->fetch_assoc()) {

                            // Verifica se o produto é para homem ou mulher
                            if ($row["homem"] == 1 && $row["mulher"] == 1){
                                $genero = '<span class="w3-tag w3-display-topright" style="background-color: transparent;">
                                                <span style="background-color: rgb(155, 201, 231); border-radius: 50%;padding: 5px;">H</span>
                                                <span style="background-color: rgb(252, 166, 233); border-radius: 50%;padding: 5px;">M</span>
                                            </span>';
                            }elseif ($row["homem"] == 1 || $row["mulher"] == 1){
                                if ($row["homem"] == 1) {
                                    $genero = '<span class="w3-tag w3-display-topright" style="background-color: transparent;">
                                                    <span style="background-color: rgb(155, 201, 231); border-radius: 50%;padding: 5px;">H</span>
                                                </span>';
                                } elseif ($row["mulher"] == 1) {
                                    $genero = '<span class="w3-tag w3-display-topright" style="background-color: transparent;">
                                                    <span style="background-color: rgb(252, 166, 233); border-radius: 50%;padding: 5px;">M</span>
                                                </span>';
                                }
                            } else {
                                $genero = "";
                            }
                            
                            // Se a quantidade do produto for 0 então está vendido
                            if ($row["quantidade"] == 0){
                                $quantidade = '<span class="w3-tag" style="position: absolute; top: 0;left:0;">Vendido!</span>';
                                $nquantidade = '';
                            } else {
                                $quantidade = '<span class="w3-tag" style="position: absolute; top: 0;left:0;"></span>';
                                $nquantidade = $row["quantidade"];
                            }

                            // Botão carrinho de compras

                            if ($quantidade == '<span class="w3-tag" style="position: absolute; top: 0;left:0;">Vendido!</span>') {
                                $carrinho = '';
                            }else{
                                $carrinho = '<span class="" style="position: absolute; bottom: 0;left: 0;">
                                            <button class="w3-button w3-teal w3-round-large" type="submit" name="adicionar_carrinho" value="' . $row["ref"] . '">
                                                <lord-icon
                                                    src="https://cdn.lordicon.com/udbbfuld.json"
                                                    trigger="hover"
                                                    colors="primary:#000000"
                                                    style="width:20px;height:20px">
                                                </lord-icon> Carrinho
                                                </button>
                                            </span>';
                            }

                            // Se o preço novo é mais baixo que o antigo o artigo está em promoção
                            if ($row["preco"] > $row["preco_novo"]){
                                $prom = '';
                                $prompreco = '<b>'.$row["preco"].' €</b></p>';
                            } else {
                                $prom = '';
                                $prompreco = '<b>'.$row["preco"].' €</b></p>';
                            }

                            // Incrementa o contador de elementos
                            $contador++;

                            // Adiciona a div de abertura a cada oito elementos
                            if ($contador % 4 == 1) {
                                echo '<div class="w3-row">';
                            }

                            // Exibe os dados do produto em uma linha da tabela
                            echo '<div class="w3-col l3 s6 count">
                                    <div class="w3-container">
                                        <div class="w3-display-container">
                                            <img src="data:image/jpeg;base64,' . base64_encode($row['imagem']) . '" style="width: 90%;" />
                                            <span class="w3-tag" style="position: absolute; bottom: 0;"><div></div></span>
                                            '.$genero.'
                                        </div>
                                        <div>
                                            <p><span style="font-size: smaller;">Ref: '.$row["ref"].'</span><br />
                                            '.$row["nome"].'<br />
                                        </div>
                                    </div>
                                </div>';


                            // Adiciona a div de fecho a cada oito elementos
                            if ($contador % 4 == 0) {
                                echo '</div>';
                            }
                            
                        }
                        // fecha a última linha
                        echo '</div>';
                        
                        for ($i = 0; $i < $contador % 2; $i++) {
                            echo '</div>';
                        }

                    }else{
                        // Com Sessão
                        
                        // monta a consulta SQL com filtro por categoria (se houver)
                        $sql = "SELECT * FROM produtos";
                        if (!empty($_GET['categoria'])) {
                            $categoria = $conn->real_escape_string($_GET['categoria']);
                            $sql .= " WHERE categ = '$categoria'";
                        }

                        // monta a consulta SQL com filtro por genero (se houver)
                        if (!empty($_GET['genero']) && ($_GET['genero'] == 'homem' || $_GET['genero'] == 'mulher')) {
                            $genero = $_GET['genero'];
                            if (strpos($sql, 'WHERE') !== false) {
                                $sql .= " AND $genero = 1";
                            } else {
                                $sql .= " WHERE $genero = 1";
                            }
                        }

                        $sql .= " ORDER BY nome";
                        $result = $conn->query($sql);

                
                        // número máximo de elementos por linha
                        $elementos_por_linha = 4;

                        $contador = 0;

                        // Loop através de todos os produtos
                        while($row = $result->fetch_assoc()) {

                            // Verifica se o produto é para homem ou mulher
                            if ($row["homem"] == 1 && $row["mulher"] == 1){
                                $genero = '<span class="w3-tag w3-display-topright" style="background-color: transparent;">
                                                <span style="background-color: rgb(155, 201, 231); border-radius: 50%;padding: 5px;">H</span>
                                                <span style="background-color: rgb(252, 166, 233); border-radius: 50%;padding: 5px;">M</span>
                                            </span>';
                            }elseif ($row["homem"] == 1 || $row["mulher"] == 1){
                                if ($row["homem"] == 1) {
                                    $genero = '<span class="w3-tag w3-display-topright" style="background-color: transparent;">
                                                    <span style="background-color: rgb(155, 201, 231); border-radius: 50%;padding: 5px;">H</span>
                                                </span>';
                                } elseif ($row["mulher"] == 1) {
                                    $genero = '<span class="w3-tag w3-display-topright" style="background-color: transparent;">
                                                    <span style="background-color: rgb(252, 166, 233); border-radius: 50%;padding: 5px;">M</span>
                                                </span>';
                                }
                            } else {
                                $genero = "";
                            }
                            
                            // Se a quantidade do produto for 0 então está vendido
                            if ($row["quantidade"] == 0){
                                $quantidade = '<span class="w3-tag" style="position: absolute; top: 0;left:0;">Vendido!</span>';
                                $nquantidade = '';
                            } else {
                                $quantidade = '<span class="w3-tag" style="position: absolute; top: 0;left:0;"></span>';
                                $nquantidade = $row["quantidade"];
                            }

                            // Se o preço novo é mais baixo que o antigo o artigo está em promoção
                            if ($row["preco"] > $row["preco_novo"]){
                                $prom = '<span class="w3-tag w3-display-topleft" style="background-color: rgb(255, 0, 0);">Promoção</span>';
                                $prompreco = '<s>'.$row["preco"].'€</s><b><span style="color:rgb(255, 0, 0); margin-left: 5%;">'.$row["preco_novo"].'€</span></b>';
                            } else {
                                $prom = '';
                                $prompreco = '<b>'.$row["preco"].' €</b></p>';
                            }

                            // Botão carrinho de compras
                            $carrinho = '';

                            if ($nquantidade != 0) {
                                // Verifica a quantidade de ocorrências da referência no carrinho
                                $referencia = $row["ref"];
                                $quantidade_no_carrinho = 0;

                                if (isset($_SESSION["carrinho"]) && is_array($_SESSION["carrinho"])) {
                                    $quantidade_no_carrinho = array_count_values($_SESSION["carrinho"])[$referencia] ?? 0;
                                }

                                // Reduz a quantidade localmente com base no número de ocorrências no carrinho
                                $nquantidade -= $quantidade_no_carrinho;

                                if ($nquantidade > 0) {
                                    $carrinho = '<span class="" style="position: absolute; bottom: 0;left: 0;">
                                                    <button class="w3-button w3-teal w3-round-large" type="submit" name="adicionar_carrinho" value="' . $row["ref"] . '">
                                                        <lord-icon
                                                            src="https://cdn.lordicon.com/udbbfuld.json"
                                                            trigger="hover"
                                                            colors="primary:#000000"
                                                            style="width:20px;height:20px">
                                                        </lord-icon> Carrinho
                                                    </button>
                                                </span>';
                                }
                            } else {
                                $carrinho = '';
                            }






                            // Incrementa o contador de elementos
                            $contador++;

                            // Adiciona a div de abertura a cada oito elementos
                            if ($contador % 4 == 1) {
                                echo '<div class="w3-row">';
                            }

                            // Exibe os dados do produto em uma linha da tabela
                            echo '<div class="w3-col l3 s6 count">
                                    <div class="w3-container">
                                        <form method="post" action="../php/adicionar_carrinho.php">
                                            <div class="w3-display-container">'. $quantidade . $prom .'
                                                <img src="data:image/jpeg;base64,' . base64_encode($row['imagem']) . '" style="width: 90%;" />
                                                ' . $carrinho . '
                                                <span class="w3-tag" style="position: absolute; bottom: 0;"><div>'. $nquantidade .'</div></span>
                                                '.$genero.'
                                            </div>
                                            <div>
                                                <p><span style="font-size: smaller;">Ref: '.$row["ref"].'</span><br />
                                                '.$row["nome"].'<br />
                                                '. $prompreco .'
                                            </div>
                                        </form>
                                    </div>
                                </div>';

                            // Adiciona a div de fecho a cada oito elementos
                            if ($contador % 4 == 0) {
                                echo '</div>';
                            }
                            
                        }
                        // fecha a última linha
                        echo '</div>';
                        
                        for ($i = 0; $i < $contador % 2; $i++) {
                            echo '</div>';
                        }
                        
                    }
                };
            ?>
    
            <?php
                // Para saber se é admin
                if (isset($_SESSION['user_email']) && ($_SESSION['is_admin'] == 1)) {
                }else{
                    echo '<!-- Footer -->
                            <footer class="w3-hide-small w3-hide-medium w3-padding-64 w3-light-grey w3-small w3-center" id="footer" style="margin-left: 250px;">
                                <div class="w3-row-padding">
                                    <div class="w3-col s12 m12 l8">
                                        <h2 id="Contact">Contactos</h2>
                                        <p>Questões? Vai em frente.</p>
                                        <form action="../php/contacto.php" method="POST">
                                            <p><input class="w3-input w3-border" type="text" placeholder="Nome" name="Name" required="" /></p>
                                            <p><input class="w3-input w3-border" type="text" placeholder="Email" name="Email" required="" /></p>
                                            <p><input class="w3-input w3-border" type="text" placeholder="Assunto" name="Subject" required="" /></p>
                                            <p><input class="w3-input w3-border" type="text" placeholder="Messagem" name="Message" required="" /></p>
                                            <button type="submit" class="w3-button w3-block w3-black">Enviar</button>
                                        </form>
                                    </div>
                    
                                    <div class="w3-col s12 m12 l4">
                                        <h2>Loja</h2>
                                        <p><i class="fa fa-fw fa-map-marker"></i> Beatriz Miranda</p>
                                        <p><i class="fa fa-fw fa-phone"></i> 0044123123</p>
                                        <p><i class="fa fa-fw fa-envelope"></i> beatrizmiranda@hotmail.com</p>
                                        <br />
                                    </div>
                    
                                    <!-- Redes Sociais -->
                                    <!--
                                    <div class="w3-col s12 m12 l12 gap" style="margin-top:60px;display: flex; justify-content: center;">
                                        <i class="fa fa-facebook-official w3-hover-opacity w3-xxlarge"></i>
                                        <i class="fa fa-instagram w3-hover-opacity w3-xxlarge"></i>
                                        <i class="fa fa-snapchat w3-hover-opacity w3-xxlarge"></i>
                                        <i class="fa fa-pinterest-p w3-hover-opacity w3-xxlarge"></i>
                                        <i class="fa fa-twitter w3-hover-opacity w3-xxlarge"></i>
                                        <i class="fa fa-linkedin w3-hover-opacity w3-xxlarge"></i>
                                    </div>-->
                                </div>
                            </footer>

                            <footer class="w3-hide-large w3-padding-64 w3-light-grey w3-small w3-center" id="footer">
                                <div class="w3-row-padding">
                                    <div class="w3-col s12 m12 l8">
                                        <h2 id="Contact">Contactos</h2>
                                        <p>Questões? Vai em frente.</p>
                                        <form action="../php/contacto.php" method="POST">
                                            <p><input class="w3-input w3-border" type="text" placeholder="Nome" name="Name" required="" /></p>
                                            <p><input class="w3-input w3-border" type="text" placeholder="Email" name="Email" required="" /></p>
                                            <p><input class="w3-input w3-border" type="text" placeholder="Assunto" name="Subject" required="" /></p>
                                            <p><input class="w3-input w3-border" type="text" placeholder="Messagem" name="Message" required="" /></p>
                                            <button type="submit" class="w3-button w3-block w3-black">Enviar</button>
                                        </form>
                                    </div>
                    
                                    <div class="w3-col s12 m12 l4">
                                        <h2>Loja</h2>
                                        <p><i class="fa fa-fw fa-map-marker"></i> Beatriz Miranda</p>
                                        <p><i class="fa fa-fw fa-phone"></i> 0044123123</p>
                                        <p><i class="fa fa-fw fa-envelope"></i> beatrizmiranda@hotmail.com</p>
                                        <br />
                                    </div>
                    
                                    <!-- Redes Sociais -->
                                    <!--
                                    <div class="w3-col s12 m12 l12 gap" style="margin-top:60px;display: flex; justify-content: center;">
                                        <i class="fa fa-facebook-official w3-hover-opacity w3-xxlarge"></i>
                                        <i class="fa fa-instagram w3-hover-opacity w3-xxlarge"></i>
                                        <i class="fa fa-snapchat w3-hover-opacity w3-xxlarge"></i>
                                        <i class="fa fa-pinterest-p w3-hover-opacity w3-xxlarge"></i>
                                        <i class="fa fa-twitter w3-hover-opacity w3-xxlarge"></i>
                                        <i class="fa fa-linkedin w3-hover-opacity w3-xxlarge"></i>
                                    </div>-->
                                </div>
                            </footer>
                    ';
                }
            ?>
            <!-- End page content -->
        </div>

        <!-- Accordion -->
        <script>
            function myAccFunc() {
                var x = document.getElementById("demoAcc");
                if (x.className.indexOf("w3-show") == -1) {
                    x.className += " w3-show";
                } else {
                    x.className = x.className.replace(" w3-show", "");
                }
            }

            // Open and close sidebar
            function w3_open() {
                document.getElementById("mySidebar").style.display = "block";
                document.getElementById("myOverlay").style.display = "block";
            }

            function w3_close() {
                document.getElementById("mySidebar").style.display = "none";
                document.getElementById("myOverlay").style.display = "none";
            }
        </script>
        <!-- Script para contar o itens -->
        <script>
            let count = document.getElementsByClassName("count").length;

            console.log(count);
            document.getElementById("countitens").innerHTML = count + " itens";

        </script>
        <!-- MOSTRAR OS FILTROS -->
        <script>
            $(document).ready(function() {
            // esconder todos os tbody
            $('#hide').hide();
        
            // adicionar evento de clique para cada thead
            $('thead.toggle').click(function() {
                // encontrar o tbody correspondente usando o próximo elemento
                var tbody = $(this).next('tbody');
        
                // alternar o estado de exibição do tbody
                tbody.slideToggle(200);
        
                // adicionar / remover a classe 'ativo' ao elemento clicado
                $(this).toggleClass('ativo');
            });
            });
        </script>
        <!-- LOG OUT -->
        <script>
            function confirmLogout() {
                if (confirm("Você tem certeza que deseja sair?")) {
                    window.location.href = "../php/LogOut.php";
                }
            }
        </script>
        <!-- ADMIN -->
        <script src="../js/catalogo_admin.js"></script>














        <!-- Script Teste -->
        <script>
            // Recupera os itens do carrinho
            var carrinho = <?php echo json_encode($_SESSION["carrinho"]); ?>;

            // Exibe o conteúdo do carrinho no console
            console.log(carrinho);
            console.log(carrinho.length);

        </script>
    </body>
</html>

