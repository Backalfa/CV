<?php

    session_start(); // Iniciar a sessão

    require('../php/conecçao.php');

    // Para saber se está logado
    if (!isset($_SESSION['user_email'])) {
        echo '<script>console.log("Sem Sessão Iniciada!")</script>';
        header("Location: ../login.html");
        exit();
    }else{
        echo '<script>console.log("Bem vindo, '. $_SESSION['user_email'] . '!")</script>';
        echo '<script>console.log("O user é '. $_SESSION['is_admin'] . ' !")</script>';
    }
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Beatriz Miranda Oriflame</title>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <!-- FALTA ADICIONAR PARA A PESQUISA-->
        <link rel="website icon" type="png" href="../imgs/icontab.png" />
        <link rel="stylesheet" href="../css/base_main/base_marca.css" />
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto" />
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <style>
            *{
                font-family: 'Merriweather', serif;
            }
        </style>
    </head>
    <body class="w3-content" style="max-width: 1200px;">
        <!-- Sidebar/menu -->
        <nav class="w3-sidebar w3-bar-block w3-white w3-collapse w3-top" style="z-index: 3; width: 250px;" id="mySidebar">
            <div class="w3-container w3-display-container w3-padding-16">
                <i onclick="w3_close()" class="fa fa-remove w3-hide-large w3-button w3-display-topright"></i>
                <img src="../imgs/LOGO.jpg" style="width: 100%;" />
            </div>
            <a class="w3-bar-item w3-button w3-padding" href="Index.php">Início</a>
            <a class="w3-bar-item w3-button w3-padding" href="#">Sobre Nós</a>
            <?php
                // Para saber se tem sessão
                if (!isset($_SESSION['user_email'])) {
                    // Sem Sessão
                }else{
                    // Para sair da sessão
                    echo '<a class="w3-bar-item w3-button w3-padding" href="tabela_precos.php">Serviços</a>';
                }
            ?>
            <a class="w3-bar-item w3-button w3-padding" href="#Contact">Contacte-nos</a>
            <a onclick="myAccFunc()" href="javascript:void(0)" class="w3-button w3-block w3-white w3-left-align" id="myBtn">
                Catálogo <i class="fa fa-caret-down"></i>
            </a>
            <div id="demoAcc" class="w3-bar-block w3-hide w3-padding-large w3-medium w3-show">
                <a href="catalogo.php?categoria=" class="w3-bar-item w3-button">Catálogo</a>
                <a href="https://pt.oriflame.com/products/digital-catalogue-current?PageNumber=1" class="w3-bar-item w3-button">Catálogo - Oriflame</a>
            </div>
            <a href="https://pt.oriflame.com/catalogue?cataloguecode=Norrsken%2F2023-norrsken-spring" class="w3-bar-item w3-button w3-padding" target="_blank">NORRSKEN - Jóias</a>
            <a href="https://pt.oriflame.com/catalogue?cataloguecode=FlyerC04&PageNumber=1" class="w3-bar-item w3-button w3-padding" target="_blank">Oportunidades</a>
        </nav>

        <!-- Top menu on small screens -->
        <header class="w3-bar w3-top w3-hide-large w3-black w3-xlarge">
            <div class="w3-bar-item w3-padding-24 w3-wide"></div>
            <a href="javascript:void(0)" class="w3-bar-item w3-button w3-padding-24 w3-right" onclick="w3_open()"><i class="fa fa-bars"></i></a>
        </header>

        <!-- Overlay effect when opening sidebar on small screens -->
        <div class="w3-overlay w3-hide-large" onclick="w3_close()" style="cursor: pointer;" title="close side menu" id="myOverlay"></div>

        <!-- !PAGE CONTENT! -->
        <div class="w3-main" style="margin-left: 250px;">
            <!-- Push down content on small screens -->
            <div class="w3-hide-large" style="margin-top: 83px;"></div>

            <!-- TOP HEADER / NAV BAR -->
            <header class="w3-container w3-xlarge">
                <p class="w3-right gap">
                    <script src="https://cdn.lordicon.com/bhenfmcm.js"></script>
                    <?php
                    // Para saber se tem sessão
                    if (!isset($_SESSION['user_email'])) {
                        // Para fazer Log In
                        echo '<a class="nav-link" href="../login.html">Log In</a>';
                    } else {
                        // Para sair da sessão
                        echo '
                            <a href="user.php" ><lord-icon
                            src="https://cdn.lordicon.com/hbvyhtse.json"
                            trigger="hover"
                            colors="primary:#000000"
                            style="width:40px;height:40px">
                        </lord-icon>';
                    }
                    ?>
                    <span style="position: relative; color: red;">
                    <!-- Conta Carrinho -->
                    <?php
                        if (isset($_SESSION["carrinho"])) {
                            if (count($_SESSION["carrinho"]) != 0) {
                                echo count($_SESSION["carrinho"]);
                            } else {
                                echo '';
                            }
                        } else {
                            echo '';
                        }
                        ?>
                    </span>
                    <?php
                    // Para saber se tem sessão
                    if (!isset($_SESSION['user_email'])) {
                        // Para fazer Log In
                        echo '<a class="nav-link" href="../login.html">Log In</a>';
                    } else {
                        // Para sair da sessão
                        echo '
                            <a href="main_carrinho.php" ><lord-icon
                                src="https://cdn.lordicon.com/lqsduwhb.json"
                                trigger="hover"
                                colors="primary:#000000"
                                style="width:40px;height:40px">
                            </lord-icon></a>
                            <a class="nav-link" href="#" onclick="confirmLogout()">Sair</a>';
                    }
                    ?>
                </p>
            </header>

            <!-- Image header -->
            <div class="w3-display-container w3-container">
                <img class="w3-hide-small" src="../imgs/top-view-salts-cream-container.jpg" alt="logo_pagina_centro" style="width: 100%;" />
                <img class="w3-hide-large w3-hide-medium" src="../imgs/top-view-salts-cream-container.jpg" alt="logo_pagina_centro" style="width: 100%;" />
                <div class="w3-display-topleft w3-text-black" style="padding: 24px 48px;">
                    <h1 class="w3-jumbo w3-hide-small">Beatriz Miranda</h1>
                    <h1 class="w3-hide-large w3-hide-medium">Beatriz Miranda</h1>
                    <p><a href="marcacao.php" class="w3-button w3-black w3-padding-large w3-large">AGENDA A TUA MARCAÇÃO!</a></p>
                </div>
            </div>

            <!-- Content -->
            <div class="w3-padding-64 w3-small w3-center" style="margin-top:80px;">
                <div class="w3-row-padding">
                    <div class="w3-col l4 s4">
                        <img src="../imgs/perfil/men.png" style="width:100px;height:100px;">
                            <button class="w3-button w3-block w3-dark-grey">Editar Perfil</button>
                    </div>
                    <div class="w3-col l4 s4">
                        nome e ultima marcação (data e hora)
                    </div>
                    <div class="w3-col l4 s4">
                        <div class="w3-container w3-green">
                            <p>Visitas Acomuladas</p>
                            <hr>
                            <p>Faltam 3 visitas para ganhar</p>
                        </div>
                    </div>
                </div>
                <hr>
                <div class="w3-row-padding">
                    <div class="w3-col l6 s6">
                        <form class="login-form" action="../php/AlterDados.php" method="post">
                            <table id="notificacao">
                                <tr>
                                    <th>Dados da Conta:</th>
                                </tr>
                                <tr>
                                    <td>Nome:</td>
                                    <td><input id="nome" type="text" value="<?php echo $_SESSION['user_name']; ?>" readonly></td>
                                </tr>
                                <tr>
                                    <td>Telemóvel:</td>
                                    <td><input id="telemovel" type="tel" value="<?php echo $_SESSION['user_tele']; ?>" readonly></td>
                                </tr>
                                <tr>
                                    <td>Aniversário:</td>
                                    <td><input id="aniversario" type="date" value="<?php echo $_SESSION['user_ani']; ?>" readonly></td>
                                </tr>
                                <tr>
                                    <td>Email:</td>
                                    <td><input id="email" type="email" value="<?php echo $_SESSION['user_email']; ?>" readonly></td>
                                </tr>
                                <tr>
                                    <td>Palavra Passe:</td>
                                    <td><input id="passe" type="password" value="<?php echo $_SESSION['user_passe']; ?>" readonly></td>
                                </tr>
                                <tr>
                                    <td colspan="2" class="w3-center w3-button w3-teal w3-round-large" id="editar-dados">Alterar Dados</td>
                                </tr>
                                <tr>
                                    <td colspan="2" class="w3-center w3-button w3-blue w3-round-large" id="guardar-dados" style="display: none;">Guardar Dados</td>
                                </tr>
                            </table>
                        </form>

                        <script>
                            // Função para habilitar a edição dos campos
                            function habilitarEdicao() {
                                document.getElementById("nome").readOnly = false;
                                document.getElementById("telemovel").readOnly = false;
                                document.getElementById("aniversario").readOnly = false;
                                document.getElementById("email").readOnly = false;
                                document.getElementById("passe").readOnly = false;
                                document.getElementById("editar-dados").style.display = "none";
                                document.getElementById("guardar-dados").style.display = "block";
                            }

                            // Função para desabilitar a edição dos campos
                            function desabilitarEdicao() {
                                document.getElementById("nome").readOnly = true;
                                document.getElementById("telemovel").readOnly = true;
                                document.getElementById("aniversario").readOnly = true;
                                document.getElementById("email").readOnly = true;
                                document.getElementById("passe").readOnly = true;
                                document.getElementById("editar-dados").style.display = "block";
                                document.getElementById("guardar-dados").style.display = "none";
                            }

                            // Evento de clique no botão "Alterar Dados"
                            document.getElementById("editar-dados").addEventListener("click", function() {
                                habilitarEdicao();
                            });

                            // Evento de clique no botão "Guardar Dados"
                            $("#guardar-dados").on("click", function() {
                                // Obter os valores dos campos de entrada
                                var nome = $("#nome").val();
                                var telemovel = $("#telemovel").val();
                                var aniversario = $("#aniversario").val();
                                var email = $("#email").val();
                                var passe = $("#passe").val();

                                // Construir os dados a serem enviados via AJAX
                                var dados = {
                                    nome: nome,
                                    telemovel: telemovel,
                                    aniversario: aniversario,
                                    email: email,
                                    passe: passe
                                };

                                // Enviar os dados via AJAX para a página PHP de processamento
                                $.ajax({
                                    url: "../php/AlterDados.php",
                                    method: "POST",
                                    data: JSON.stringify(dados), // Converter para JSON
                                    contentType: "application/json; charset=utf-8", // Definir o cabeçalho de conteúdo
                                    success: function(response) {
                                        // Processar a resposta da página PHP, se necessário
                                        // Por exemplo, exibir uma mensagem de sucesso

                                        // Desabilitar a edição dos campos
                                        desabilitarEdicao();
                                    },
                                    error: function(xhr, status, error) {
                                        // Lidar com erros de requisição, se necessário
                                    }
                                });
                            });


                        </script>

                    </div>
                </div>
            </div>
            
            <!-- End page content -->
        </div>
        <script>
            // Accordion
            function myAccFunc() {
                var x = document.getElementById("demoAcc");
                if (x.className.indexOf("w3-show") == -1) {
                    x.className += " w3-show";
                } else {
                    x.className = x.className.replace(" w3-show", "");
                }
            }

            // Open and close sidebar
            function w3_open() {
                document.getElementById("mySidebar").style.display = "block";
                document.getElementById("myOverlay").style.display = "block";
            }

            function w3_close() {
                document.getElementById("mySidebar").style.display = "none";
                document.getElementById("myOverlay").style.display = "none";
            }
        </script>
    </body>
</html>

