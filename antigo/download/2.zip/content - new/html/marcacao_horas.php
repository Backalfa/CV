<?php

    session_start(); // Iniciar a sessão

    require('../php/conecçao.php');

    // Para saber se está logado
    if (!isset($_SESSION['user_email'])) {
        echo '<script>console.log("Sem Sessão Iniciada!")</script>';
        header("Location: ../login.html");
        exit();
    }else{
        echo '<script>console.log("Bem vindo, '. $_SESSION['user_email'] . '!")</script>';
        echo '<script>console.log("O user é '. $_SESSION['is_admin'] . ' !")</script>';
    }
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Beatriz Miranda Oriflame</title>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <!-- FALTA ADICIONAR PARA A PESQUISA-->
        <link rel="website icon" type="png" href="../imgs/icontab.png" />
        <link rel="stylesheet" href="../css/base_main/base_marca.css" />
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto" />
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <!-- script para teste-->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/locale/pt-br.js"></script>
        <!-- script para teste-->
        <style>
            *{
                font-family: 'Merriweather', serif;
            }
        </style>
    </head>
    <body class="w3-content" style="max-width: 1200px;">
        <!-- Sidebar/menu -->
        <nav class="w3-sidebar w3-bar-block w3-white w3-collapse w3-top" style="z-index: 3; width: 250px;" id="mySidebar">
            <div class="w3-container w3-display-container w3-padding-16">
                <i onclick="w3_close()" class="fa fa-remove w3-hide-large w3-button w3-display-topright"></i>
                <img src="../imgs/LOGO.jpg" style="width: 100%;" />
            </div>
            <a class="w3-bar-item w3-button w3-padding" href="Index.php">Início</a>
            <a class="w3-bar-item w3-button w3-padding" href="#">Sobre Nós</a>
            <?php
                // Para saber se tem sessão
                if (!isset($_SESSION['user_email'])) {
                    // Sem Sessão
                }else{
                    // Para sair da sessão
                    echo '<a class="w3-bar-item w3-button w3-padding" href="tabela_precos.php">Serviços</a>';
                }
            ?>
            <a class="w3-bar-item w3-button w3-padding" href="#Contact">Contacte-nos</a>
            <a onclick="myAccFunc()" href="javascript:void(0)" class="w3-button w3-block w3-white w3-left-align" id="myBtn">
                Catálogo <i class="fa fa-caret-down"></i>
            </a>
            <div id="demoAcc" class="w3-bar-block w3-hide w3-padding-large w3-medium w3-show">
                <a href="catalogo.php?categoria=" class="w3-bar-item w3-button">Catálogo</a>
                <a href="https://pt.oriflame.com/products/digital-catalogue-current?PageNumber=1" class="w3-bar-item w3-button">Catálogo - Oriflame</a>
            </div>
            <a href="https://pt.oriflame.com/catalogue?cataloguecode=Norrsken%2F2023-norrsken-spring" class="w3-bar-item w3-button w3-padding" target="_blank">NORRSKEN - Jóias</a>
            <a href="https://pt.oriflame.com/catalogue?cataloguecode=FlyerC04&PageNumber=1" class="w3-bar-item w3-button w3-padding" target="_blank">Oportunidades</a>
        </nav>

        <!-- Top menu on small screens -->
        <header class="w3-bar w3-top w3-hide-large w3-black w3-xlarge">
            <div class="w3-bar-item w3-padding-24 w3-wide"></div>
            <a href="javascript:void(0)" class="w3-bar-item w3-button w3-padding-24 w3-right" onclick="w3_open()"><i class="fa fa-bars"></i></a>
        </header>

        <!-- Overlay effect when opening sidebar on small screens -->
        <div class="w3-overlay w3-hide-large" onclick="w3_close()" style="cursor: pointer;" title="close side menu" id="myOverlay"></div>

        <!-- !PAGE CONTENT! -->
        <div class="w3-main" style="margin-left: 250px;">
            <!-- Push down content on small screens -->
            <div class="w3-hide-large" style="margin-top: 83px;"></div>

            <!-- TOP HEADER / NAV BAR -->
            <header class="w3-container w3-xlarge">
                <p class="w3-right gap">
                    <script src="https://cdn.lordicon.com/bhenfmcm.js"></script>
                    <span style="position: relative; color: red;">
                    <!-- Conta Carrinho -->
                    <?php
                        if (isset($_SESSION["carrinho"])) {
                            if (count($_SESSION["carrinho"]) != 0) {
                                echo count($_SESSION["carrinho"]);
                            } else {
                                echo '';
                            }
                        } else {
                            echo '';
                        }
                        ?>
                    </span>
                    <?php
                    // Para saber se tem sessão
                    if (!isset($_SESSION['user_email'])) {
                        // Para fazer Log In
                        echo '<a class="nav-link" href="../login.html">Log In</a>';
                    } else {
                        // Para sair da sessão
                        echo '
                            <a href="main_carrinho.php" ><lord-icon
                                src="https://cdn.lordicon.com/lqsduwhb.json"
                                trigger="hover"
                                colors="primary:#000000"
                                style="width:40px;height:40px">
                            </lord-icon></a>
                            <a class="nav-link" href="#" onclick="confirmLogout()">Sair</a>';
                    }
                    ?>
                </p>
            </header>

            <!-- Image header -->
            <div class="w3-display-container w3-container">
                <img class="w3-hide-small" src="../imgs/top-view-salts-cream-container.jpg" alt="logo_pagina_centro" style="width: 100%;" />
                <img class="w3-hide-large w3-hide-medium" src="../imgs/top-view-salts-cream-container.jpg" alt="logo_pagina_centro" style="width: 100%;" />
                <div class="w3-display-topleft w3-text-black" style="padding: 24px 48px;">
                    <h1 class="w3-jumbo w3-hide-small">Beatriz Miranda</h1>
                    <h1 class="w3-hide-large w3-hide-medium">Beatriz Miranda</h1>
                    <p><a href="marcacao.php" class="w3-button w3-black w3-padding-large w3-large">AGENDA A TUA MARCAÇÃO!</a></p>
                </div>
            </div>

            <!-- Content -->

            <div class="box_main">
                <div class="center card shadow-3 rd-3" id="content">
                    <h3>Nova Marcação</h3>
                    <div class='w3-row' style='width: 90%;'>
                        <div class='w3-col s2 m2 l2 w3-center'>
                            <button class='w3-button w3-block w3-light-grey' type='button' onclick='goBack()'>
                            <script src='https://cdn.lordicon.com/bhenfmcm.js'></script>
                            <lord-icon
                                src='https://cdn.lordicon.com/nhfyhmlt.json'
                                trigger='hover'
                                colors='primary:#000000'
                                style='width:40px;height:40px;cursor:pointer;'>
                            </lord-icon></button>
                        </div>
                        <div class='w3-col s8 m8 l8 w3-center'>
                            <p>Escolha Dia da Semana</p><br/>
                        </div>
                        <div class='w3-col s2 m2 l2 w3-center'>
                            <div id='confir'></div>
                        </div>
                    </div><br/>

                    <div id="horario" class="w3-row" align="center" style="width:100%;float:center;margin-bottom: 100px;">
                        <div class="w3-col l6 s6">
                            <div id="manha"></div>
                        </div>
                        <div class="w3-col l6 s6">
                            <div id="tarde"></div>
                        </div>

                        <!-- SCRIPT PARA IR BUSCAR HORARIO -->
                        <script>
                            var diaSemana = localStorage.dia_semana;

                            $.ajax({
                                url: '../php/marcacao/check_horario.php',
                                type: 'POST',
                                data: { diaSemana: diaSemana },
                                dataType: 'json', // Especifica o tipo de dados esperado como JSON
                                success: function(response) {
                                    // O código PHP foi executado e a resposta está em "response"
                                    console.log(response);

                                    // Processar os horários disponíveis
                                    var horariosManha = response.manha;
                                    var horariosTarde = response.tarde;

                                    // Exemplo de como exibir os horários em botões
                                    var manhaElement = document.getElementById('manha');
                                    var tardeElement = document.getElementById('tarde');

                                    // Limpar os elementos existentes, se houver
                                    manhaElement.innerHTML = '<h4>Manhã</h4>';
                                    tardeElement.innerHTML = '<h4>Tarde</h4>';

                                    // Adicionar os horários da manhã aos botões
                                    for (var i = 0; i < horariosManha.length; i++) {
                                        var horario = horariosManha[i];
                                        var button = document.createElement('button');
                                        button.type = 'button';
                                        button.id = horario;
                                        button.className = 'w3-button w3-block w3-light-grey';
                                        button.style.width = '90%';
                                        button.style.cursor = 'pointer';
                                        button.textContent = horario;

                                        function handleButtonClick(horario) {
                                            localStorage.setItem("service_hora", horario);
                                            window.location.href = 'marcacao_confir.php';
                                        }

                                        button.addEventListener('click', handleButtonClick.bind(null, horario));

                                        manhaElement.appendChild(button);

                                        // Adicionar uma quebra de linha após cada botão
                                        var lineBreak = document.createElement('br');
                                        manhaElement.appendChild(lineBreak);
                                    }

                                    // Adicionar os horários da tarde aos botões
                                    for (var i = 0; i < horariosTarde.length; i++) {
                                        var horario = horariosTarde[i];
                                        var button = document.createElement('button');
                                        button.type = 'button';
                                        button.id = horario;
                                        button.className = 'w3-button w3-block w3-light-grey';
                                        button.style.width = '90%';
                                        button.style.cursor = 'pointer';
                                        button.textContent = horario;

                                        function handleButtonClick(horario) {
                                            localStorage.setItem("service_hora", horario);
                                            window.location.href = 'marcacao_confir.php';
                                        }

                                        button.addEventListener('click', handleButtonClick.bind(null, horario));

                                        tardeElement.appendChild(button);

                                        // Adicionar uma quebra de linha após cada botão
                                        var lineBreak = document.createElement('br');
                                        tardeElement.appendChild(lineBreak);
                                        }
                                },
                                error: function(xhr, status, error) {
                                    console.error('Ocorreu um erro na requisição: ' + error);
                                }
                            });
                        </script>

                        <!-- SCRIPT PARA BARRAR HORARIO/MARCAÇÕES -->
                        <script>
                            function scure(time) {
                                
                                var diaano = localStorage.dia;
                                var dia = moment(diaano, 'DD-MM-YYYY').format('YYYY-MM-DD');
                                
                                // VERIFICAR AQUI
                                var button = document.getElementById(time);
                                var time = time + ':00'; // Adiciona ':00' ao final do valor de time

                                
                                // Faz uma requisição assíncrona usando AJAX
                                var xhr = new XMLHttpRequest();
                                xhr.open('GET', '../php/marcacao/check_appointment.php?time=' + encodeURIComponent(time) + '&dia=' + encodeURIComponent(dia), true);
                                xhr.onreadystatechange = function() {
                                    if (xhr.readyState === XMLHttpRequest.DONE) {
                                        if (xhr.status === 200) {
                                            var response = JSON.parse(xhr.responseText);
                                            // Parseia a resposta JSON
                                            var response = JSON.parse(xhr.responseText);
                                    
                                            // Se a resposta for true, desabilita o botão
                                            if (button !== null) {
                                                button.disabled = response;
                                            }
                                        } else {
                                            console.error('Ocorreu um erro na requisição: ' + xhr.status);
                                        }
                                    }
                                };
                                xhr.send();
                            }

                            setTimeout(function() {
                                        scure('09:00');
                                        scure('09:30');
                                        scure('10:00');
                                        scure('10:30');
                                        scure('11:00');
                                        scure('11:30');
                                        scure('12:00');
                                        scure('12:30');
                                        scure('13:00');
                                        scure('13:30');
                                        scure('14:00');
                                        scure('14:30');
                                        scure('15:00');
                                        scure('15:30');
                                        scure('16:00');
                                        scure('16:30');
                                        scure('17:00');
                                        scure('17:30');
                                        scure('18:00');
                                        scure('18:30');
                                        scure('19:00');
                                        scure('19:30');
                                    }, 300)
                        </script>

                        <!-- SCRIPT PARA ADICIONAR HORARIO DISPONIVEL CONSUANTE O TIME -->
                        <script>

                            setTimeout(function() {
                                checktime();
                            }, 400);


                            function checktime(){
                                let time = localStorage.service_time;

                                let allbutton = $('#horario button');
                                let Buttons = allbutton.filter(':not(:disabled)');
                                console.log(Buttons);

                                if( time < 180){

                                    let sequencia = parseInt( parseInt(time) * 0.0333 );
                                        console.log(sequencia);

                                    if (sequencia != 0){

                                        let ultimosBotoes = Buttons.slice(- parseInt(sequencia));

                                        // Percorrer os últimos dois botões e desabilitá-los
                                        ultimosBotoes.each(function() {
                                        $(this).prop('disabled', true);
                                        });
                                    }
                                }


                            }
                        </script>
                    </div>
                </div>
            </div>



            <!-- End page content -->
        </div>
        
        <script>
            function goBack() {
                localStorage.removeItem("dia_semana");
                localStorage.removeItem("dia");

                window.location.href = "marcacao_table.php";
            }
        </script>

        <script>
            // Accordion
            function myAccFunc() {
                var x = document.getElementById("demoAcc");
                if (x.className.indexOf("w3-show") == -1) {
                    x.className += " w3-show";
                } else {
                    x.className = x.className.replace(" w3-show", "");
                }
            }

            // Open and close sidebar
            function w3_open() {
                document.getElementById("mySidebar").style.display = "block";
                document.getElementById("myOverlay").style.display = "block";
            }

            function w3_close() {
                document.getElementById("mySidebar").style.display = "none";
                document.getElementById("myOverlay").style.display = "none";
            }
        </script>
    </body>
</html>

