<?php

    session_start(); // Iniciar a sessão

    require('../php/conecçao.php');

    // Para saber se está logado
    if (!isset($_SESSION['user_email'])) {
        echo '<script>console.log("Sem Sessão Iniciada!")</script>';
    }else{
        echo '<script>console.log("Bem vindo, '. $_SESSION['user_email'] . '!")</script>';
        echo '<script>console.log("O user é '. $_SESSION['is_admin'] . ' !")</script>';
    }
?>


<!DOCTYPE html>
<html>
    <head>
        <title>Beatriz Miranda Oriflame</title>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <!-- FALTA ADICIONAR PARA A PESQUISA-->
        <link rel="website icon" type="png" href="../imgs/icontab.png" />
        <link rel="stylesheet" href="../css/base_main/base_catalogo.css" />
        <link rel="stylesheet" href="../css/base_main/base_carrinho.css" />
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto" />
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <!-- JQUERY -->
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <style>
            *{
                font-family: 'Merriweather', serif;
            }
        </style>
    </head>
    <body class="w3-content" style="max-width: 1200px;">
        <!-- Sidebar/menu -->
        <nav class="w3-sidebar w3-bar-block w3-white w3-collapse w3-top" style="z-index: 3; width: 250px;" id="mySidebar">
            <div class="w3-container w3-display-container w3-padding-16">
                <i onclick="w3_close()" class="fa fa-remove w3-hide-large w3-button w3-display-topright"></i>
                <img src="../imgs/LOGO.jpg" style="width: 100%;" />
            </div>
            <a class="w3-bar-item w3-button w3-padding" href="Index.php">Início</a>
            <a class="w3-bar-item w3-button w3-padding" href="#">Sobre Nós</a>
            <?php
                // Para saber se tem sessão
                if (!isset($_SESSION['user_email'])) {
                    // Sem Sessão
                }else{
                    // Para sair da sessão
                    echo '<a class="w3-bar-item w3-button w3-padding" href="tabela_precos.php">Serviços</a>';
                }
            ?>
            <a class="w3-bar-item w3-button w3-padding" href="#Contact">Contacte-nos</a>
            <a onclick="myAccFunc()" href="javascript:void(0)" class="w3-button w3-block w3-white w3-left-align" id="myBtn">
                Catálogo <i class="fa fa-caret-down"></i>
            </a>
            <div id="demoAcc" class="w3-bar-block w3-hide w3-padding-large w3-medium w3-show">
                <a href="catalogo.php?categoria=" class="w3-bar-item w3-button">Catálogo</a>
                <a href="https://pt.oriflame.com/products/digital-catalogue-current?PageNumber=1" class="w3-bar-item w3-button">Catálogo - Oriflame</a>
            </div>
            <a href="https://pt.oriflame.com/catalogue?cataloguecode=Norrsken%2F2023-norrsken-spring" class="w3-bar-item w3-button w3-padding" target="_blank">NORRSKEN - Jóias</a>
            <a href="https://pt.oriflame.com/catalogue?cataloguecode=FlyerC04&PageNumber=1" class="w3-bar-item w3-button w3-padding" target="_blank">Oportunidades</a>
        </nav>

        <!-- Top menu on small screens -->
        <header class="w3-bar w3-top w3-hide-large w3-black w3-xlarge">
            <div class="w3-bar-item w3-padding-24 w3-wide"></div>
            <a href="javascript:void(0)" class="w3-bar-item w3-button w3-padding-24 w3-right" onclick="w3_open()"><i class="fa fa-bars"></i></a>
        </header>

        <!-- Overlay effect when opening sidebar on small screens -->
        <div class="w3-overlay w3-hide-large" onclick="w3_close()" style="cursor: pointer;" title="close side menu" id="myOverlay"></div>

        <!-- !PAGE CONTENT! -->
        <div class="w3-main" style="margin-left: 250px;">
            <!-- Push down content on small screens -->
            <div class="w3-hide-large" style="margin-top: 83px;"></div>

            <!-- TOP HEADER / NAV BAR -->
            <header class="w3-container w3-xlarge">
                <p class="w3-right gap">
                    <script src="https://cdn.lordicon.com/bhenfmcm.js"></script>
                    <span style="position: relative; color: red;">
                    <!-- Conta Carrinho -->
                    <?php
                        if (isset($_SESSION["carrinho"])) {
                            if (count($_SESSION["carrinho"]) != 0) {
                                echo count($_SESSION["carrinho"]);
                            } else {
                                echo '';
                            }
                        } else {
                            echo '';
                        }
                        ?>
                    </span>
                    <?php
                    // Para saber se tem sessão
                    if (!isset($_SESSION['user_email'])) {
                        // Para fazer Log In
                        echo '<a class="nav-link" href="../login.html">Log In</a>';
                    } else {
                        // Para sair da sessão
                        echo '
                            <a href="main_carrinho.php" ><lord-icon
                                src="https://cdn.lordicon.com/lqsduwhb.json"
                                trigger="hover"
                                colors="primary:#000000"
                                style="width:40px;height:40px">
                            </lord-icon></a>
                            <a class="nav-link" href="#" onclick="confirmLogout()">Sair</a>';
                    }
                    ?>
                </p>
            </header>


            <!-- Image header -->
            <div class="w3-display-container w3-container">
                <img class="w3-hide-small" src="../imgs/top-view-salts-cream-container.jpg" alt="logo_pagina_centro" style="width: 100%;" />
                <img class="w3-hide-large w3-hide-medium" src="../imgs/top-view-salts-cream-container.jpg" alt="logo_pagina_centro" style="width: 100%;" />
                <div class="w3-display-topleft w3-text-black" style="padding: 24px 48px;">
                    <h1 class="w3-jumbo w3-hide-small">Beatriz Miranda</h1>
                    <h1 class="w3-hide-large w3-hide-medium">Beatriz Miranda</h1>
                    <p><a href="marcacao.php" class="w3-button w3-black w3-padding-large w3-large">AGENDA A TUA MARCAÇÃO!</a></p>
                </div>
            </div>

            <!-- MAIN CONTENT -->
            
            <h1 class="w3-center" style="margin-top: 40px;">Carrinho</h1>


            <div class="w3-row" style="margin-bottom: 100px;">
                <div class="w3-col l8 s12">
                    <?php
                        // Verifica se a variável $_SESSION["carrinho"] está definida e contém dados
                        if (isset($_SESSION["carrinho"]) && is_array($_SESSION["carrinho"])) {
                            $carrinho = $_SESSION["carrinho"]; // Recupera o carrinho da sessão

                            if (!empty($carrinho)) {
                                // Remove as referências duplicadas
                                $carrinho = array_unique($carrinho);

                                // Conecte-se ao banco de dados
                                require('../php/conecçao.php');

                                // Obtém o subtotal do carrinho
                                $subTotal = 0;

                                // Itera sobre as referências do carrinho
                                foreach ($carrinho as $referencia) {
                                    // Consulta SQL para obter as informações do produto com base na referência
                                    $sql = "SELECT * FROM produtos WHERE ref = '$referencia'";
                                    $result = $conn->query($sql);

                                    // Verifica se a consulta retornou algum resultado
                                    if ($result->num_rows > 0) {
                                        // Obtém os dados do produto
                                        $row = $result->fetch_assoc();

                                        // Obtém a quantidade do produto no carrinho
                                        $quantidade_no_carrinho = array_count_values($_SESSION["carrinho"])[$referencia];

                                        // Saber o desconto
                                        $desconto = 0;

                                        if ($row["preco"] == $row["preco_novo"]) {
                                            $desconto = 0; // Não há desconto
                                        } else if ($row["preco"] > $row["preco_novo"]) {
                                            $desconto = $row["preco"] - $row["preco_novo"]; // Calcula o desconto
                                        }
                                        // Formata o desconto para o formato desejado
                                        $desconto_formatado = number_format($desconto, 2, '.', '') . '€';

                                        // Calcula o subtotal do produto
                                        $subtotal_produto = $row["preco_novo"] * $quantidade_no_carrinho;

                                        // Adiciona o subtotal do produto ao subtotal total
                                        $subTotal += $subtotal_produto;

                                        // Verifica se o produto é para homem ou mulher
                                        if ($row["homem"] == 1 && $row["mulher"] == 1) {
                                            $genero = '<span class="w3-tag w3-display-topleft" style="top: 15px;background-color: transparent;">
                                                            <span style="background-color: rgb(155, 201, 231); border-radius: 50%;padding: 5px;">H</span>
                                                            <span style="background-color: rgb(252, 166, 233); border-radius: 50%;padding: 5px;">M</span>
                                                        </span>';
                                        } elseif ($row["homem"] == 1 || $row["mulher"] == 1) {
                                            if ($row["homem"] == 1) {
                                                $genero = '<span class="w3-tag w3-display-topleft" style="top: 15px;background-color: transparent;">
                                                                <span style="background-color: rgb(155, 201, 231); border-radius: 50%;padding: 5px;">H</span>
                                                            </span>';
                                            } elseif ($row["mulher"] == 1) $genero = '<span class="w3-tag w3-display-topleft" style="top: 15px;background-color: transparent;">
                                            <span style="background-color: rgb(252, 166, 233); border-radius: 50%;padding: 5px;">M</span>
                                            </span>';
                                            }
                                            
                                            else {
                                            $genero = "";
                                            }
                                            
                                            // Se o preço novo é mais baixo que o antigo, o artigo está em promoção
                                            if ($row["preco"] > $row["preco_novo"]) {
                                            $prompreco = '<h5><s>'.$row["preco"].'€</s><b><span style="color:rgb(255, 0, 0); margin-left: 5%;">'.$row["preco_novo"].'€</span></b></h5>';
                                            } else {
                                            $prompreco = '<h5><b>'.$row["preco"].' €</b></h5>';
                                            }

                                            // Saber a percentagem de desconto

                                            if (($row["preco"] > $row["preco_novo"]) && ($row["preco"] != $row["preco_novo"])) {
                                                $ndesconto = 100 - (($row["preco_novo"] * 100) / $row["preco"]);
                                                $ydesconto = number_format($ndesconto);
                                                $desconto = '
                                                            <div class="w3-container w3-panel w3-card yellow" style="width:70%;">
                                                                <div class="w3-row">
                                                                    <div class="w3-col l4 s4">
                                                                        <script src="https://cdn.lordicon.com/bhenfmcm.js"></script>
                                                                        <lord-icon src="https://cdn.lordicon.com/xcevpeyr.json" trigger="hover" colors="primary:#000000" style="width:50px;height:50px"></lord-icon>
                                                                    </div>
                                                                    <div class="w3-col l8 s8" style="text-align: center;">
                                                                        <h5><b>' . $ydesconto . '% </b></h5>
                                                                    </div>
                                                                </div>
                                                            </div>';
                                            }else{
                                                $desconto = '';
                                            }

                                            // Visão Desktop
                                            echo '
                                            <div class="w3-hide-small w3-hide-medium w3-container w3-panel w3-card" style="margin-left:10px;">
                                                <div class="w3-row">
                                                    <div class="w3-container" style="margin: 20px;">
                                                        <div class="w3-row">

                                                            <div class="w3-col l5 s5">
                                                                <div class="w3-display-container">
                                                                    <img src="data:image/jpeg;base64,' . base64_encode($row['imagem']) . '" style="width: 200px;"" />
                                                                    '.$genero.'
                                                                </div>
                                                            </div>

                                                            <div class="w3-col l5 s5">
                                                                <div class="w3-display-container">
                                                                    <h4><b>' . $row["nome"] .'</b></h4>
                                                                    <p><span style="font-size: smaller;"><u>Ref:</u> '.$row["ref"].'</span></p><br />
                                                                    <p>'. $prompreco .'</p>
                                                                    <p>' . $desconto . '</p><br />
                                                                </div>
                                                            </div>

                                                            <div class="w3-col l2 s2">';

                                                                if($quantidade_no_carrinho < $row["quantidade"]){
                                                                    echo ' 
                                                                    <form method="post" action="../php/increment.php">
                                                                        <button class="w3-button w3-round-large w3-teal"  value="' . $row["ref"] . '" name="adicionar_carrinho" style="width:100%;">
                                                                            <script src="https://cdn.lordicon.com/bhenfmcm.js"></script>
                                                                            <lord-icon
                                                                                src="https://cdn.lordicon.com/xdakhdsq.json"
                                                                                trigger="hover"
                                                                                colors="primary:#000000"
                                                                                style="width:30px;height:30px">
                                                                            </lord-icon>
                                                                        </button>
                                                                    </form>';
                                                                }else{
                                                                    echo ' 
                                                                    <button class="w3-button w3-round-large w3-Gray" style="width:100%;">
                                                                        <script src="https://cdn.lordicon.com/bhenfmcm.js"></script>
                                                                        <lord-icon
                                                                            src="https://cdn.lordicon.com/xdakhdsq.json"
                                                                            trigger="hover"
                                                                            colors="primary:#000000"
                                                                            style="width:30px;height:30px">
                                                                        </lord-icon>
                                                                    </button>';
                                                                };

                                                                    echo '<button style="width:100%; margin-bottom: 18px;" class="w3-button w3-round-large w3-teal" id="quantidade_' . $referencia . '">' . $quantidade_no_carrinho . '</button>';

                                                                if($quantidade_no_carrinho == 1 ){
                                                                    echo ' 
                                                                    <button class="w3-button w3-round-large w3-grey" style="width:100%;">
                                                                        <script src="https://cdn.lordicon.com/bhenfmcm.js"></script>
                                                                        <lord-icon
                                                                        src="https://cdn.lordicon.com/albqovim.json"
                                                                            trigger="hover"
                                                                            colors="primary:#000000"
                                                                            style="width:30px;height:30px">
                                                                        </lord-icon>
                                                                    </button>';
                                                                }else{
                                                                    echo '
                                                                    <form method="post" action="../php/decrement.php">
                                                                        <button class="w3-button w3-round-large w3-teal"  value="' . $row["ref"] . '" name="retirar_carrinho" style="width:100%;">
                                                                            <script src="https://cdn.lordicon.com/bhenfmcm.js"></script>
                                                                            <lord-icon
                                                                            src="https://cdn.lordicon.com/albqovim.json"
                                                                                trigger="hover"
                                                                                colors="primary:#000000"
                                                                                style="width:30px;height:30px">
                                                                            </lord-icon>
                                                                        </button>
                                                                    </form>';
                                                                }   

                                                            echo '
                                                            </div>
                                                        </div>
                                                        <a class="w3-padding w3-round" href="#" onclick="removerProduto(\'' . $referencia . '\')">Remover</a>
                                                    </div>
                                                </div>
                                            </div>';

                                            // Visão Mobile
                                            echo '
                                            <div class="w3-hide-large w3-container w3-panel w3-card">
                                                <div class="w3-row">
                                                    <div class="w3-container" style="margin: 20px;">
                                                        <div class="w3-row">

                                                            <div class="w3-col l10 s10">
                                                                <h4><b>' . $row["nome"] .'</b></h4>
                                                                <div class="w3-display-container">
                                                                    <img src="data:image/jpeg;base64,' . base64_encode($row['imagem']) . '" style="width: 150px;"" />
                                                                    '.$genero.'
                                                                </div>
                                                                <div class="w3-display-container">
                                                                    <p><span style="font-size: smaller;"><u>Ref:</u> '.$row["ref"].'</span></p>
                                                                    <p>'. $prompreco .'</p>
                                                                    <p>' . $desconto . '</p><br />
                                                                </div>
                                                            </div>

                                                            <div class="w3-col l2 s2" style="align-items: center;">';

                                                                if($quantidade_no_carrinho < $row["quantidade"]){
                                                                    echo ' 
                                                                    <form method="post" action="../php/increment.php">
                                                                        <button class="w3-button w3-round-large w3-teal" value="' . $row["ref"] . '" name="adicionar_carrinho" style="width:100%; display: flex; justify-content: center; align-items: center;">
                                                                            <script src="https://cdn.lordicon.com/bhenfmcm.js"></script>
                                                                            <lord-icon
                                                                                src="https://cdn.lordicon.com/xdakhdsq.json"
                                                                                trigger="hover"
                                                                                colors="primary:#000000"
                                                                                style="width:30px;height:30px">
                                                                            </lord-icon>
                                                                        </button>
                                                                    </form>';
                                                                }else{
                                                                    echo ' 
                                                                    <button class="w3-button w3-round-large w3-Gray" style="width:100%; display: flex; justify-content: center; align-items: center;">
                                                                        <script src="https://cdn.lordicon.com/bhenfmcm.js"></script>
                                                                        <lord-icon
                                                                            src="https://cdn.lordicon.com/xdakhdsq.json"
                                                                            trigger="hover"
                                                                            colors="primary:#000000"
                                                                            style="width:30px;height:30px">
                                                                        </lord-icon>
                                                                    </button>';
                                                                };

                                                                    echo '<button style="width:100%; margin-bottom: 15px;" class="w3-button w3-round-large w3-teal" id="quantidade_' . $referencia . '">' . $quantidade_no_carrinho . '</button>';

                                                                if($quantidade_no_carrinho == 1 ){
                                                                    echo ' 
                                                                    <button class="w3-button w3-round-large w3-grey" style="width:100%; display: flex; justify-content: center; align-items: center;">
                                                                        <script src="https://cdn.lordicon.com/bhenfmcm.js"></script>
                                                                        <lord-icon
                                                                        src="https://cdn.lordicon.com/albqovim.json"
                                                                            trigger="hover"
                                                                            colors="primary:#000000"
                                                                            style="width:30px;height:30px">
                                                                        </lord-icon>
                                                                    </button>';
                                                                }else{
                                                                    echo '
                                                                    <form method="post" action="../php/decrement.php">
                                                                        <button class="w3-button w3-round-large w3-teal"  value="' . $row["ref"] . '" name="retirar_carrinho" style="width:100%; display: flex; justify-content: center; align-items: center;">
                                                                            <script src="https://cdn.lordicon.com/bhenfmcm.js"></script>
                                                                            <lord-icon
                                                                            src="https://cdn.lordicon.com/albqovim.json"
                                                                                trigger="hover"
                                                                                colors="primary:#000000"
                                                                                style="width:30px;height:30px">
                                                                            </lord-icon>
                                                                        </button>
                                                                    </form>';
                                                                }   

                                                            echo '
                                                            </div>
                                                        </div>
                                                        <a class="w3-padding w3-round" href="#" onclick="removerProduto(\'' . $referencia . '\')">Remover</a>
                                                    </div>
                                                </div>
                                            </div>';

                                            echo '
                                            <script>
                                                // Decrement
                                                $(document).ready(function() {
                                                    // Evento de clique no botão "-"
                                                    $(".decrement").click(function() {
                                                        var referencia = $(this).data("referencia");

                                                        // Requisição AJAX para remover a referência
                                                        $.ajax({
                                                        url: "../php/atualizar_quantidade_-.php",
                                                        type: "POST",
                                                        data: { referencia: referencia },
                                                        success: function(response) {

                                                            // Recarregar a página para refletir as alterações no carrinho
                                                            location.reload();
                                                        },
                                                        error: function() {
                                                            alert("Ocorreu um erro ao remover a referência do carrinho.");
                                                        }
                                                        });
                                                    });
                                                });
                                            </script>
                                        ';

                                    }
                                }
                            } else {
                                // Obtém o subtotal do carrinho
                                $subTotal = 0;
                                echo 'Não tem Itens no Carrinho'; // Mensagem exibida quando o carrinho estiver vazio
                            }
                        } else {
                            // Obtém o subtotal do carrinho
                            $subTotal = 0;
                            echo 'Não tem Itens no Carrinho'; // Mensagem exibida quando o carrinho não estiver definido na sessão
                        }
                    ?>
                </div>
                <div class="w3-col l4">
                    <div class="w3-card w3-margin w3-padding">
                        <h4>Total: <span id="total"><?php echo number_format($subTotal, 2, '.', ''); ?>€</span></h4><br />
                        <button class="w3-button w3-block w3-teal" id="comprar">Comprar</button><br/><br/>
                        
                        <div class="w3-row">
                            <div class="w3-col l4 s4 w3-center">
                                <!-- Visa -->
                                <svg version="1.1" width="30px" height="10px" viewBox="0 0 30.0 10.0" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><defs><clipPath id="i0"><path d="M19.6107,0 C20.5446,0 21.29505,0.203775 21.87825,0.415425 L21.452475,2.40255 C20.367,1.9029 19.41,1.9377 19.0626,1.98315 C18.36195,2.0745 18.0417,2.43195 18.034425,2.768175 C18.0108,3.873 21.441075,4.00935 21.4308,6.48255 C21.422925,8.430675 19.7571,9.68865 17.21025,9.68865 C16.126275,9.677325 15.08085,9.4506 14.51445,9.190725 L14.953725,7.137825 C15.517425,7.3998 16.224525,7.74825 17.4429,7.729575 C18.14085,7.7187 18.8877,7.4412 18.89445,6.81255 C18.897975,6.40185 18.581025,6.10695 17.636175,5.6478 C16.7178,5.199525 15.49875,4.44675 15.5142,3.09765 C15.52845,1.2738 17.214675,0 19.6107,0 Z M14.85405,0.17115 L12.849525,9.542175 L10.42545,9.542175 L12.430725,0.17115 L14.85405,0.17115 Z M28.04295,0.17115 L30,9.542175 L27.75795,9.542175 L27.4653,8.142375 L24.3552,8.142375 L23.8497,9.542175 L21.304275,9.542175 L24.941925,0.858675 C25.11585,0.44205 25.50825,0.17115 25.97355,0.17115 L28.04295,0.17115 Z M4.182405,0.17115 C4.708185,0.17115 5.1807975,0.521175 5.3001525,1.126725 L6.32094,6.5493 L8.843775,0.17115 L11.3904,0.17115 L7.4627625,9.542175 L4.9003125,9.542175 L2.9675325,2.0637 C2.8501425,1.602975 2.7482175,1.4343 2.39136,1.240275 C1.8087525,0.92415 0.8464875,0.627675 0,0.44355 L0.057515175,0.17115 L4.182405,0.17115 Z M26.32905,2.703225 L25.05315,6.2217 L27.063375,6.2217 L26.32905,2.703225 Z"></path></clipPath></defs><g transform="translate(0.0 0.08179999999999943)"><g transform=""><g clip-path="url(#i0)"><polygon points="0,0 30,0 30,9.68865 0,9.68865 0,0" stroke="none" fill="#1434CB"></polygon></g></g></g></svg>
                            </div>
                            <div class="w3-col l4 s4 w3-center">
                                <!-- Multibanco -->
                                <svg xmlns="http://www.w3.org/2000/svg" width="17" height="20" viewBox="0 0 17 20"><g fill="none" transform="translate(.1 .943)"><path fill="#2A6BAE" d="M7.89821347,15.187 L14.4322135,15.187 C15.9242135,15.187 15.9392135,13.602 15.7872135,12.819 C15.7042135,12.293 14.8102135,12.297 14.7122135,12.819 L14.7122135,13.429 C14.7111171,13.7091053 14.4843188,13.9359037 14.2042135,13.937 L1.67721347,13.937 C1.39749608,13.9359079 1.17085674,13.7097147 1.16921347,13.43 L1.16921347,12.819 C1.07121347,12.297 0.177213465,12.293 0.094213465,12.819 C-0.057786535,13.602 -0.042786535,15.188 1.44921347,15.188 L7.89821347,15.188 L7.89821347,15.187 Z M3.28021347,8.8817842e-16 L13.3542135,8.8817842e-16 C14.0622135,8.8817842e-16 14.6412135,0.613 14.6412135,1.362 L14.6412135,2.012 C14.6141453,2.33498143 14.3450229,2.58389082 14.0209143,2.5857102 C13.6968057,2.58752957 13.4249059,2.3416572 13.3942135,2.019 L13.3942135,1.663 C13.3931152,1.43662968 13.2095858,1.25354678 12.9832135,1.253 L2.88721347,1.253 C2.66123157,1.25409436 2.47830783,1.4370181 2.47721347,1.663 L2.47721347,2.012 C2.47721347,2.927 1.28821347,2.92 1.28821347,2.032 L1.28821347,1.362 C1.28821347,0.612 1.86821347,8.8817842e-16 2.57521347,8.8817842e-16 L3.27921347,8.8817842e-16 L3.28021347,8.8817842e-16 Z"/><path fill="#424041" d="M14.3872135 7.481C15.0842135 7.809 15.5662135 8.487 15.5662135 9.265 15.5662135 10.362 14.6082135 11.259 13.4382135 11.259L10.1572135 11.259C9.85021347 11.259 9.59921347 11.024 9.59921347 10.736L9.59921347 4.494C9.60031038 4.19180348 9.84501694 3.94709691 10.1472135 3.946L12.8802135 3.946C14.0302135 3.946 14.9712135 4.886 14.9712135 6.036 14.9712135 6.596 14.7482135 7.105 14.3872135 7.481M11.9372135 6.972L12.9792135 6.972 12.9792135 6.961C13.4624681 6.88571976 13.8191533 6.47008184 13.8202135 5.981 13.8180213 5.43514872 13.3760647 4.9931922 12.8302135 4.991L10.7302135 4.991 10.7302135 10.171 13.3912135 10.171C13.9542135 10.171 14.4142135 9.711 14.4142135 9.148 14.4142135 8.585 13.9542135 8.125 13.3912135 8.125L12.9782135 8.125 12.9782135 8.123 11.9372135 8.123C11.6201053 8.12190273 11.3633107 7.86510812 11.3622135 7.548 11.3622135 7.231 11.6202135 6.972 11.9372135 6.972M3.69521347 17.104C3.69521347 17.0067979 3.77401135 16.928 3.87121347 16.928 3.96841558 16.928 4.04721601 17.0067979 4.04721601 17.104L4.04721601 18.056C4.04774634 18.2656839 3.96468556 18.4669333 3.81641615 18.6152027 3.66814674 18.7634721 3.4668974 18.8465329 3.25721347 18.8460025 3.04752953 18.8465329 2.84628019 18.7634721 2.69801078 18.6152027 2.54974137 18.4669333 2.46668059 18.2656839 2.46721092 18.056L2.46721092 17.104C2.47414778 17.012202 2.55065393 16.9412571 2.64271347 16.9412571 2.73477301 16.9412571 2.81127915 17.012202 2.81821347 17.104L2.81821347 18.056C2.81794785 18.172338 2.86397686 18.2840021 2.9461466 18.3663594 3.02831634 18.4487168 3.13987517 18.4950003 3.25621347 18.495L3.25721347 18.495C3.37721347 18.495 3.48721347 18.445 3.56721347 18.365 3.64721347 18.285 3.69621347 18.176 3.69621347 18.055L3.69621347 17.104 3.69521347 17.104zM5.35821347 18.494C5.45541558 18.494 5.53421347 18.5727979 5.53421347 18.67 5.53421347 18.7672021 5.45541558 18.846 5.35821347 18.846L4.87221347 18.846C4.69699718 18.846 4.52897188 18.7763274 4.40516908 18.6523371 4.28136628 18.5283467 4.21194799 18.3602161 4.21221347 18.185L4.21121347 18.185 4.21121347 17.105C4.21121347 17.0077979 4.29001135 16.929 4.38721347 16.929 4.48441558 16.929 4.56321347 17.0077979 4.56321347 17.105L4.56321347 18.185 4.56221347 18.185C4.56258597 18.2673197 4.59568547 18.3461109 4.65421347 18.404 4.71218431 18.4615502 4.79052724 18.4938937 4.87221347 18.494L5.35821347 18.494 5.35821347 18.494zM9.07821347 10.635C9.10322206 10.869009 9.00148866 11.0985841 8.81133525 11.2372466 8.62118184 11.3759092 8.37149724 11.4025931 8.15633524 11.3072466 7.94117324 11.2119002 7.79322205 11.009009 7.76821347 10.775L7.22821347 5.81 5.31821347 10.664 5.31621347 10.669 5.31021347 10.682 5.30621347 10.692 5.30521347 10.695 5.30021347 10.705 5.29821347 10.711 5.29321347 10.721 5.29121347 10.725 5.28621347 10.735 5.28421347 10.738C5.24965797 10.8031282 5.20435463 10.861955 5.15021347 10.912L5.14921347 10.914 5.13921347 10.923C5.10418342 10.9536663 5.06596477 10.9804864 5.02521347 11.003L5.02221347 11.005 5.01021347 11.012 5.00921347 11.012 4.99721347 11.018 4.99221347 11.021 4.98521347 11.024 4.97721347 11.028 4.97021347 11.031 4.96221347 11.035 4.95521347 11.038 4.94821347 11.041 4.94221347 11.043 4.93821347 11.044 4.93321347 11.046 4.92421347 11.05 4.91921347 11.051C4.85710286 11.072954 4.79203966 11.0854273 4.72621347 11.088L4.67821347 11.088C4.60452698 11.0851905 4.53184156 11.0699773 4.46321347 11.043L4.45321347 11.039 4.45221347 11.039 4.44221347 11.035 4.43421347 11.031 4.42721347 11.028 4.42021347 11.025 4.41221347 11.021 4.40721347 11.018 4.39521347 11.012 4.38421347 11.006 4.37821347 11.003C4.34277698 10.9828254 4.30929875 10.9593906 4.27821347 10.933L4.27521347 10.931 4.25321347 10.911C4.24744938 10.9057711 4.24178176 10.9004369 4.23621347 10.895L4.22121347 10.879C4.21437301 10.8718266 4.20770445 10.8644911 4.20121347 10.857L4.19921347 10.854C4.17282285 10.8229147 4.14938809 10.7894365 4.12921347 10.754L4.12621347 10.748 4.12021347 10.738 4.12021347 10.736 4.11321347 10.724 4.11121347 10.72 4.10721347 10.712 4.10421347 10.704 4.10121347 10.698 4.09721347 10.689 4.09321347 10.68 4.09321347 10.678 4.08921347 10.669 2.17621347 5.81 1.63621347 10.775C1.59755353 11.1364704 1.27318383 11.3981599.911713465 11.3595.550243096 11.3208401.288553533 10.9964704.327213465 10.635L.963213465 4.783.963213465 4.779C.97877031 4.64103671 1.02051728 4.50731065 1.08621347 4.385 1.25139714 4.07489324 1.55593726 3.86342772 1.90421347 3.817L1.90521347 3.817C1.97212769 3.80780468 2.03974662 3.80479196 2.10721347 3.808L2.11021347 3.808C2.53976408 3.82524778 2.91826966 4.09538454 3.07421347 4.496L4.70221347 8.632 6.33021347 4.496C6.48630147 4.09506155 6.86529379 3.82485769 7.29521347 3.808L7.29721347 3.808C7.36468034 3.80481457 7.4322972 3.8078272 7.49921347 3.817L7.50021347 3.817C7.99784291 3.8829955 8.38621558 4.28003537 8.44121347 4.779L8.44121347 4.783 9.07721347 10.635 9.07821347 10.635zM2.40021347 18.65C2.41125916 18.7466498 2.3418633 18.8339543 2.24521347 18.845 2.14856363 18.8560457 2.06125916 18.7866498 2.05021347 18.69L1.90021347 17.424 1.36221347 18.67C1.3343277 18.7343775 1.270871 18.7760447 1.20071347 18.7760447 1.13055593 18.7760447 1.06709923 18.7343775 1.03921347 18.67L.502213465 17.424.351213465 18.691C.339891628 18.7876498.252363296 18.8568218.155713465 18.8455.0590636338 18.8341782-.0101083723 18.7466498.00121346504 18.65L.177213465 17.178C.190338707 17.0655005.269497822 16.9717698.378213465 16.94.395199923 16.9348514.412597184 16.9311712.430213465 16.929L.433213465 16.929C.541782858 16.9150004.64949514 16.9604534.715213465 17.048.726979438 17.0642527.737032923 17.0816788.745213465 17.1L1.20121347 18.157 1.65721347 17.1C1.70202471 16.9971821 1.80210702 16.9294221 1.91421347 16.926L1.95421347 16.926 1.96721347 16.928 1.96921347 16.928C2.06008079 16.9386304 2.14092611 16.9906815 2.18821347 17.069 2.2078328 17.102077 2.22042788 17.138841 2.22521347 17.177L2.22521347 17.178 2.40021347 18.65 2.40021347 18.65zM6.12621347 18.67C6.12621347 18.7672021 6.04741558 18.846 5.95021347 18.846 5.85301135 18.846 5.77421347 18.7672021 5.77421347 18.67L5.77421347 17.28 5.27421347 17.28C5.17701135 17.28 5.09821347 17.2012021 5.09821347 17.104 5.09821347 17.0067979 5.17701135 16.928 5.27421347 16.928L6.62621347 16.928C6.72341558 16.928 6.80221347 17.0067979 6.80221347 17.104 6.80221347 17.2012021 6.72341558 17.28 6.62621347 17.28L6.12621347 17.28 6.12621347 18.67 6.12621347 18.67zM7.83521347 18.67C7.83521347 18.767 7.63221347 18.846 7.38221347 18.846 7.13221347 18.846 6.92921347 18.767 6.92921347 18.67L6.92921347 17.104C6.92921347 17.007 7.13221347 16.928 7.38221347 16.928 7.63221347 16.928 7.83521347 17.007 7.83521347 17.104L7.83521347 18.67zM10.8322135 18.649C10.8385225 18.7424117 10.7705961 18.8244128 10.6776423 18.8355992 10.5846885 18.8467856 10.4992467 18.7832414 10.4832135 18.691L10.4212135 18.195 9.81121347 18.195C9.71401135 18.195 9.63521347 18.1162021 9.63521347 18.019 9.63521347 17.9217979 9.71401135 17.843 9.81121347 17.843L10.3782135 17.843 10.3622135 17.713 10.3602135 17.7C10.350707 17.6365646 10.3318346 17.5748921 10.3042135 17.517 10.2416781 17.3755378 10.1028502 17.2831158 9.94821347 17.28L9.94621347 17.28C9.88820219 17.2802366 9.83103682 17.2939289 9.77921347 17.32 9.63783078 17.4017138 9.54608402 17.5481341 9.53421347 17.711L9.42421347 18.689C9.40757151 18.7797082 9.32373241 18.8421882 9.23205209 18.8322058 9.14037176 18.8222234 9.07194381 18.7431642 9.07521347 18.651L9.18521347 17.673C9.20962252 17.3919375 9.37284908 17.1416568 9.62021347 17.006 9.72111592 16.9545155 9.83293878 16.9281034 9.94621347 16.929L9.94821347 16.929C10.2532135 16.929 10.4902135 17.106 10.6182135 17.36 10.6671713 17.4570726 10.6986521 17.5620084 10.7112135 17.67L10.8322135 18.649 10.8322135 18.649zM11.3722135 18.67C11.3722135 18.7674783 11.2931917 18.8465 11.1957135 18.8465 11.0982352 18.8465 11.0192135 18.7674783 11.0192135 18.67L11.0192135 17.215C11.0192135 17.205 11.0192135 17.195 11.0222135 17.185 11.0242656 17.1655508 11.0286298 17.1464157 11.0352135 17.128 11.0667998 17.043903 11.1413946 16.983462 11.2302135 16.97L11.2322135 16.97 11.2322135 16.969C11.2461357 16.9671917 11.2601824 16.9665228 11.2742135 16.967L11.2782135 16.967C11.3502135 16.97 11.4182135 17.003 11.4642135 17.062L12.4012135 18.256 12.4012135 17.104C12.4012135 17.0067979 12.4800113 16.928 12.5772135 16.928 12.6744156 16.928 12.7532149 17.0067979 12.7532149 17.104L12.7532149 18.552C12.7535522 18.6512312 12.6944733 18.741031 12.6032135 18.78L12.6012135 18.78 12.6012135 18.781C12.5963427 18.783309 12.591333 18.7853129 12.5862135 18.787L12.5842135 18.787C12.4885773 18.8204861 12.3821923 18.791905 12.3162135 18.715L12.3102135 18.709 12.3072135 18.705 11.3712135 17.511 11.3712135 18.671 11.3722135 18.67zM14.1192135 18.494C14.2164156 18.494 14.2952135 18.5727979 14.2952135 18.67 14.2952135 18.7672021 14.2164156 18.8460029 14.1192135 18.8460029L13.6012135 18.8460029C13.4169903 18.8465332 13.2401587 18.7735868 13.1098927 18.6433208 12.9796267 18.5130548 12.9066803 18.3362232 12.9072106 18.152L12.9072106 17.622C12.9072106 17.2392667 13.2174801 16.929 13.6002135 16.929L13.6002135 16.928 14.1202135 16.928C14.2174156 16.928 14.2962135 17.0067979 14.2962135 17.104 14.2962135 17.2012021 14.2174156 17.28 14.1202135 17.28L13.6002135 17.28C13.4113321 17.28 13.2582135 17.4331186 13.2582135 17.622L13.2582135 18.152C13.2582135 18.246 13.2962135 18.332 13.3592135 18.394 13.4212135 18.456 13.5072135 18.494 13.6002135 18.494L14.1202135 18.494 14.1192135 18.494zM15.1372135 17.2789982L15.1372135 17.28C15.013339 17.2793821 14.894022 17.3266789 14.8042135 17.412 14.7182485 17.4926998 14.6690983 17.6050947 14.6682135 17.723L14.6682135 18.051C14.6682135 18.171 14.7202135 18.281 14.8032135 18.361 14.9892344 18.5407049 15.2841926 18.5407049 15.4702135 18.361 15.5560258 18.2806083 15.6051728 18.1685819 15.6062135 18.051L15.6062135 17.723C15.6062135 17.603 15.5542135 17.493 15.4712135 17.413 15.3814711 17.3267084 15.2617117 17.2786612 15.1372135 17.2789982M15.1372135 16.928C15.3622135 16.928 15.5662135 17.018 15.7142135 17.159 15.8689289 17.3058618 15.9567445 17.5096809 15.9572135 17.723L15.9572135 18.051C15.9567445 18.2643191 15.8689289 18.4681382 15.7142135 18.615 15.558784 18.7632798 15.3520267 18.845696 15.1372135 18.845L15.1372135 18.8460025C14.9222413 18.8465311 14.7154278 18.763734 14.5602135 18.615 14.4054981 18.4681382 14.3176824 18.2643191 14.3172135 18.051L14.3172135 17.723C14.3172135 17.503 14.4102135 17.303 14.5602135 17.159 14.7155857 17.0106311 14.9223805 16.9281999 15.1372135 16.929L15.1372135 16.928 15.1372135 16.928z"/><path fill="#424041" d="M7.72421347,17.28 L7.72421347,18.494 L8.40421347,18.494 C8.46279347,18.4939667 8.51894119,18.4705718 8.56021347,18.429 C8.64446063,18.3453314 8.64711602,18.2099068 8.56621347,18.123 L8.55921347,18.117 C8.51835028,18.0753058 8.4625906,18.051563 8.40421347,18.051 L8.40421347,18.052 L8.16821347,18.052 C8.07101135,18.052 7.99221347,17.9732021 7.99221347,17.876 C7.99221347,17.7787979 8.07101135,17.7 8.16821347,17.7 L8.24821347,17.7 C8.29853678,17.6959114 8.34572582,17.6739135 8.38121347,17.638 C8.42065632,17.5988187 8.44295256,17.5455954 8.44321347,17.49 C8.44321793,17.4340578 8.42090134,17.380426 8.38121347,17.341 C8.34203213,17.3015571 8.28880886,17.2792609 8.23321347,17.279 L8.23321347,17.28 L7.72321347,17.28 L7.72421347,17.28 Z M7.37221346,17.876 L7.37221346,17.112 C7.37221346,17.063009 7.3920422,17.0161042 7.42721347,16.982 L7.42921347,16.979 C7.46062108,16.9489439 7.50179703,16.9311956 7.54521347,16.929 L7.55521347,16.929 L7.55521347,16.928 L8.23421347,16.928 C8.38308187,16.928 8.525824,16.9872733 8.63090205,17.0927267 C8.7359801,17.19818 8.79474514,17.3411325 8.79421347,17.49 L8.79621347,17.49 L8.79521347,17.49 C8.79521347,17.6 8.76321347,17.702 8.70821347,17.789 C8.74521347,17.812 8.77821347,17.839 8.80821347,17.869 L8.81921347,17.88 C8.97707709,18.0455887 9.02086441,18.2894167 8.93048055,18.4995864 C8.84009669,18.7097561 8.63299299,18.8456879 8.40421347,18.845 L8.40421347,18.846 L7.54821347,18.846 C7.45101135,18.846 7.37221346,18.7672021 7.37221346,18.67 L7.37221346,17.876 L7.37221346,17.876 Z"/></g></svg>
                            </div>
                            <div class="w3-col l4 s4 w3-center">
                                <!-- MB WAY-->
                                <svg xmlns="http://www.w3.org/2000/svg" width="34" height="17"><g fill="none"><path fill="#C3242B" d="m1.344 14.75-.06.474a.387.387 0 0 0 .377.439h14.68a.389.389 0 0 0 .378-.439l-.06-.474c-.037-.37.219-.707.57-.746.353-.04.664.23.7.598l.057.462C18.1 16.095 17.544 17 16.552 17H1.45C.458 17-.1 16.095.016 15.064l.056-.462c.038-.368.348-.638.7-.598.352.039.608.376.572.746"/><path fill="#000" d="M16.33 6.289c0 .586-.213.917-.566 1.326l-.035.04.049.03c.698.415 1.185 1.041 1.22 1.921.055 1.311-1.085 2.397-2.437 2.394h-3.566a.628.628 0 0 1-.627-.628V4.628c0-.348.28-.628.626-.628l2.943.008c1.284.001 2.393.921 2.393 2.281m-1.776 4.496c.719.002 1.29-.509 1.276-1.18-.015-.687-.656-1.131-1.372-1.133h-1.445a.583.583 0 0 1-.583-.584c0-.325.262-.585.583-.585h.965c.65-.025 1.152-.41 1.183-1.01.033-.642-.534-1.125-1.226-1.125h-2.342l-.01 5.617h2.97M4.838 9.688l.016.048.018-.048c.165-.444.364-.936.576-1.472.218-.564.435-1.104.65-1.618.22-.522.428-.987.626-1.393.198-.415.362-.699.488-.855a.97.97 0 0 1 .774-.342h.148c.196 0 .35.05.465.145a.5.5 0 0 1 .185.312l.922 6.97a.56.56 0 0 1-.157.42c-.105.097-.254.145-.45.145-.194 0-.35-.045-.462-.134a.484.484 0 0 1-.216-.348c-.031-.232-.06-.49-.088-.772-.04-.282-.184-1.498-.225-1.805-.038-.315-.297-2.284-.385-3l-.008-.06-.295.604c-.1.207-.21.457-.33.748-.365.937-.717 1.878-1.055 2.825-.052.144-.152.435-.243.702-.092.266-.176.506-.2.553a.81.81 0 0 1-.735.438.806.806 0 0 1-.74-.438 9.425 9.425 0 0 1-.2-.553c-.092-.267-.19-.558-.245-.702 0 0-.57-1.59-.698-1.904a27.21 27.21 0 0 0-.358-.921c-.12-.291-.227-.54-.325-.748l-.297-.604-.007.06c-.09.716-.346 2.685-.386 3-.04.307-.184 1.523-.223 1.805-.03.282-.06.54-.091.772a.487.487 0 0 1-.214.348c-.116.089-.27.134-.465.134s-.343-.048-.447-.144a.572.572 0 0 1-.16-.422l.922-6.969a.516.516 0 0 1 .188-.312.704.704 0 0 1 .463-.145h.15c.32 0 .578.115.772.342.127.156.29.44.488.855.199.406.406.871.624 1.393.217.514.435 1.054.654 1.618.21.536.41 1.028.576 1.472"/><path fill="#C3242B" d="M3.67 0h10.66c1.005 0 1.505.822 1.622 1.905l.046.347c.036.372-.216.705-.55.744-.337.04-.64-.23-.674-.602l-.042-.332c-.045-.412-.205-.73-.59-.73H3.86c-.384 0-.544.318-.59.73l-.04.332c-.035.372-.336.642-.674.602-.337-.04-.587-.372-.55-.744l.045-.347C2.168.822 2.667 0 3.67 0"/><path fill="#000" d="m22.97 7.713-.24.912c-.083.322-.167.63-.25.925-.081.295-.158.553-.232.775-.047.158-.108.31-.184.457-.086.146-.24.218-.456.218-.06 0-.14-.012-.238-.036a.399.399 0 0 1-.244-.197 2.633 2.633 0 0 1-.184-.48c-.073-.238-.15-.511-.232-.822a47.594 47.594 0 0 1-.464-1.95c-.056-.253-.11-.506-.164-.76a8.337 8.337 0 0 1-.081-.43v-.03c0-.088.034-.16.105-.214a.415.415 0 0 1 .26-.081c.1 0 .178.02.239.06.06.037.102.106.13.204 0 .01.016.086.044.225l.115.534.155.73c.115.542.237 1.082.367 1.62.062.257.12.48.176.665.13-.43.256-.863.375-1.297.065-.241.127-.48.188-.721l.167-.67c.052-.208.096-.391.134-.55.038-.161.068-.28.09-.358a.42.42 0 0 1 .155-.232.458.458 0 0 1 .278-.086.47.47 0 0 1 .294.09.408.408 0 0 1 .146.228c.06.253.126.536.196.85.14.633.293 1.263.456 1.891.083.307.16.58.238.817.054-.186.113-.408.176-.666l.19-.8c.066-.272.128-.544.188-.813.06-.268.114-.51.164-.725l.162-.732c.027-.098.07-.167.13-.205A.43.43 0 0 1 25.558 6c.102 0 .19.027.26.081.069.05.11.13.107.214v.03a5.404 5.404 0 0 1-.087.43c-.044.21-.1.464-.166.76-.066.299-.14.618-.221.962-.08.343-.16.67-.24.98-.08.31-.154.583-.23.818a2.577 2.577 0 0 1-.182.476.424.424 0 0 1-.25.206.952.952 0 0 1-.24.043.93.93 0 0 1-.237-.04.533.533 0 0 1-.146-.072.34.34 0 0 1-.114-.137 3.356 3.356 0 0 1-.176-.487 36.55 36.55 0 0 1-.452-1.671c-.076-.313-.148-.607-.212-.88m6.078 1.178c-.105-.31-.214-.618-.327-.925a16.185 16.185 0 0 0-.404-1.002 4.615 4.615 0 0 1-.052-.134.669.669 0 0 0-.053.128 3.15 3.15 0 0 1-.086.204 14.07 14.07 0 0 0-.315.804c-.1.28-.208.59-.322.925h1.56-.001Zm-1.811.675a21.26 21.26 0 0 0-.216.689c-.05.176-.11.35-.176.52-.06.15-.18.225-.36.225-.124 0-.215-.03-.273-.089a.32.32 0 0 1-.085-.23.3.3 0 0 1 .016-.1l.103-.317c.056-.18.13-.406.224-.675l.305-.883c.215-.615.448-1.224.698-1.826.114-.271.22-.49.318-.655a.36.36 0 0 1 .175-.179.792.792 0 0 1 .299-.046c.12 0 .22.02.305.054.085.037.143.1.176.187.077.154.168.363.274.623.237.586.464 1.177.68 1.771.115.315.22.609.315.88l.244.694c.068.192.11.316.127.371a.34.34 0 0 1 .016.102.296.296 0 0 1-.098.23c-.065.058-.16.088-.285.088-.093 0-.162-.02-.21-.06a.395.395 0 0 1-.11-.165 10.97 10.97 0 0 1-.19-.52c-.073-.212-.152-.44-.233-.69h-2.04v.001Zm4.577-.52a1.038 1.038 0 0 1-.155-.193 4.936 4.936 0 0 1-.25-.376c-.09-.147-.18-.304-.27-.469-.171-.318-.333-.64-.487-.968l-.175-.376a1.426 1.426 0 0 1-.09-.222.353.353 0 0 1-.02-.058.366.366 0 0 1-.005-.058.3.3 0 0 1 .1-.232.4.4 0 0 1 .283-.094c.109 0 .186.026.233.077a.56.56 0 0 1 .1.156c.01.027.039.082.079.17l.15.326c.06.128.129.271.204.426.078.155.154.307.234.458.078.15.155.292.228.43.073.136.143.248.208.337.104-.15.215-.338.335-.566.272-.52.527-1.046.767-1.581a.59.59 0 0 1 .1-.156c.047-.051.125-.077.234-.077a.4.4 0 0 1 .282.094.3.3 0 0 1 .1.232c0 .02 0 .039-.003.058a.497.497 0 0 1-.02.058l-.093.225c-.204.458-.424.908-.66 1.35a14.9 14.9 0 0 1-.27.471c-.09.15-.174.277-.25.38a1.243 1.243 0 0 1-.155.178v1.605a.332.332 0 0 1-.102.252.372.372 0 0 1-.265.097.372.372 0 0 1-.265-.097.332.332 0 0 1-.102-.252V9.046"/></g></svg>
                            </div>
                        </div><br/>
                    </div>
                </div>
            </div>
            <!-- End page content -->
        </div>

        <!-- Accordion -->
        <script>
            function myAccFunc() {
                var x = document.getElementById("demoAcc");
                if (x.className.indexOf("w3-show") == -1) {
                    x.className += " w3-show";
                } else {
                    x.className = x.className.replace(" w3-show", "");
                }
            }

            // Open and close sidebar
            function w3_open() {
                document.getElementById("mySidebar").style.display = "block";
                document.getElementById("myOverlay").style.display = "block";
            }

            function w3_close() {
                document.getElementById("mySidebar").style.display = "none";
                document.getElementById("myOverlay").style.display = "none";
            }
        </script>
        <!-- Script para contar o itens -->
        <script>
            let count = document.getElementsByClassName("count").length;

            console.log(count);
            document.getElementById("countitens").innerHTML = count + " itens";

        </script>
        <!-- MOSTRAR OS FILTROS -->
        <script>
            $(document).ready(function() {
            // esconder todos os tbody
            $('#hide').hide();
        
            // adicionar evento de clique para cada thead
            $('thead.toggle').click(function() {
                // encontrar o tbody correspondente usando o próximo elemento
                var tbody = $(this).next('tbody');
        
                // alternar o estado de exibição do tbody
                tbody.slideToggle(200);
        
                // adicionar / remover a classe 'ativo' ao elemento clicado
                $(this).toggleClass('ativo');
            });
            });
        </script>
        <!-- LOG OUT -->
        <script>
            function confirmLogout() {
                if (confirm("Você tem certeza que deseja sair?")) {
                    window.location.href = "../php/LogOut.php";
                }
            }
        </script>
        <!-- Teste Botoes -->
        <script>
            function removerProduto(ref) {
                // Enviar uma solicitação AJAX para remover o produto do carrinho
                var xhr = new XMLHttpRequest();
                xhr.open("POST", "../php/remover_produto.php", true);
                xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                xhr.onreadystatechange = function () {
                    if (xhr.readyState === XMLHttpRequest.DONE) {
                        if (xhr.status === 200) {
                            // Atualizar a página após remover o produto
                            location.reload();
                        } else {
                            console.error("Ocorreu um erro ao remover o produto do carrinho.");
                        }
                    }
                };
                xhr.send("referencia=" + ref);
            }
        </script>
        <!-- Script Teste Count Carrinho -->
        <script>
            // Recupera os itens do carrinho
            var carrinho = <?php echo json_encode($_SESSION["carrinho"]); ?>;

            // Exibe o conteúdo do carrinho no console
            console.log(carrinho);
            console.log(carrinho.length);
        </script>
    </body>
</html>

