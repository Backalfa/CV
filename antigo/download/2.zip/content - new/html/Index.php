<?php
if (isset($_GET['success']) && $_GET['success'] == 1) {
    echo '<script>alert("Registro bem-sucedido!");</script>';
}

session_start(); // Iniciar a sessão

// Para saber se está logado
if (!isset($_SESSION['user_email'])) {
    echo '<script>console.log("Sem Sessão Iniciada!")</script>';
}else{
    echo '<script>console.log("Bem vindo, '. $_SESSION['user_email'] . '!")</script>';
    echo '<script>console.log("O user é '. $_SESSION['is_admin'] . ' !")</script>';
    echo '<script>console.log("1 é admin, 0 é user")</script>';
}

?>

<!DOCTYPE html>
<html>
    <head>
        <title>Beatriz Miranda Oriflame</title>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <!-- FALTA ADICIONAR PARA A PESQUISA-->
        <link rel="website icon" type="png" href="../imgs/icontab.png" />
        <link rel="stylesheet" href="../css/base_main/base_index.css" />
        <link rel="stylesheet" href="../css/base_main/main_index.css" />
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto" />
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <style>
            *{
                font-family: 'Merriweather', serif;
            }
        </style>
    </head>
    <body class="w3-content" style="max-width: 1200px;">
        <!-- Sidebar/menu -->
        <nav class="w3-sidebar w3-bar-block w3-white w3-collapse w3-top" style="z-index: 3; width: 250px;" id="mySidebar">
            <div class="w3-container w3-display-container w3-padding-16">
                <i onclick="w3_close()" class="fa fa-remove w3-hide-large w3-button w3-display-topright"></i>
                <img src="../imgs/LOGO.jpg" style="width: 100%;" />
            </div>
            <a class="w3-bar-item w3-button w3-padding" href="Index.php">Início</a>
            <a class="w3-bar-item w3-button w3-padding" href="#">Sobre Nós</a>
            <?php
                // Para saber se tem sessão
                if (!isset($_SESSION['user_email'])) {
                    // Sem Sessão
                }else{
                    // Para sair da sessão
                    echo '<a class="w3-bar-item w3-button w3-padding" href="tabela_precos.php">Serviços</a>';
                }
            ?>
            <a class="w3-bar-item w3-button w3-padding" href="#Contact">Contacte-nos</a>
            <a onclick="myAccFunc()" href="javascript:void(0)" class="w3-button w3-block w3-white w3-left-align" id="myBtn">
                Catálogo <i class="fa fa-caret-down"></i>
            </a>
            <div id="demoAcc" class="w3-bar-block w3-hide w3-padding-large w3-medium w3-show">
                <a href="catalogo.php?categoria=" class="w3-bar-item w3-button">Catálogo</a>
                <a href="https://pt.oriflame.com/products/digital-catalogue-current?PageNumber=1" class="w3-bar-item w3-button">Catálogo - Oriflame</a>
            </div>
            <a href="https://pt.oriflame.com/catalogue?cataloguecode=Norrsken%2F2023-norrsken-spring" class="w3-bar-item w3-button w3-padding" target="_blank">NORRSKEN - Jóias</a>
            <a href="https://pt.oriflame.com/catalogue?cataloguecode=FlyerC04&PageNumber=1" class="w3-bar-item w3-button w3-padding" target="_blank">Oportunidades</a>
        </nav>

        <!-- Top menu on small screens -->
        <header class="w3-bar w3-top w3-hide-large w3-black w3-xlarge">
            <div class="w3-bar-item w3-padding-24 w3-wide"></div>
            <a href="javascript:void(0)" class="w3-bar-item w3-button w3-padding-24 w3-right" onclick="w3_open()"><i class="fa fa-bars"></i></a>
        </header>

        <!-- Overlay effect when opening sidebar on small screens -->
        <div class="w3-overlay w3-hide-large" onclick="w3_close()" style="cursor: pointer;" title="close side menu" id="myOverlay"></div>

        <!-- !PAGE CONTENT! -->
        <div class="w3-main" style="margin-left: 250px;">
            <!-- Push down content on small screens -->
            <div class="w3-hide-large" style="margin-top: 83px;"></div>

            <!-- TOP HEADER / NAV BAR -->
            <header class="w3-container w3-xlarge">
                <p class="w3-right gap">
                    <script src="https://cdn.lordicon.com/bhenfmcm.js"></script>
                    <span style="position: relative; color: red;">
                    <!-- Conta Carrinho -->
                    <?php
                        if (isset($_SESSION["carrinho"])) {
                            if (count($_SESSION["carrinho"]) != 0) {
                                echo count($_SESSION["carrinho"]);
                            } else {
                                echo '';
                            }
                        } else {
                            echo '';
                        }
                        ?>
                    </span>
                    <?php
                    // Para saber se tem sessão
                    if (!isset($_SESSION['user_email'])) {
                        // Para fazer Log In
                        echo '<a class="nav-link" href="../login.html">Log In</a>';
                    } else {
                        // Para sair da sessão
                        echo '
                            <a href="main_carrinho.php" ><lord-icon
                                src="https://cdn.lordicon.com/lqsduwhb.json"
                                trigger="hover"
                                colors="primary:#000000"
                                style="width:40px;height:40px">
                            </lord-icon></a>
                            <a class="nav-link" href="#" onclick="confirmLogout()">Sair</a>';
                    }
                    ?>
                </p>
            </header>

            <!-- Image header -->
            <div class="w3-display-container w3-container">
                <img class="w3-hide-small" src="../imgs/top-view-salts-cream-container.jpg" alt="logo_pagina_centro" style="width: 100%;" />
                <img class="w3-hide-large w3-hide-medium" src="../imgs/top-view-salts-cream-container.jpg" alt="logo_pagina_centro" style="width: 100%;" />
                <div class="w3-display-topleft w3-text-black" style="padding: 24px 48px;">
                    <h1 class="w3-jumbo w3-hide-small">Beatriz Miranda</h1>
                    <h1 class="w3-hide-large w3-hide-medium">Beatriz Miranda</h1>
                    <p><a href="marcacao.php" class="w3-button w3-black w3-padding-large w3-large">AGENDA A TUA MARCAÇÃO!</a></p>
                </div>
            </div>

            <!-- Main Content -->

            <!------------ PARA DETERMINAR O DISPLAY A SEGUIR ------------>
            <?php
                // Para saber se é admin
                if (isset($_SESSION['user_email']) && ($_SESSION['is_admin'] == 1)) {
                    echo '
                    <!-- Atendimento Responsivo -->
                    <div class="w3-display-container w3-hide-large" style="margin: 80px 0;">
                        <div class="w3-center" style="background:#ffffff;">
                            <h2 class="w3-text-Orange">Contacte-nos</h2>
                            <p class="w3-opacity">+351 968 748 845</p>
                            <h4>Horário</h4>
                            <table class="w3-table w3-bordered w3-opacity">
                                <tr>
                                    <td>
                                        3ª a 6ª
                                    </td>
                                    <td>
                                        9:00 ás 19:30
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        Sábado
                                    </td>
                                    <td>
                                        9:00 ás 19:00
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
        
                    <!-- Imagens -->
                    <div class="w3-row main w3-hide-small w3-hide-medium">
                        <div class="w3-col s12 m12 l4 center">
                            <div class="w3-display-container w3-container" style="cursor: pointer;">
                                <img class="main_img w3-hover-opacity" src="../imgs/main/creative-green-design-nails-female-hands-art-manicure-photo-taken-studio_151428-1390.jpg">
                                <div class="w3-display-topmiddle text_imgs" style="margin-top:20px;padding:10px;">Nail Art</div>
                                <div class="w3-display-middle" style="background: #fff;opacity: 0.7;padding:10px;">Nail Art é uma forma criativa de decorar unhas, expressar estilo e acompanhar tendências de moda</div>
                            </div>
                        </div>
                        <div class="w3-col s12 m12 l4 center">
                            <div class="w3-display-container w3-container" style="cursor: pointer;">
                                <img class="main_img w3-hover-opacity" src="../imgs/main/beautician-doing-microblading-procedure-client-s-eyebrows.jpg">
                                <div class="w3-display-topmiddle text_imgs" style="margin-top:20px;padding:10px;">Microblading</div>
                                <div class="w3-display-middle" style="background: #fff;opacity: 0.7;padding:10px;">Microblading é uma técnica de beleza semipermanente para realçar as sobrancelhas, criando um visual natural e definido.</div>
                            </div>
                        </div>
                        <div class="w3-col s12 m12 l4 center">
                            <div class="w3-display-container w3-container" style="cursor: pointer;">
                                <img class="main_img w3-hover-opacity" src="../imgs/main/girl-holding-make-up-brushes-front-mirror.jpg">
                                <div class="w3-display-topmiddle text_imgs" style="margin-top:20px;padding:10px;">Maquilhagem</div>
                                <div class="w3-display-middle" style="background: #fff;opacity: 0.7;padding:10px;">Maquilhagem é a arte de realçar a beleza facial através da aplicação de produtos cosméticos, destacando traços e expressões.</div>
                            </div>
                        </div>
                    </div>
        
                    <!-- Frase -->
                    <div class="w3-display-container w3-hide-small w3-hide-medium" style="margin: 40px 0;">
                        <img class="w3-opacity" src="../imgs/organic-spa-products-white-background.jpg" style="max-width: 100%;height: auto;">
                        <div class="w3-display-topleft" style="margin-top: 150px">
                            <p>Acreditamos que a beleza vem do interior e que cada</p>
                            <p> um de nós é responsável por encontrar o seu próprio equilíbrio!</p>
                        </div>
                    </div>
        
                    <!-- Box Service -->
                    <script src="https://cdn.lordicon.com/bhenfmcm.js"></script>
                    <div class="w3-container" style="background: #f1f1f1;">
                        <div class="w3-row">
                            <div class="w3-col s12 m12 l6 w3-round-large">
                                <div class="w3-row w3-container" style="height:200px">
                                    <div class="w3-col s3 m3 l3 w3-center">
                                        <lord-icon
                                            src="https://cdn.lordicon.com/jffauosv.json"
                                            trigger="hover"
                                            colors="primary:#000000"
                                            style="width:80px;height:80px;margin-top:40px;">
                                        </lord-icon>
                                    </div>
                                    <div class="w3-col s9 m9 l9">
                                        <h6><u>Tecnologia avançada</u></h6>
                                        <h6>Dispomos dos equipamentos mais avançados e inovadores para que consiga alcançar os resultados pretendidos.</h6>
                                    </div>
                                </div>
                            </div>
                            <div class="w3-col s12 m12 l6 w3-round-large">
                                <div class="w3-row w3-container" style="height:200px">
                                    <div class="w3-col s3 m3 l3 w3-center">
                                        <lord-icon
                                            src="https://cdn.lordicon.com/hbvyhtse.json"
                                            trigger="hover"
                                            colors="primary:#000000"
                                            style="width:80px;height:80px;margin-top:40px;">
                                        </lord-icon>
                                    </div>
                                    <div class="w3-col s9 m9 l9">
                                        <h6><u>Atenção ao detalhe</u></h6>
                                        <h6>Cada cliente é especial e único, e por isso disponibilizamos serviços totalmente personalizados.</h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="w3-row">
                            <div class="w3-col s12 m12 l6 w3-round-large">
                                <div class="w3-row w3-container" style="height:200px">
                                    <div class="w3-col s3 m3 l3 w3-center">
                                        <lord-icon
                                            src="https://cdn.lordicon.com/xryjrepg.json"
                                            trigger="hover"
                                            colors="primary:#000000"
                                            style="width:80px;height:80px;margin-top:40px;">
                                        </lord-icon>
                                    </div>
                                    <div class="w3-col s9 m9 l9">
                                        <h6><u>Os seus objetivos são também os nossos</u></h6>
                                        <h6>Dispõem de profissionais especializados, que frequentemente atualiza os seus conhecimentos e adquire novas competências.</h6>
                                    </div>
                                </div>
                            </div>
                            <div class="w3-col s12 m12 l6 w3-round-large">
                                <div class="w3-row w3-container" style="height:200px">
                                    <div class="w3-col s3 m3 l3 w3-center">
                                        <lord-icon
                                            src="https://cdn.lordicon.com/iizhfivi.json"
                                            trigger="hover"
                                            colors="primary:#000000"
                                            style="width:80px;height:80px;margin-top:40px;">
                                        </lord-icon>
                                    </div>
                                    <div class="w3-col s9 m9 l9">
                                        <h6><u>Relação qualidade/preço</u></h6>
                                        <h6>Encontrará o equilíbrio perfeito no que diz respeito à relação qualidade/preço considerando a prestação de serviço de excelência levada a cabo, fruto de variadas e frutíferas circunstâncias.</h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Atendimento PC -->
                    <div class="w3-display-container w3-hide-small w3-hide-medium" style="margin: 80px 0;">
                        <img class="" src="../imgs/v722-aum-35a.jpg" style="max-width: 100%;height: auto;opacity:0.0">
                                <!-- Carrosel -->
                        <div class="w3-display-topleft" style="z-index:999;margin-top:-50px">
                            <div class="w3-content w3-section" style="max-width:500px">
                                <img class="mySlides" src="../imgs/main/beauty-portrait-happy-female-model-applies-green-nourishing-mask-face.jpg" style="width: 100%; border-radius: 10px;">
                                <img class="mySlides" src="../imgs/main/pleased-european-woman-with-curly-hair-keeps-hands-cheeks-smiles-pleasantly-keeps-eyes-closed-recalls-pleasant-memories-wears-shirt-isolated-beige-background-happy-feelings-concept.jpg" style="width:100%; border-radius: 10px;">
                                <img class="mySlides" src="../imgs/main/positive-woman-with-bushy-curly-hair-keeps-eyes-closed-applies-green-patches-undergoes-beauty-procedures-holds-calla-feels-happy-isolated-white-background-skin-care-rejuvenation-concept_273609-.jpg" style="width:100%; border-radius: 10px;">
                                <img class="mySlides" src="../imgs/main/relieved-ethnic-woman-wears-beauty-facial-mask-stands-with-eyes-shut-meditates-home-while-undergoes-.jpg" style="width:100%; border-radius: 10px;">
                            </div>
                        </div>
        
                        <div class="w3-display-topleft" style="z-index:500;margin-left:50px">
                            <img class="" src="../imgs/v722-aum-35a.jpg" style="max-width:100%;height: auto;">
                        </div>
        
                        <div class="w3-display-right w3-padding-large w3-center" style="margin-right:80px;background:#ffffff;z-index:999;">
                            <h2 class="w3-text-Orange">Contacte-nos</h2>
                            <p class="w3-opacity">+351 968 748 845</p>
                            <h4>Horário</h4>
                            <table class="w3-table w3-bordered w3-opacity">
                                <tr>
                                    <td>
                                        3ª a 6ª
                                    </td>
                                    <td>
                                        9:00 ás 19:30
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        Sábado
                                    </td>
                                    <td>
                                        9:00 ás 19:00
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
        
                    <!-- Imagens Responsivo -->
                    <div class="w3-hide-large" style="display: flex;justify-content: center;">
                        <div class="w3-content w3-display-container main" style="width:80%;">
                            <div class="w3-display-container mySlidesSmall">
                                <img style="width: 100%; border-radius: 10px;" class="w3-hover-opacity" src="../imgs/main/creative-green-design-nails-female-hands-art-manicure-photo-taken-studio_151428-1390.jpg">
                                <div class="w3-display-topmiddle text_imgs" style="margin-top:20px;padding:20px;">Nail Art</div>
                                <div class="w3-display-middle" style="background: #fff;opacity: 0.7;padding:20px;">Nail Art é uma forma criativa de decorar unhas, expressar estilo e acompanhar tendências de moda</div>
                            </div>
                            <div class="w3-display-container mySlidesSmall">
                                <img style="width: 100%; border-radius: 10px;" class="w3-hover-opacity" src="../imgs/main/beautician-doing-microblading-procedure-client-s-eyebrows.jpg">
                                <div class="w3-display-topmiddle text_imgs" style="margin-top:20px;padding:20px;">Microblading</div>
                                <div class="w3-display-middle" style="background: #fff;opacity: 0.7;padding:20px;">Microblading é uma técnica de beleza semipermanente para realçar as sobrancelhas, criando um visual natural e definido.</div>
                            </div>
                            <div class="w3-display-container mySlidesSmall">
                                <img style="width: 100%; border-radius: 10px;" class="w3-hover-opacity" src="../imgs/main/girl-holding-make-up-brushes-front-mirror.jpg">
                                <div class="w3-display-topmiddle text_imgs" style="margin-top:20px;padding:20px;">Maquilhagem</div>
                                <div class="w3-display-middle" style="background: #fff;opacity: 0.7;padding:20px;">Maquilhagem é a arte de realçar a beleza facial através da aplicação de produtos cosméticos, destacando traços e expressões.</div>
                            </div>
                            <button class="w3-button w3-display-left w3-black" onclick="plusDivs(-1)">&#10094;</button>
                            <button class="w3-button w3-display-right w3-black" onclick="plusDivs(1)">&#10095;</button>
                        </div>
                    </div>
        
                    <!-- Footer -->
                    <footer class="w3-padding-64 w3-light-grey w3-small w3-center" id="footer">
                        <div class="w3-row-padding">
                            <h2 id="Contact">Contactos</h2>';

                            require('../php/conecçao.php');

                            // Executar consulta SQL para recuperar os registros da tabela
                            $sql = "SELECT * FROM contacto_index";
                            $result = $conn->query($sql);

                            // Verificar se existem registros retornados
                            if ($result->num_rows > 0) {
                                // Iterar sobre os registros e exibir as informações
                                while ($row = mysqli_fetch_assoc($result)) {
                                    $id = $row["id"];
                                    $nome = $row["nome"];
                                    $email = $row["email"];
                                    $assunto = $row["assunto"];
                                    $mensagem = $row["mensagem"];

                                    // Faça o que você precisa com as informações recuperadas
                                    echo '<button onclick="myFunction(' . $id . ')" class="w3-button w3-block w3-black w3-left-align" style="margin-bottom: 10px;">' . $nome . ' (' . $assunto . ')</button>
                                            <div id="' . $id .'" class="w3-hide w3-container" style="margin-bottom: 10px;">
                                                <div class="w3-container">
                                                    <div class="w3-row"">
                                                        <div class="w3-col s4 m4 l4">
                                                            <div class="w3-row">
                                                                <div class="w3-col s4 m4 l4" style="background:#ccc;border: 1px solid black;"><strong>Nome:</strong></div>
                                                                <div class="w3-col s8 m8 l8" style="border: 1px solid black;">' . $nome . '</div>
                                                            </div>            
                                                        </div>
                                                        <div class="w3-col s4 m4 l4 ">
                                                            <div class="w3-row">
                                                                <div class="w3-col s4 m4 l4" style="background:#ccc;border: 1px solid black;"><strong>Email:</strong></div>
                                                                <div class="w3-col s8 m8 l8" style="border: 1px solid black;">' . $email . '</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="w3-row">
                                                        <div class="w3-col s12 m12 l12">
                                                            <div class="w3-row" style="background:#ccc">
                                                                <div class="w3-col s4 m4 l4" style="border: 1px solid black;"><strong>Asssunto:</strong></div>
                                                                <div class="w3-col s8 m8 l8" style="border: 1px solid black;">' . $assunto . '</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="w3-row">
                                                        <div class="w3-col s12 m12 l12" style="background:#ccc;border: 1px solid black;"><strong>Mensagem:</strong></div>
                                                        <div class="w3-col s12 m12 l12" style="border: 1px solid black;">' . $mensagem . '</div>
                                                    </div><br>
                                                    <div class="w3-row">
                                                        <div class="w3-col s12 m12 l12">
                                                            <button class="w3-button w3-red" onclick="apagarDados(' . $id . ')">Apagar</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <script>
                                                function apagarDados(id) {
                                                    // Exibe uma caixa de diálogo de confirmação antes de excluir o registro
                                                    if (confirm("Tem certeza que deseja excluir este registro?")) {
                                                    // Redireciona para o arquivo que processa a exclusão do registro
                                                    window.location.href = "../php/delete_contactos.php?id=" + id;
                                                    }
                                                }
                                            </script>';
                                }
                            } else {
                                echo "Nenhum registro encontrado.";
                            }

                            $conn->close();
                        echo '</div>
                    </footer>';
                }else{
                    echo '
                    <!-- Atendimento Responsivo -->
                    <div class="w3-display-container w3-hide-large" style="margin: 80px 0;">
                        <div class="w3-center" style="background:#ffffff;">
                            <h2 class="w3-text-Orange">Contacte-nos</h2>
                            <p class="w3-opacity">+351 968 748 845</p>
                            <h4>Horário</h4>
                            <table class="w3-table w3-bordered w3-opacity">
                                <tr>
                                    <td>
                                        3ª a 6ª
                                    </td>
                                    <td>
                                        9:00 ás 19:30
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        Sábado
                                    </td>
                                    <td>
                                        9:00 ás 19:00
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
        
                    <!-- Imagens -->
                    <div class="w3-row main w3-hide-small w3-hide-medium">
                        <div class="w3-col s12 m12 l4 center">
                            <div class="w3-display-container w3-container" style="cursor: pointer;">
                                <img class="main_img w3-hover-opacity" src="../imgs/main/creative-green-design-nails-female-hands-art-manicure-photo-taken-studio_151428-1390.jpg">
                                <div class="w3-display-topmiddle text_imgs" style="margin-top:20px;padding:10px;">Nail Art</div>
                                <div class="w3-display-middle" style="background: #fff;opacity: 0.7;padding:10px;">Nail Art é uma forma criativa de decorar unhas, expressar estilo e acompanhar tendências de moda</div>
                            </div>
                        </div>
                        <div class="w3-col s12 m12 l4 center">
                            <div class="w3-display-container w3-container" style="cursor: pointer;">
                                <img class="main_img w3-hover-opacity" src="../imgs/main/beautician-doing-microblading-procedure-client-s-eyebrows.jpg">
                                <div class="w3-display-topmiddle text_imgs" style="margin-top:20px;padding:10px;">Microblading</div>
                                <div class="w3-display-middle" style="background: #fff;opacity: 0.7;padding:10px;">Microblading é uma técnica de beleza semipermanente para realçar as sobrancelhas, criando um visual natural e definido.</div>
                            </div>
                        </div>
                        <div class="w3-col s12 m12 l4 center">
                            <div class="w3-display-container w3-container" style="cursor: pointer;">
                                <img class="main_img w3-hover-opacity" src="../imgs/main/girl-holding-make-up-brushes-front-mirror.jpg">
                                <div class="w3-display-topmiddle text_imgs" style="margin-top:20px;padding:10px;">Maquilhagem</div>
                                <div class="w3-display-middle" style="background: #fff;opacity: 0.7;padding:10px;">Maquilhagem é a arte de realçar a beleza facial através da aplicação de produtos cosméticos, destacando traços e expressões.</div>
                            </div>
                        </div>
                    </div>
        
                    <!-- Frase -->
                    <div class="w3-display-container w3-hide-small w3-hide-medium" style="margin: 40px 0;">
                        <img class="w3-opacity" src="../imgs/organic-spa-products-white-background.jpg" style="max-width: 100%;height: auto;">
                        <div class="w3-display-topleft" style="margin-top: 150px">
                            <p>Acreditamos que a beleza vem do interior e que cada</p>
                            <p> um de nós é responsável por encontrar o seu próprio equilíbrio!</p>
                        </div>
                    </div>
        
                    <!-- Box Service -->
                    <script src="https://cdn.lordicon.com/bhenfmcm.js"></script>
                    <div class="w3-container" style="background: #f1f1f1;">
                        <div class="w3-row">
                            <div class="w3-col s12 m12 l6 w3-round-large">
                                <div class="w3-row w3-container" style="height:200px">
                                    <div class="w3-col s3 m3 l3 w3-center">
                                        <lord-icon
                                            src="https://cdn.lordicon.com/jffauosv.json"
                                            trigger="hover"
                                            colors="primary:#000000"
                                            style="width:80px;height:80px;margin-top:40px;">
                                        </lord-icon>
                                    </div>
                                    <div class="w3-col s9 m9 l9">
                                        <h6><u>Tecnologia avançada</u></h6>
                                        <h6>Dispomos dos equipamentos mais avançados e inovadores para que consiga alcançar os resultados pretendidos.</h6>
                                    </div>
                                </div>
                            </div>
                            <div class="w3-col s12 m12 l6 w3-round-large">
                                <div class="w3-row w3-container" style="height:200px">
                                    <div class="w3-col s3 m3 l3 w3-center">
                                        <lord-icon
                                            src="https://cdn.lordicon.com/hbvyhtse.json"
                                            trigger="hover"
                                            colors="primary:#000000"
                                            style="width:80px;height:80px;margin-top:40px;">
                                        </lord-icon>
                                    </div>
                                    <div class="w3-col s9 m9 l9">
                                        <h6><u>Atenção ao detalhe</u></h6>
                                        <h6>Cada cliente é especial e único, e por isso disponibilizamos serviços totalmente personalizados.</h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="w3-row">
                            <div class="w3-col s12 m12 l6 w3-round-large">
                                <div class="w3-row w3-container" style="height:200px">
                                    <div class="w3-col s3 m3 l3 w3-center">
                                        <lord-icon
                                            src="https://cdn.lordicon.com/xryjrepg.json"
                                            trigger="hover"
                                            colors="primary:#000000"
                                            style="width:80px;height:80px;margin-top:40px;">
                                        </lord-icon>
                                    </div>
                                    <div class="w3-col s9 m9 l9">
                                        <h6><u>Os seus objetivos são também os nossos</u></h6>
                                        <h6>Dispõem de profissionais especializados, que frequentemente atualiza os seus conhecimentos e adquire novas competências.</h6>
                                    </div>
                                </div>
                            </div>
                            <div class="w3-col s12 m12 l6 w3-round-large">
                                <div class="w3-row w3-container" style="height:200px">
                                    <div class="w3-col s3 m3 l3 w3-center">
                                        <lord-icon
                                            src="https://cdn.lordicon.com/iizhfivi.json"
                                            trigger="hover"
                                            colors="primary:#000000"
                                            style="width:80px;height:80px;margin-top:40px;">
                                        </lord-icon>
                                    </div>
                                    <div class="w3-col s9 m9 l9">
                                        <h6><u>Relação qualidade/preço</u></h6>
                                        <h6>Encontrará o equilíbrio perfeito no que diz respeito à relação qualidade/preço considerando a prestação de serviço de excelência levada a cabo, fruto de variadas e frutíferas circunstâncias.</h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Atendimento PC -->
                    <div class="w3-display-container w3-hide-small w3-hide-medium" style="margin: 80px 0;">
                        <img class="" src="../imgs/v722-aum-35a.jpg" style="max-width: 100%;height: auto;opacity:0.0">
                                <!-- Carrosel -->
                        <div class="w3-display-topleft" style="z-index:999;margin-top:-50px">
                            <div class="w3-content w3-section" style="max-width:500px">
                                <img class="mySlides" src="../imgs/main/beauty-portrait-happy-female-model-applies-green-nourishing-mask-face.jpg" style="width: 100%; border-radius: 10px;">
                                <img class="mySlides" src="../imgs/main/pleased-european-woman-with-curly-hair-keeps-hands-cheeks-smiles-pleasantly-keeps-eyes-closed-recalls-pleasant-memories-wears-shirt-isolated-beige-background-happy-feelings-concept.jpg" style="width:100%; border-radius: 10px;">
                                <img class="mySlides" src="../imgs/main/positive-woman-with-bushy-curly-hair-keeps-eyes-closed-applies-green-patches-undergoes-beauty-procedures-holds-calla-feels-happy-isolated-white-background-skin-care-rejuvenation-concept_273609-.jpg" style="width:100%; border-radius: 10px;">
                                <img class="mySlides" src="../imgs/main/relieved-ethnic-woman-wears-beauty-facial-mask-stands-with-eyes-shut-meditates-home-while-undergoes-.jpg" style="width:100%; border-radius: 10px;">
                            </div>
                        </div>
        
                        <div class="w3-display-topleft" style="z-index:500;margin-left:50px">
                            <img class="" src="../imgs/v722-aum-35a.jpg" style="max-width:100%;height: auto;">
                        </div>
        
                        <div class="w3-display-right w3-padding-large w3-center" style="margin-right:80px;background:#ffffff;z-index:999;">
                            <h2 class="w3-text-Orange">Contacte-nos</h2>
                            <p class="w3-opacity">+351 968 748 845</p>
                            <h4>Horário</h4>
                            <table class="w3-table w3-bordered w3-opacity">
                                <tr>
                                    <td>
                                        3ª a 6ª
                                    </td>
                                    <td>
                                        9:00 ás 19:30
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        Sábado
                                    </td>
                                    <td>
                                        9:00 ás 19:00
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
        
                    <!-- Imagens Responsivo -->
                    <div class="w3-hide-large" style="display: flex;justify-content: center;">
                        <div class="w3-content w3-display-container main" style="width:80%;">
                            <div class="w3-display-container mySlidesSmall">
                                <img style="width: 100%; border-radius: 10px;" class="w3-hover-opacity" src="../imgs/main/creative-green-design-nails-female-hands-art-manicure-photo-taken-studio_151428-1390.jpg">
                                <div class="w3-display-topmiddle text_imgs" style="margin-top:20px;padding:20px;">Nail Art</div>
                                <div class="w3-display-middle" style="background: #fff;opacity: 0.7;padding:20px;">Nail Art é uma forma criativa de decorar unhas, expressar estilo e acompanhar tendências de moda</div>
                            </div>
                            <div class="w3-display-container mySlidesSmall">
                                <img style="width: 100%; border-radius: 10px;" class="w3-hover-opacity" src="../imgs/main/beautician-doing-microblading-procedure-client-s-eyebrows.jpg">
                                <div class="w3-display-topmiddle text_imgs" style="margin-top:20px;padding:20px;">Microblading</div>
                                <div class="w3-display-middle" style="background: #fff;opacity: 0.7;padding:20px;">Microblading é uma técnica de beleza semipermanente para realçar as sobrancelhas, criando um visual natural e definido.</div>
                            </div>
                            <div class="w3-display-container mySlidesSmall">
                                <img style="width: 100%; border-radius: 10px;" class="w3-hover-opacity" src="../imgs/main/girl-holding-make-up-brushes-front-mirror.jpg">
                                <div class="w3-display-topmiddle text_imgs" style="margin-top:20px;padding:20px;">Maquilhagem</div>
                                <div class="w3-display-middle" style="background: #fff;opacity: 0.7;padding:20px;">Maquilhagem é a arte de realçar a beleza facial através da aplicação de produtos cosméticos, destacando traços e expressões.</div>
                            </div>
                            <button class="w3-button w3-display-left w3-black" onclick="plusDivs(-1)">&#10094;</button>
                            <button class="w3-button w3-display-right w3-black" onclick="plusDivs(1)">&#10095;</button>
                        </div>
                    </div>
        
                    <!-- Footer -->
                    <footer class="w3-padding-64 w3-light-grey w3-small w3-center" id="footer">
                        <div class="w3-row-padding">
                            <div class="w3-col s12 m12 l8">
                                <h2 id="Contact">Contactos</h2>
                                <p>Questões? Vai em frente.</p>
                                <form action="../php/contacto.php" method="POST">
                                    <p><input class="w3-input w3-border" type="text" placeholder="Nome" name="Name" required="" /></p>
                                    <p><input class="w3-input w3-border" type="text" placeholder="Email" name="Email" required="" /></p>
                                    <p><input class="w3-input w3-border" type="text" placeholder="Assunto" name="Subject" required="" /></p>
                                    <p><input class="w3-input w3-border" type="text" placeholder="Messagem" name="Message" required="" /></p>
                                    <button type="submit" class="w3-button w3-block w3-black">Enviar</button>
                                </form>
                            </div>
        
                            <div class="w3-col s12 m12 l4">
                                <h2>Loja</h2>
                                <p><i class="fa fa-fw fa-map-marker"></i> Beatriz Miranda</p>
                                <p><i class="fa fa-fw fa-phone"></i> 0044123123</p>
                                <p><i class="fa fa-fw fa-envelope"></i> beatrizmiranda@hotmail.com</p>
                                <br />
                            </div>
        
                            <!-- Redes Sociais -->
                            <!--
                            <div class="w3-col s12 m12 l12 gap" style="margin-top:60px;display: flex; justify-content: center;">
                                <i class="fa fa-facebook-official w3-hover-opacity w3-xxlarge"></i>
                                <i class="fa fa-instagram w3-hover-opacity w3-xxlarge"></i>
                                <i class="fa fa-snapchat w3-hover-opacity w3-xxlarge"></i>
                                <i class="fa fa-pinterest-p w3-hover-opacity w3-xxlarge"></i>
                                <i class="fa fa-twitter w3-hover-opacity w3-xxlarge"></i>
                                <i class="fa fa-linkedin w3-hover-opacity w3-xxlarge"></i>
                            </div>-->
                        </div>
                    </footer>';
                };
            ?>
            <!-- End page content -->
        </div>

        
        <!-- Accordion -->
        <script>
            function myAccFunc() {
                var x = document.getElementById("demoAcc");
                if (x.className.indexOf("w3-show") == -1) {
                    x.className += " w3-show";
                } else {
                    x.className = x.className.replace(" w3-show", "");
                }
            }

            // Open and close sidebar
            function w3_open() {
                document.getElementById("mySidebar").style.display = "block";
                document.getElementById("myOverlay").style.display = "block";
            }

            function w3_close() {
                document.getElementById("mySidebar").style.display = "none";
                document.getElementById("myOverlay").style.display = "none";
            }
        </script>
        <!-- LOG OUT -->
        <script>
            function confirmLogout() {
                if (confirm("Você tem certeza que deseja sair?")) {
                    window.location.href = "../php/LogOut.php";
                }
            }
        </script>
        <!-- Slides PC -->
        <script>
            var myIndex = 0;
            carousel();

            function carousel() {
            var i;
            var x = document.getElementsByClassName("mySlides");
            for (i = 0; i < x.length; i++) {
                x[i].style.display = "none";  
            }
            myIndex++;
            if (myIndex > x.length) {myIndex = 1}    
            x[myIndex-1].style.display = "block";  
            setTimeout(carousel, 4000); // Change image every 4 seconds
            }
        </script>
        <!-- Slides Responsivo -->
        <script>
            var slideIndex = 1;
            showDivs(slideIndex);

            function plusDivs(n) {
                showDivs(slideIndex += n);
            }

            function showDivs(n) {
                var i;
                var x = document.getElementsByClassName("mySlidesSmall");
                if (n > x.length) {slideIndex = 1}
                if (n < 1) {slideIndex = x.length}
                for (i = 0; i < x.length; i++) {
                    x[i].style.display = "none";  
                }
                x[slideIndex-1].style.display = "block";  
            }
        </script>
        <!-- Admin Contacts -->
        <script>
            function myFunction(id) {
                var x = document.getElementById(id);

                if (x.className.indexOf("w3-show") == -1) {
                    x.className += " w3-show";
                } else { 
                    x.className = x.className.replace(" w3-show", "");
                }
            }
        </script>
    </body>
</html>
