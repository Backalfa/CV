<?php

    session_start(); // Iniciar a sessão

    require('../php/conecçao.php');

    // Para saber se está logado
    if (!isset($_SESSION['user_email'])) {
        echo '<script>console.log("Sem Sessão Iniciada!")</script>';
    }else{
        echo '<script>console.log("Bem vindo, '. $_SESSION['user_email'] . '!")</script>';
        echo '<script>console.log("O user é '. $_SESSION['is_admin'] . ' !")</script>';
    }
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Beatriz Miranda Oriflame</title>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <!-- FALTA ADICIONAR PARA A PESQUISA-->
        <link rel="website icon" type="png" href="../imgs/icontab.png" />
        <link rel="stylesheet" href="../css/base_main/base_tabela_precos.css" />
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto" />
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <!-- JQUERY -->
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <style>
            *{
                font-family: 'Merriweather', serif;
            }
            .toggle:hover{
                cursor: pointer;
                background: #ccc;
            }
        </style>
    </head>
    <body class="w3-content" style="max-width: 1200px;">
        <!-- Sidebar/menu -->
        <nav class="w3-sidebar w3-bar-block w3-white w3-collapse w3-top" style="z-index: 3; width: 250px;" id="mySidebar">
            <div class="w3-container w3-display-container w3-padding-16">
                <i onclick="w3_close()" class="fa fa-remove w3-hide-large w3-button w3-display-topright"></i>
                <img src="../imgs/LOGO.jpg" style="width: 100%;" />
            </div>
            <a class="w3-bar-item w3-button w3-padding" href="Index.php">Início</a>
            <a class="w3-bar-item w3-button w3-padding" href="#">Sobre Nós</a>
            <?php
                // Para saber se tem sessão
                if (!isset($_SESSION['user_email'])) {
                    // Sem Sessão
                }else{
                    // Para sair da sessão
                    echo '<a class="w3-bar-item w3-button w3-padding" href="tabela_precos.php">Serviços</a>';
                }
            ?>
            <a class="w3-bar-item w3-button w3-padding" href="#Contact">Contacte-nos</a>
            <a onclick="myAccFunc()" href="javascript:void(0)" class="w3-button w3-block w3-white w3-left-align" id="myBtn">
                Catálogo <i class="fa fa-caret-down"></i>
            </a>
            <div id="demoAcc" class="w3-bar-block w3-hide w3-padding-large w3-medium w3-show">
                <a href="catalogo.php?categoria=" class="w3-bar-item w3-button">Catálogo</a>
                <a href="https://pt.oriflame.com/products/digital-catalogue-current?PageNumber=1" class="w3-bar-item w3-button">Catálogo - Oriflame</a>
            </div>
            <a href="https://pt.oriflame.com/catalogue?cataloguecode=Norrsken%2F2023-norrsken-spring" class="w3-bar-item w3-button w3-padding" target="_blank">NORRSKEN - Jóias</a>
            <a href="https://pt.oriflame.com/catalogue?cataloguecode=FlyerC04&PageNumber=1" class="w3-bar-item w3-button w3-padding" target="_blank">Oportunidades</a>
        </nav>

        <!-- Top menu on small screens -->
        <header class="w3-bar w3-top w3-hide-large w3-black w3-xlarge">
            <div class="w3-bar-item w3-padding-24 w3-wide"></div>
            <a href="javascript:void(0)" class="w3-bar-item w3-button w3-padding-24 w3-right" onclick="w3_open()"><i class="fa fa-bars"></i></a>
        </header>

        <!-- Overlay effect when opening sidebar on small screens -->
        <div class="w3-overlay w3-hide-large" onclick="w3_close()" style="cursor: pointer;" title="close side menu" id="myOverlay"></div>

        <!-- !PAGE CONTENT! -->
        <div class="w3-main" style="margin-left: 250px;">
            <!-- Push down content on small screens -->
            <div class="w3-hide-large" style="margin-top: 83px;"></div>

            <!-- TOP HEADER / NAV BAR -->
            <header class="w3-container w3-xlarge">
                <p class="w3-right gap">
                    <script src="https://cdn.lordicon.com/bhenfmcm.js"></script>
                    <span style="position: relative; color: red;">
                    <!-- Conta Carrinho -->
                    <?php
                        if (isset($_SESSION["carrinho"])) {
                            if (count($_SESSION["carrinho"]) != 0) {
                                echo count($_SESSION["carrinho"]);
                            } else {
                                echo '';
                            }
                        } else {
                            echo '';
                        }
                        ?>
                    </span>
                    <?php
                    // Para saber se tem sessão
                    if (!isset($_SESSION['user_email'])) {
                        // Para fazer Log In
                        echo '<a class="nav-link" href="../login.html">Log In</a>';
                    } else {
                        // Para sair da sessão
                        echo '
                            <a href="main_carrinho.php" ><lord-icon
                                src="https://cdn.lordicon.com/lqsduwhb.json"
                                trigger="hover"
                                colors="primary:#000000"
                                style="width:40px;height:40px">
                            </lord-icon></a>
                            <a class="nav-link" href="#" onclick="confirmLogout()">Sair</a>';
                    }
                    ?>
                </p>
            </header>

            <!-- Image header -->
            <div class="w3-display-container w3-container">
                <img class="w3-hide-small" src="../imgs/top-view-salts-cream-container.jpg" alt="logo_pagina_centro" style="width: 100%;" />
                <img class="w3-hide-large w3-hide-medium" src="../imgs/top-view-salts-cream-container.jpg" alt="logo_pagina_centro" style="width: 100%;" />
                <div class="w3-display-topleft w3-text-black" style="padding: 24px 48px;">
                    <h1 class="w3-jumbo w3-hide-small">Beatriz Miranda</h1>
                    <h1 class="w3-hide-large w3-hide-medium">Beatriz Miranda</h1>
                    <p><a href="marcacao.php" class="w3-button w3-black w3-padding-large w3-large">AGENDA A TUA MARCAÇÃO!</a></p>
                </div>
            </div>

            <!-- MAIN CONTENT -->

            <h1 align="center">Tabela de Preços</h1>

            <?php
                // Para saber se é admin
                if (isset($_SESSION['user_email']) && ($_SESSION['is_admin'] == 1)) {
                    // ADMIN

                    echo '
                    <div class="w3-row" style="margin: 60px 0;">
                        <div class="w3-col s12 m12 l12">';

                        echo '
                            <!-- TABELA Epilação -->
                            <table style="width:100%">
                                <thead class="toggle" id="epilacao">
                                    <tr>
                                        <th class="upercase" colspan="2">Epilação</th>
                                    </tr>
                                </thead>
                                <tbody class="hide">
                                    <tr>
                                        <th> </th>
                                        <th>Preço</th>
                                        <th>Tempo</th>
                                        <th>Acções</th>
                                    </tr>';

                                    // Query para buscar os dados da tabela
                                    $sql = "SELECT * FROM epilacao";
                                    $result = $conn->query($sql);
                                    
                                    // Verifica se a query retornou resultados
                                    if ($result->num_rows > 0) {
                                        // Exibe os dados em uma tabela
                                        while($row = $result->fetch_assoc()) {
                                            echo "<tr>";
                                            echo "<td>" . $row["nome"] . "</td>";
                                            echo "<td class='w3-center'>" . $row["preco"] . "€ </td>";
                                            echo "<td class='w3-center'>" . $row["tempo"] . " min</td>";
                                            echo '<td class="w3-center">
                                                    <button type="button" class="w3-button w3-blue w3-small" onclick="editRecord(\'' . $row["nome"] . '\')">
                                                    <span class="w3-button-icon">
                                                        <i class="fa fa-pencil"></i>
                                                    </span>
                                                    Editar
                                                    </button>
                                                    <button type="button" class="w3-button w3-red w3-small" onclick="deleteRecord(\'' . $row["nome"] . '\')">
                                                    <span class="w3-button-icon">
                                                        <i class="fa fa-trash"></i>
                                                    </span>
                                                    Excluir
                                                    </button>
                                                </td>';
                                            echo '
                                            </tr>
                                            <script>
                                                function addProduct() {
                                                    // Redireciona para a página de adicionar produto
                                                    window.location.href = "../php/precos/epilação/adicionar_tabela_epilacao.php";
                                                }
                                                function editRecord(nome) {
                                                    // Redireciona para a página de edição do registro com a referência especificada
                                                    window.location.href = "../php/precos/epilação/edite_tabela_epilacao.php?nome=" + nome;
                                                }
                                                
                                                function deleteRecord(nome) {
                                                    // Exibe uma caixa de diálogo de confirmação antes de excluir o registro
                                                    if (confirm("Tem certeza que deseja excluir este Serviço?")) {
                                                        // Redireciona para o arquivo que processa a exclusão do registro
                                                        window.location.href = "../php/precos/epilação/delet_tabela_epilacao.php?nome=" + nome;
                                                    }
                                                }
                                            </script>';
                                            
                                        }
                                    } else {
                                        echo "<tr><td colspan='2'>Nenhum resultado encontrado.</td></tr>";
                                    }
                                    
                                echo '
                                <tr>
                                    <td colspan="4">
                                        <button type="button" class="w3-button w3-green w3-small" onclick="addProduct(epilacao)" style="margin-top: 40px; width:100%;">
                                        <span class="w3-button-icon">
                                            <i class="fa fa-plus"></i>
                                        </span>
                                        Adicionar Serviço
                                        </button>
                                    </td>
                                </tr>
                                </tbody>
                            </table><br>';


                        echo '
                            <!-- TABELA Microblanding -->
                            <table style="width:100%">
                                <thead class="toggle" id="microblanding">
                                    <tr>
                                        <th class="upercase" colspan="2">Microblanding</th>
                                    </tr>
                                </thead>
                                <tbody class="hide">
                                    <tr>
                                        <th> </th>
                                        <th>Preço</th>
                                        <th>Tempo</th>
                                        <th>Acções</th>
                                    </tr>';
                                    
                                        // Query para buscar os dados da tabela
                                        $sql = "SELECT * FROM microblanding";
                                        $result = $conn->query($sql);
                                        
                                        // Verifica se a query retornou resultados
                                        if ($result->num_rows > 0) {
                                            // Exibe os dados em uma tabela
                                            while($row = $result->fetch_assoc()) {
                                                echo "<tr>";
                                                echo "<td>" . $row["nome"] . "</td>";
                                                echo "<td class='w3-center'>" . $row["preco"] . "€ </td>";
                                                echo "<td class='w3-center'>" . $row["tempo"] . " min</td>";
                                                echo '<td class="w3-center">
                                                        <button type="button" class="w3-button w3-blue w3-small" onclick="editRecord1(\'' . $row["nome"] . '\')">
                                                        <span class="w3-button-icon">
                                                            <i class="fa fa-pencil"></i>
                                                        </span>
                                                        Editar
                                                        </button>
                                                        <button type="button" class="w3-button w3-red w3-small" onclick="deleteRecord1(\'' . $row["nome"] . '\')">
                                                        <span class="w3-button-icon">
                                                            <i class="fa fa-trash"></i>
                                                        </span>
                                                        Excluir
                                                        </button>
                                                    </td>';
                                                echo '
                                                </tr>
                                                <script>
                                                    function addProduct1() {
                                                        // Redireciona para a página de adicionar produto
                                                        window.location.href = "../php/precos/microblanding/adicionar_tabela.php";
                                                    }
                                                    function editRecord1(nome) {
                                                        // Redireciona para a página de edição do registro com a referência especificada
                                                        window.location.href = "../php/precos/microblanding/edite_tabela.php?nome=" + nome;
                                                    }
                                                    
                                                    function deleteRecord1(nome) {
                                                        // Exibe uma caixa de diálogo de confirmação antes de excluir o registro
                                                        if (confirm("Tem certeza que deseja excluir este Serviço?")) {
                                                            // Redireciona para o arquivo que processa a exclusão do registro
                                                            window.location.href = "../php/precos/microblanding/delet_tabela.php?nome=" + nome;
                                                        }
                                                    }
                                                </script>';
                                                    
                                                }
                                        } else {
                                            echo "<tr><td colspan='2'>Nenhum resultado encontrado.</td></tr>";
                                        }
                                        
                                    echo '
                                    <tr>
                                        <td colspan="4">
                                            <button type="button" class="w3-button w3-green w3-small" onclick="addProduct1()" style="margin-top: 40px; width:100%;">
                                            <span class="w3-button-icon">
                                                <i class="fa fa-plus"></i>
                                            </span>
                                            Adicionar Serviço
                                            </button>
                                        </td>
                                    </tr>
                                </tbody>
                            </table><br>';

                                
                        echo '
                            <!-- TABELA Unhas - Gel -->
                            <table style="width:100%">
                                <thead class="toggle" id="unhas_gel">
                                    <tr>
                                        <th class="upercase" colspan="5">Unhas - Gel</th>
                                    </tr>
                                </thead>
                                <tbody class="hide">
                                    <tr>
                                        <th> </th>
                                        <th>S</th>
                                        <th>M</th>
                                        <th>L</th>
                                        <th>XL</th>
                                        <th>Tempo</th>
                                        <th>Acções</th>
                                    </tr>';
                                    
                                        // Query para buscar os dados da tabela
                                        $sql = "SELECT * FROM gel";
                                        $result = $conn->query($sql);
                                        
                                        // Verifica se a query retornou resultados
                                        if ($result->num_rows > 0) {
                                            // Exibe os dados em uma tabela
                                            while($row = $result->fetch_assoc()) {
                                                echo "<tr>";
                                                echo "<td>" . $row["nome"] . "</td>";
                                                echo "<td class='w3-center'>" . $row["s"] . "€ </td>";
                                                echo "<td class='w3-center'>" . $row["m"] . "€ </td>";
                                                echo "<td class='w3-center'>" . $row["l"] . "€ </td>";
                                                echo "<td class='w3-center'>" . $row["xl"] . "€ </td>";
                                                echo "<td class='w3-center'>" . $row["tempo"] . " min</td>";
                                                echo '<td class="w3-center">
                                                        <button type="button" class="w3-button w3-blue w3-small" onclick="editRecord3(\'' . $row["nome"] . '\')">
                                                        <span class="w3-button-icon">
                                                            <i class="fa fa-pencil"></i>
                                                        </span>
                                                        Editar
                                                        </button>
                                                        <button type="button" class="w3-button w3-red w3-small" onclick="deleteRecord3(\'' . $row["nome"] . '\')">
                                                        <span class="w3-button-icon">
                                                            <i class="fa fa-trash"></i>
                                                        </span>
                                                        Excluir
                                                        </button>
                                                    </td>';
                                                echo '
                                                </tr>
                                                <script>
                                                    function addProduct3() {
                                                        // Redireciona para a página de adicionar produto
                                                        window.location.href = "../php/precos/unhas-gel/adicionar_tabela.php";
                                                    }
                                                    function editRecord3(nome) {
                                                        // Redireciona para a página de edição do registro com a referência especificada
                                                        window.location.href = "../php/precos/unhas-gel/edite_tabela.php?nome=" + nome;
                                                    }
                                                    
                                                    function deleteRecord3(nome) {
                                                        // Exibe uma caixa de diálogo de confirmação antes de excluir o registro
                                                        if (confirm("Tem certeza que deseja excluir este Serviço?")) {
                                                            // Redireciona para o arquivo que processa a exclusão do registro
                                                            window.location.href = "../php/precos/unhas-gel/delet_tabela.php?nome=" + nome;
                                                        }
                                                    }
                                                </script>';
                                            }
        
                                        } else {
                                            echo "<tr><td colspan='2'>Nenhum resultado encontrado.</td></tr>";
                                        }
                                        
                                echo '
                                    <tr>
                                        <td colspan="7">
                                            <button type="button" class="w3-button w3-green w3-small" onclick="addProduct3()" style="margin-top: 40px; width:100%;">
                                                <span class="w3-button-icon">
                                                    <i class="fa fa-plus"></i>
                                                </span>
                                                Adicionar Serviço
                                            </button>
                                        </td>
                                    </tr>
                                </tbody>
                            </table><br>';

                        echo '
                            <!-- TABELA Unhas - Acrílico -->
                            <table style="width:100%">
                                <thead class="toggle" id="unhas_acrilico">
                                    <tr>
                                        <th class="upercase" colspan="5">Unhas - Acrílico</th>
                                    </tr>
                                </thead>
                                <tbody class="hide">
                                    <tr>
                                        <th> </th>
                                        <th>S</th>
                                        <th>M</th>
                                        <th>L</th>
                                        <th>XL</th>
                                        <th>Tempo</th>
                                        <th>Acções</th>
                                    </tr>';
                                    
                                        // Query para buscar os dados da tabela
                                        $sql = "SELECT * FROM acrilico";
                                        $result = $conn->query($sql);
                                        
                                        // Verifica se a query retornou resultados
                                        if ($result->num_rows > 0) {
                                            // Exibe os dados em uma tabela
                                            while($row = $result->fetch_assoc()) {
                                                echo "<tr>";
                                                echo "<td>" . $row["nome"] . "</td>";
                                                echo "<td class='w3-center'>" . $row["s"] . "€ </td>";
                                                echo "<td class='w3-center'>" . $row["m"] . "€ </td>";
                                                echo "<td class='w3-center'>" . $row["l"] . "€ </td>";
                                                echo "<td class='w3-center'>" . $row["xl"] . "€ </td>";
                                                echo "<td class='w3-center'>" . $row["tempo"] . " min</td>";
                                                echo '<td class="w3-center">
                                                        <button type="button" class="w3-button w3-blue w3-small" onclick="editRecord4(\'' . $row["nome"] . '\')">
                                                        <span class="w3-button-icon">
                                                            <i class="fa fa-pencil"></i>
                                                        </span>
                                                        Editar
                                                        </button>
                                                        <button type="button" class="w3-button w3-red w3-small" onclick="deleteRecord4(\'' . $row["nome"] . '\')">
                                                        <span class="w3-button-icon">
                                                            <i class="fa fa-trash"></i>
                                                        </span>
                                                        Excluir
                                                        </button>
                                                    </td>';
                                                echo '
                                                </tr>
                                                <script>
                                                    function addProduct4() {
                                                        // Redireciona para a página de adicionar produto
                                                        window.location.href = "../php/precos/unhas-acrilico/adicionar_tabela.php";
                                                    }
                                                    function editRecord4(nome) {
                                                        // Redireciona para a página de edição do registro com a referência especificada
                                                        window.location.href = "../php/precos/unhas-acrilico/edite_tabela.php?nome=" + nome;
                                                    }
                                                    
                                                    function deleteRecord4(nome) {
                                                        // Exibe uma caixa de diálogo de confirmação antes de excluir o registro
                                                        if (confirm("Tem certeza que deseja excluir este Serviço?")) {
                                                            // Redireciona para o arquivo que processa a exclusão do registro
                                                            window.location.href = "../php/precos/unhas-acrilico/delet_tabela.php?nome=" + nome;
                                                        }
                                                    }
                                                </script>';
                                            }
                                        } else {
                                            echo "<tr><td colspan='2'>Nenhum resultado encontrado.</td></tr>";
                                        }
                                        
                                echo '
                                    <tr>
                                        <td colspan="7">
                                            <button type="button" class="w3-button w3-green w3-small" onclick="addProduct4()" style="margin-top: 40px; width:100%;">
                                                <span class="w3-button-icon">
                                                    <i class="fa fa-plus"></i>
                                                </span>
                                                Adicionar Serviço
                                            </button>
                                        </td>
                                    </tr>
                                </tbody>
                            </table><br>';

                        echo '
                            <!-- TABELA Escolher Nome -->
                            <table style="width:100%">
                                <thead class="toggle" id="escolher_nome">
                                    <tr>
                                        <th class="upercase" colspan="2">Outros</th>
                                    </tr>
                                </thead>
                                <tbody class="hide">
                                    <tr>
                                        <th> </th>
                                        <th>Preço</th>
                                        <th>Tempo</th>
                                        <th>Acções</th>
                                    </tr>';
                                    
                                        // Query para buscar os dados da tabela
                                        $sql = "SELECT * FROM falta";
                                        $result = $conn->query($sql);
                                        
                                        // Verifica se a query retornou resultados
                                        if ($result->num_rows > 0) {
                                            // Exibe os dados em uma tabela
                                            while($row = $result->fetch_assoc()) {
                                                echo "<tr>";
                                                echo "<td>" . $row["nome"] . "</td>";
                                                echo "<td class='w3-center'>" . $row["preco"] . "€ </td>";
                                                echo "<td class='w3-center'>" . $row["tempo"] . " min</td>";
                                                echo '<td class="w3-center">
                                                        <button type="button" class="w3-button w3-blue w3-small" onclick="editRecord5(\'' . $row["nome"] . '\')">
                                                        <span class="w3-button-icon">
                                                            <i class="fa fa-pencil"></i>
                                                        </span>
                                                        Editar
                                                        </button>
                                                        <button type="button" class="w3-button w3-red w3-small" onclick="deleteRecord5(\'' . $row["nome"] . '\')">
                                                        <span class="w3-button-icon">
                                                            <i class="fa fa-trash"></i>
                                                        </span>
                                                        Excluir
                                                        </button>
                                                    </td>';
                                                echo '
                                                </tr>
                                                <script>
                                                    function addProduct5() {
                                                        // Redireciona para a página de adicionar produto
                                                        window.location.href = "../php/precos/outros/adicionar_tabela.php";
                                                    }
                                                    function editRecord5(nome) {
                                                        // Redireciona para a página de edição do registro com a referência especificada
                                                        window.location.href = "../php/precos/outros/edite_tabela.php?nome=" + nome;
                                                    }
                                                    
                                                    function deleteRecord5(nome) {
                                                        // Exibe uma caixa de diálogo de confirmação antes de excluir o registro
                                                        if (confirm("Tem certeza que deseja excluir este Serviço?")) {
                                                            // Redireciona para o arquivo que processa a exclusão do registro
                                                            window.location.href = "../php/precos/outros/delet_tabela.php?nome=" + nome;
                                                        }
                                                    }
                                                </script>';
                                            }
                                        } else {
                                            echo "<tr><td colspan='2'>Nenhum resultado encontrado.</td></tr>";
                                        }
                                        
                                        echo '
                                            <tr>
                                                <td colspan="7">
                                                    <button type="button" class="w3-button w3-green w3-small" onclick="addProduct5()" style="margin-top: 40px; width:100%;">
                                                        <span class="w3-button-icon">
                                                            <i class="fa fa-plus"></i>
                                                        </span>
                                                        Adicionar Serviço
                                                    </button>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table><br>';

                        echo '
                            <!-- TABELA Nail Art -->
                            <table style="width:100%">
                                <thead class="toggle" id="nail_art">
                                    <tr>
                                        <th class="upercase" colspan="2">Nail Art</th>
                                    </tr>
                                </thead>
                                <tbody class="hide">
                                    <tr>
                                        <th> </th>
                                        <th>Preço</th>
                                        <th>Tempo</th>
                                        <th>Acções</th>
                                    </tr>';
                                    
                                        // Query para buscar os dados da tabela
                                        $sql = "SELECT * FROM nail_art";
                                        $result = $conn->query($sql);
                                        
                                        // Verifica se a query retornou resultados
                                        if ($result->num_rows > 0) {
                                            // Exibe os dados em uma tabela
                                            while($row = $result->fetch_assoc()) {
                                                echo "<tr>";
                                                echo "<td>" . $row["nome"] . "</td>";
                                                echo "<td class='w3-center'>" . $row["preco"] . "€ </td>";
                                                echo "<td class='w3-center'>" . $row["tempo"] . " min</td>";
                                                echo '<td class="w3-center">
                                                        <button type="button" class="w3-button w3-blue w3-small" onclick="editRecord6(\'' . $row["nome"] . '\')">
                                                        <span class="w3-button-icon">
                                                            <i class="fa fa-pencil"></i>
                                                        </span>
                                                        Editar
                                                        </button>
                                                        <button type="button" class="w3-button w3-red w3-small" onclick="deleteRecord6(\'' . $row["nome"] . '\')">
                                                        <span class="w3-button-icon">
                                                            <i class="fa fa-trash"></i>
                                                        </span>
                                                        Excluir
                                                        </button>
                                                    </td>';
                                                echo '
                                                </tr>
                                                <script>
                                                    function addProduct6() {
                                                        // Redireciona para a página de adicionar produto
                                                        window.location.href = "../php/precos/nail art/adicionar_tabela.php";
                                                    }
                                                    function editRecord6(nome) {
                                                        // Redireciona para a página de edição do registro com a referência especificada
                                                        window.location.href = "../php/precos/nail art/edite_tabela.php?nome=" + nome;
                                                    }
                                                    
                                                    function deleteRecord6(nome) {
                                                        // Exibe uma caixa de diálogo de confirmação antes de excluir o registro
                                                        if (confirm("Tem certeza que deseja excluir este Serviço?")) {
                                                            // Redireciona para o arquivo que processa a exclusão do registro
                                                            window.location.href = "../php/precos/nail art/delet_tabela.php?nome=" + nome;
                                                        }
                                                    }
                                                </script>';
                                            }
                                        } else {
                                            echo "<tr><td colspan='2'>Nenhum resultado encontrado.</td></tr>";
                                        }
                                        
                                        echo '
                                            <tr>
                                                <td colspan="7">
                                                    <button type="button" class="w3-button w3-green w3-small" onclick="addProduct6()" style="margin-top: 40px; width:100%;">
                                                        <span class="w3-button-icon">
                                                            <i class="fa fa-plus"></i>
                                                        </span>
                                                        Adicionar Serviço
                                                    </button>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table><br>';

                            echo '
                                <!-- TABELA Threading -->
                                <table style="width:100%">
                                    <thead class="toggle" id="threading">
                                        <tr>
                                            <th class="upercase" colspan="2">Threading</th>
                                        </tr>
                                    </thead>
                                    <tbody class="hide">
                                        <tr>
                                            <th> </th>
                                            <th>Preço</th>
                                            <th>Tempo</th>
                                            <th>Acções</th>
                                        </tr>';
                                        
                                            // Query para buscar os dados da tabela
                                            $sql = "SELECT * FROM threading";
                                            $result = $conn->query($sql);
                                            
                                            // Verifica se a query retornou resultados
                                            if ($result->num_rows > 0) {
                                                // Exibe os dados em uma tabela
                                                while($row = $result->fetch_assoc()) {
                                                    echo "<tr>";
                                                    echo "<td>" . $row["nome"] . "</td>";
                                                    echo "<td class='w3-center'>" . $row["preco"] . "€ </td>";
                                                    echo "<td class='w3-center'>" . $row["tempo"] . " min</td>";
                                                    echo '<td class="w3-center">
                                                            <button type="button" class="w3-button w3-blue w3-small" onclick="editRecord7(\'' . $row["nome"] . '\')">
                                                            <span class="w3-button-icon">
                                                                <i class="fa fa-pencil"></i>
                                                            </span>
                                                            Editar
                                                            </button>
                                                            <button type="button" class="w3-button w3-red w3-small" onclick="deleteRecord7(\'' . $row["nome"] . '\')">
                                                            <span class="w3-button-icon">
                                                                <i class="fa fa-trash"></i>
                                                            </span>
                                                            Excluir
                                                            </button>
                                                        </td>';
                                                    echo '
                                                    </tr>
                                                    <script>
                                                        function addProduct7() {
                                                            // Redireciona para a página de adicionar produto
                                                            window.location.href = "../php/precos/threading/adicionar_tabela.php";
                                                        }
                                                        function editRecord7(nome) {
                                                            // Redireciona para a página de edição do registro com a referência especificada
                                                            window.location.href = "../php/precos/threading/edite_tabela.php?nome=" + nome;
                                                        }
                                                        
                                                        function deleteRecord7(nome) {
                                                            // Exibe uma caixa de diálogo de confirmação antes de excluir o registro
                                                            if (confirm("Tem certeza que deseja excluir este Serviço?")) {
                                                                // Redireciona para o arquivo que processa a exclusão do registro
                                                                window.location.href = "../php/precos/threading/delet_tabela.php?nome=" + nome;
                                                            }
                                                        }
                                                    </script>';
                                                }
                                                echo "<tr>";
                                                echo "<td>*inclui sobrancelha, buço, maçãs rosto, queixo.</td>";
                                                echo "</tr>";
                                                
                                            } else {
                                                echo "<tr><td colspan='2'>Nenhum resultado encontrado.</td></tr>";
                                            }
                                        
                                            echo '
                                                <tr>
                                                    <td colspan="6">
                                                        <button type="button" class="w3-button w3-green w3-small" onclick="addProduct7()" style="margin-top: 40px; width:100%;">
                                                            <span class="w3-button-icon">
                                                                <i class="fa fa-plus"></i>
                                                            </span>
                                                            Adicionar Serviço
                                                        </button>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table><br>';
    
                            echo '
                                <!-- TABELA Manicure / Pedicure -->
                                <table style="width:100%">
                                    <thead class="toggle" id="manicure_pedicure">
                                        <tr>
                                            <th class="upercase" colspan="2">Manicure / Pedicure</th>
                                        </tr>
                                    </thead>
                                    <tbody class="hide">
                                        <tr>
                                            <th> </th>
                                            <th>Preço</th>
                                            <th>Tempo</th>
                                            <th>Acções</th>
                                        </tr>';
                                        
                                            // Query para buscar os dados da tabela
                                            $sql = "SELECT * FROM manicure_pedicure";
                                            $result = $conn->query($sql);
                                            
                                            // Verifica se a query retornou resultados
                                            if ($result->num_rows > 0) {
                                                // Exibe os dados em uma tabela
                                                while($row = $result->fetch_assoc()) {
                                                    echo "<tr>";
                                                    echo "<td>" . $row["nome"] . "</td>";
                                                    echo "<td class='w3-center'>" . $row["preco"] . "€ </td>";
                                                    echo "<td class='w3-center'>" . $row["tempo"] . " min</td>";
                                                    echo '<td class="w3-center">
                                                            <button type="button" class="w3-button w3-blue w3-small" onclick="editRecord8(\'' . $row["nome"] . '\')">
                                                            <span class="w3-button-icon">
                                                                <i class="fa fa-pencil"></i>
                                                            </span>
                                                            Editar
                                                            </button>
                                                            <button type="button" class="w3-button w3-red w3-small" onclick="deleteRecord8(\'' . $row["nome"] . '\')">
                                                            <span class="w3-button-icon">
                                                                <i class="fa fa-trash"></i>
                                                            </span>
                                                            Excluir
                                                            </button>
                                                        </td>';
                                                    echo '
                                                    </tr>
                                                    <script>
                                                        function addProduct8() {
                                                            // Redireciona para a página de adicionar produto
                                                            window.location.href = "../php/precos/manicure-pedicure/adicionar_tabela.php";
                                                        }
                                                        function editRecord8(nome) {
                                                            // Redireciona para a página de edição do registro com a referência especificada
                                                            window.location.href = "../php/precos/manicure-pedicure/edite_tabela.php?nome=" + nome;
                                                        }
                                                        
                                                        function deleteRecord8(nome) {
                                                            // Exibe uma caixa de diálogo de confirmação antes de excluir o registro
                                                            if (confirm("Tem certeza que deseja excluir este Serviço?")) {
                                                                // Redireciona para o arquivo que processa a exclusão do registro
                                                                window.location.href = "../php/precos/manicure-pedicure/delet_tabela.php?nome=" + nome;
                                                            }
                                                        }
                                                    </script>';
                                                }
                                            } else {
                                                echo "<tr><td colspan='2'>Nenhum resultado encontrado.</td></tr>";
                                            }
                                        
                                            echo '
                                                <tr>
                                                    <td colspan="6">
                                                        <button type="button" class="w3-button w3-green w3-small" onclick="addProduct8()" style="margin-top: 40px; width:100%;">
                                                            <span class="w3-button-icon">
                                                                <i class="fa fa-plus"></i>
                                                            </span>
                                                            Adicionar Serviço
                                                        </button>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table><br>';
                                
                            echo '
                                <!-- TABELA Tratamentos de Rosto -->
                                <table style="width:100%">
                                    <thead class="toggle" id="tratamentos_rosto">
                                        <tr>
                                            <th class="upercase" colspan="2">Tratamentos de Rosto</th>
                                        </tr>
                                    </thead>
                                    <tbody class="hide">
                                        <tr>
                                            <th> </th>
                                            <th>Preço</th>
                                            <th>Tempo</th>
                                            <th>Acções</th>
                                        </tr>';
                                        
                                            // Query para buscar os dados da tabela
                                            $sql = "SELECT * FROM tratamentos_rosto";
                                            $result = $conn->query($sql);
                                            
                                            // Verifica se a query retornou resultados
                                            if ($result->num_rows > 0) {
                                                // Exibe os dados em uma tabela
                                                while($row = $result->fetch_assoc()) {
                                                    echo "<tr>";
                                                    echo "<td>" . $row["nome"] . "</td>";
                                                    echo "<td class='w3-center'>" . $row["preco"] . "€ </td>";
                                                    echo "<td class='w3-center'>" . $row["tempo"] . " min</td>";
                                                    echo '<td class="w3-center">
                                                            <button type="button" class="w3-button w3-blue w3-small" onclick="editRecord9(\'' . $row["nome"] . '\')">
                                                            <span class="w3-button-icon">
                                                                <i class="fa fa-pencil"></i>
                                                            </span>
                                                            Editar
                                                            </button>
                                                            <button type="button" class="w3-button w3-red w3-small" onclick="deleteRecord9(\'' . $row["nome"] . '\')">
                                                            <span class="w3-button-icon">
                                                                <i class="fa fa-trash"></i>
                                                            </span>
                                                            Excluir
                                                            </button>
                                                        </td>';
                                                    echo '
                                                    </tr>
                                                    <script>
                                                        function addProduct9() {
                                                            // Redireciona para a página de adicionar produto
                                                            window.location.href = "../php/precos/tratamentos rosto/adicionar_tabela.php";
                                                        }
                                                        function editRecord9(nome) {
                                                            // Redireciona para a página de edição do registro com a referência especificada
                                                            window.location.href = "../php/precos/tratamentos rosto/edite_tabela.php?nome=" + nome;
                                                        }
                                                        
                                                        function deleteRecord9(nome) {
                                                            // Exibe uma caixa de diálogo de confirmação antes de excluir o registro
                                                            if (confirm("Tem certeza que deseja excluir este Serviço?")) {
                                                                // Redireciona para o arquivo que processa a exclusão do registro
                                                                window.location.href = "../php/precos/tratamentos rosto/delet_tabela.php?nome=" + nome;
                                                            }
                                                        }
                                                    </script>';
                                                }
                                            } else {
                                                echo "<tr><td colspan='2'>Nenhum resultado encontrado.</td></tr>";
                                            }
                                        
                                            echo '
                                                <tr>
                                                    <td colspan="6">
                                                        <button type="button" class="w3-button w3-green w3-small" onclick="addProduct9()" style="margin-top: 40px; width:100%;">
                                                            <span class="w3-button-icon">
                                                                <i class="fa fa-plus"></i>
                                                            </span>
                                                            Adicionar Serviço
                                                        </button>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table><br>';
    
                            echo '
                                <!-- TABELA Maquilhagem -->
                                <table style="width:100%">
                                    <thead class="toggle" id="maquilhagem">
                                        <tr>
                                            <th class="upercase" colspan="2">Maquilhagem</th>
                                        </tr>
                                    </thead>
                                    <tbody class="hide">
                                        <tr>
                                            <th> </th>
                                            <th>Preço</th>
                                            <th>Tempo</th>
                                            <th>Acções</th>
                                        </tr>';
                                        
                                            // Query para buscar os dados da tabela
                                            $sql = "SELECT * FROM maquilhagem";
                                            $result = $conn->query($sql);
                                            
                                            // Verifica se a query retornou resultados
                                            if ($result->num_rows > 0) {
                                                // Exibe os dados em uma tabela
                                                while($row = $result->fetch_assoc()) {
                                                    echo "<tr>";
                                                    echo "<td>" . $row["nome"] . "</td>";
                                                    echo "<td class='w3-center'>" . $row["preco"] . "€ </td>";
                                                    echo "<td class='w3-center'>" . $row["tempo"] . " min</td>";
                                                    echo '<td class="w3-center">
                                                            <button type="button" class="w3-button w3-blue w3-small" onclick="editRecord10(\'' . $row["nome"] . '\')">
                                                            <span class="w3-button-icon">
                                                                <i class="fa fa-pencil"></i>
                                                            </span>
                                                            Editar
                                                            </button>
                                                            <button type="button" class="w3-button w3-red w3-small" onclick="deleteRecord10(\'' . $row["nome"] . '\')">
                                                            <span class="w3-button-icon">
                                                                <i class="fa fa-trash"></i>
                                                            </span>
                                                            Excluir
                                                            </button>
                                                        </td>';
                                                    echo '
                                                    </tr>
                                                    <script>
                                                        function addProduct10() {
                                                            // Redireciona para a página de adicionar produto
                                                            window.location.href = "../php/precos/maquilhagem/adicionar_tabela.php";
                                                        }
                                                        function editRecord10(nome) {
                                                            // Redireciona para a página de edição do registro com a referência especificada
                                                            window.location.href = "../php/precos/maquilhagem/edite_tabela.php?nome=" + nome;
                                                        }
                                                        
                                                        function deleteRecord10(nome) {
                                                            // Exibe uma caixa de diálogo de confirmação antes de excluir o registro
                                                            if (confirm("Tem certeza que deseja excluir este Serviço?")) {
                                                                // Redireciona para o arquivo que processa a exclusão do registro
                                                                window.location.href = "../php/precos/maquilhagem/delet_tabela.php?nome=" + nome;
                                                            }
                                                        }
                                                    </script>';
                                                }
                                            } else {
                                                echo "<tr><td colspan='2'>Nenhum resultado encontrado.</td></tr>";
                                            }
                                        
                                            echo '
                                                <tr>
                                                    <td colspan="6">
                                                        <button type="button" class="w3-button w3-green w3-small" onclick="addProduct10()" style="margin-top: 40px; width:100%;">
                                                            <span class="w3-button-icon">
                                                                <i class="fa fa-plus"></i>
                                                            </span>
                                                            Adicionar Serviço
                                                        </button>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table><br>';
                                
                            echo '
                                <!-- TABELA Massagens -->
                                <table style="width:100%">
                                    <thead class="toggle" id="massagens">
                                        <tr>
                                            <th class="upercase" colspan="2">Massagens</th>
                                        </tr>
                                    </thead>
                                    <tbody class="hide">
                                        <tr>
                                            <th> </th>
                                            <th>Preço</th>
                                            <th>Tempo</th>
                                            <th>Acções</th>
                                        </tr>';
                                        
                                            // Query para buscar os dados da tabela
                                            $sql = "SELECT * FROM massagens";
                                            $result = $conn->query($sql);
                                            
                                            // Verifica se a query retornou resultados
                                            if ($result->num_rows > 0) {
                                                // Exibe os dados em uma tabela
                                                while($row = $result->fetch_assoc()) {
                                                    echo "<tr>";
                                                    echo "<td>" . $row["nome"] . "</td>";
                                                    echo "<td class='w3-center'>" . $row["preco"] . "€ </td>";
                                                    echo "<td class='w3-center'>" . $row["tempo"] . " min</td>";
                                                    echo '<td class="w3-center">
                                                            <button type="button" class="w3-button w3-blue w3-small" onclick="editRecord11(\'' . $row["nome"] . '\')">
                                                            <span class="w3-button-icon">
                                                                <i class="fa fa-pencil"></i>
                                                            </span>
                                                            Editar
                                                            </button>
                                                            <button type="button" class="w3-button w3-red w3-small" onclick="deleteRecord11(\'' . $row["nome"] . '\')">
                                                            <span class="w3-button-icon">
                                                                <i class="fa fa-trash"></i>
                                                            </span>
                                                            Excluir
                                                            </button>
                                                        </td>';
                                                    echo '
                                                    </tr>
                                                    <script>
                                                        function addProduct11() {
                                                            // Redireciona para a página de adicionar produto
                                                            window.location.href = "../php/precos/massagens/adicionar_tabela.php";
                                                        }
                                                        function editRecord11(nome) {
                                                            // Redireciona para a página de edição do registro com a referência especificada
                                                            window.location.href = "../php/precos/massagens/edite_tabela.php?nome=" + nome;
                                                        }
                                                        
                                                        function deleteRecord11(nome) {
                                                            // Exibe uma caixa de diálogo de confirmação antes de excluir o registro
                                                            if (confirm("Tem certeza que deseja excluir este Serviço?")) {
                                                                // Redireciona para o arquivo que processa a exclusão do registro
                                                                window.location.href = "../php/precos/massagens/delet_tabela.php?nome=" + nome;
                                                            }
                                                        }
                                                    </script>';
                                                }
                                            } else {
                                                echo "<tr><td colspan='2'>Nenhum resultado encontrado.</td></tr>";
                                            }
                                        
                                            echo '
                                                <tr>
                                                    <td colspan="6">
                                                        <button type="button" class="w3-button w3-green w3-small" onclick="addProduct11()" style="margin-top: 40px; width:100%;">
                                                            <span class="w3-button-icon">
                                                                <i class="fa fa-plus"></i>
                                                            </span>
                                                            Adicionar Serviço
                                                        </button>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table><br>';
    
                            echo '
                                <!-- TABELA Tratamentos de Corpo -->
                                <table style="width:100%">
                                    <thead class="toggle" id="tratamentos_corpo">
                                        <tr>
                                            <th class="upercase" colspan="2">Tratamentos de Corpo</th>
                                        </tr>
                                    </thead>
                                    <tbody class="hide">
                                        <tr>
                                            <th> </th>
                                            <th>Preço</th>
                                            <th>Tempo</th>
                                            <th>Acções</th>
                                        </tr>';
                                        
                                            // Query para buscar os dados da tabela
                                            $sql = "SELECT * FROM tratamentos_corpo";
                                            $result = $conn->query($sql);
                                            
                                            // Verifica se a query retornou resultados
                                            if ($result->num_rows > 0) {
                                                // Exibe os dados em uma tabela
                                                while($row = $result->fetch_assoc()) {
                                                    echo "<tr>";
                                                    echo "<td>" . $row["nome"] . "</td>";
                                                    echo "<td class='w3-center'>" . $row["preco"] . "€ </td>";
                                                    echo "<td class='w3-center'>" . $row["tempo"] . " min</td>";
                                                    echo '<td class="w3-center">
                                                            <button type="button" class="w3-button w3-blue w3-small" onclick="editRecord12(\'' . $row["nome"] . '\')">
                                                            <span class="w3-button-icon">
                                                                <i class="fa fa-pencil"></i>
                                                            </span>
                                                            Editar
                                                            </button>
                                                            <button type="button" class="w3-button w3-red w3-small" onclick="deleteRecord12(\'' . $row["nome"] . '\')">
                                                            <span class="w3-button-icon">
                                                                <i class="fa fa-trash"></i>
                                                            </span>
                                                            Excluir
                                                            </button>
                                                        </td>';
                                                    echo '
                                                    </tr>
                                                    <script>
                                                        function addProduct12() {
                                                            // Redireciona para a página de adicionar produto
                                                            window.location.href = "../php/precos/tratamento corpo/adicionar_tabela.php";
                                                        }
                                                        function editRecord12(nome) {
                                                            // Redireciona para a página de edição do registro com a referência especificada
                                                            window.location.href = "../php/precos/tratamento corpo/edite_tabela.php?nome=" + nome;
                                                        }
                                                        
                                                        function deleteRecord12(nome) {
                                                            // Exibe uma caixa de diálogo de confirmação antes de excluir o registro
                                                            if (confirm("Tem certeza que deseja excluir este Serviço?")) {
                                                                // Redireciona para o arquivo que processa a exclusão do registro
                                                                window.location.href = "../php/precos/tratamento corpo/delet_tabela.php?nome=" + nome;
                                                            }
                                                        }
                                                    </script>';
                                                }
                                            } else {
                                                echo "<tr><td colspan='2'>Nenhum resultado encontrado.</td></tr>";
                                            }
                                        
                                            echo '
                                                <tr>
                                                    <td colspan="6">
                                                        <button type="button" class="w3-button w3-green w3-small" onclick="addProduct12()" style="margin-top: 40px; width:100%;">
                                                            <span class="w3-button-icon">
                                                                <i class="fa fa-plus"></i>
                                                            </span>
                                                            Adicionar Serviço
                                                        </button>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table><br>';


                    echo '
                        </div>
                    </div>';

                }else{
                    // Sem ser admin

                    echo '
                    <div class="w3-row" style="margin: 60px 0;">
                        <div class="w3-col s12 m12 l6">';

                        echo '
                            <!-- TABELA Epilação -->
                            <table style="width:100%">
                                <thead class="" id="epilacao">
                                    <tr>
                                        <th class="upercase" colspan="2">Epilação</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <th> </th>
                                        <th>Preço</th>
                                    </tr>';
                                    // Query para buscar os dados da tabela
                                    $sql = "SELECT * FROM epilacao";
                                    $result = $conn->query($sql);
                                    
                                    // Verifica se a query retornou resultados
                                    if ($result->num_rows > 0) {
                                        // Exibe os dados em uma tabela
                                        while($row = $result->fetch_assoc()) {
                                            echo "<tr>";
                                            echo "<td>" . $row["nome"] . "</td>";
                                            echo "<td class='w3-center'>" . $row["preco"] . "€ </td>";
                                            echo "</tr>";
                                        }
                                    } else {
                                        echo "<tr><td colspan='2'>Nenhum resultado encontrado.</td></tr>";
                                    }
                                    
                                echo '
                                </tbody>
                            </table><br>';

                            echo '
                            <!-- TABELA Microblanding -->
                            <table style="width:100%">
                                <thead class="" id="microblanding">
                                    <tr>
                                        <th class="upercase" colspan="2">Microblanding</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <th> </th>
                                        <th>Preço</th>
                                    </tr>';
                                    
                                        // Query para buscar os dados da tabela
                                        $sql = "SELECT * FROM microblanding";
                                        $result = $conn->query($sql);
                                        
                                        // Verifica se a query retornou resultados
                                        if ($result->num_rows > 0) {
                                            // Exibe os dados em uma tabela
                                            while($row = $result->fetch_assoc()) {
                                                echo "<tr>";
                                                echo "<td>" . $row["nome"] . "</td>";
                                                echo "<td class='w3-center'>" . $row["preco"] . "€ </td>";
                                                echo "</tr>";
                                            }
                                        } else {
                                            echo "<tr><td colspan='2'>Nenhum resultado encontrado.</td></tr>";
                                        }
                                    
                                echo '
                                </tbody>
                            </table><br>';

                            echo '
                            <!-- TABELA Unhas - Gel -->
                            <table style="width:100%">
                                <thead class="" id="unhas_gel">
                                    <tr>
                                        <th class="upercase" colspan="5">Unhas - Gel</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <th> </th>
                                        <th>S</th>
                                        <th>M</th>
                                        <th>L</th>
                                        <th>XL</th>
                                    </tr>';
                                    
                                        // Query para buscar os dados da tabela
                                        $sql = "SELECT * FROM gel";
                                        $result = $conn->query($sql);
                                        
                                        // Verifica se a query retornou resultados
                                        if ($result->num_rows > 0) {
                                            // Exibe os dados em uma tabela
                                            while($row = $result->fetch_assoc()) {
                                                echo "<tr>";
                                                echo "<td>" . $row["nome"] . "</td>";
                                                echo "<td class='w3-center'>" . $row["s"] . "€ </td>";
                                                echo "<td class='w3-center'>" . $row["m"] . "€ </td>";
                                                echo "<td class='w3-center'>" . $row["l"] . "€ </td>";
                                                echo "<td class='w3-center'>" . $row["xl"] . "€ </td>";
                                                echo "</tr>";
                                            }
                                            echo "<tr>";
                                            echo "<td colspan=5 class='w3-center'>Manutenção  apenas incluí  1 nail art simples</td>";
                                            echo "</tr>";
                                            echo "<tr>";
                                            echo "<td colspan=5 class='w3-center'>A partir das 4 semanas é aplicado o preço de aplicação.</td>";
                                            echo "</tr>";
        
                                        } else {
                                            echo "<tr><td colspan='2'>Nenhum resultado encontrado.</td></tr>";
                                        }

                                        echo '
                                </tbody>
                            </table><br>';

                            echo '
                            <!-- TABELA Unhas - Acrílico -->
                            <table style="width:100%">
                                <thead class="" id="unhas_acrilico">
                                    <tr>
                                        <th class="upercase" colspan="5">Unhas - Acrílico</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <th> </th>
                                        <th>S</th>
                                        <th>M</th>
                                        <th>L</th>
                                        <th>XL</th>
                                    </tr>';
                                    
                                        // Query para buscar os dados da tabela
                                        $sql = "SELECT * FROM acrilico";
                                        $result = $conn->query($sql);
                                        
                                        // Verifica se a query retornou resultados
                                        if ($result->num_rows > 0) {
                                            // Exibe os dados em uma tabela
                                            while($row = $result->fetch_assoc()) {
                                                echo "<tr>";
                                                echo "<td>" . $row["nome"] . "</td>";
                                                echo "<td class='w3-center'>" . $row["s"] . "€ </td>";
                                                echo "<td class='w3-center'>" . $row["m"] . "€ </td>";
                                                echo "<td class='w3-center'>" . $row["l"] . "€ </td>";
                                                echo "<td class='w3-center'>" . $row["xl"] . "€ </td>";
                                                echo "</tr>";
                                            }
                                            echo "<tr>";
                                            echo "<td colspan=5 class='w3-center'>Manutenção  apenas incluí  1 nail art simples</td>";
                                            echo "</tr>";
                                            echo "<tr>";
                                            echo "<td colspan=5 class='w3-center'>A partir das 4 semanas é aplicado o preço de aplicação.</td>";
                                            echo "</tr>";
                                        } else {
                                            echo "<tr><td colspan='2'>Nenhum resultado encontrado.</td></tr>";
                                        }

                                echo '
                                </tbody>
                            </table><br>';

                            echo '
                            <!-- TABELA Escolher Nome -->
                            <table style="width:100%">
                                <thead class="" id="escolher_nome">
                                    <tr>
                                        <th class="upercase" colspan="2">Outros</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <th> </th>
                                        <th>Preço</th>
                                    </tr>';
                                    
                                        // Query para buscar os dados da tabela
                                        $sql = "SELECT * FROM falta";
                                        $result = $conn->query($sql);
                                        
                                        // Verifica se a query retornou resultados
                                        if ($result->num_rows > 0) {
                                            // Exibe os dados em uma tabela
                                            while($row = $result->fetch_assoc()) {
                                                echo "<tr>";
                                                echo "<td>" . $row["nome"] . "</td>";
                                                echo "<td class='w3-center'>" . $row["preco"] . "€ </td>";
                                                echo "</tr>";
                                            }
                                        } else {
                                            echo "<tr><td colspan='2'>Nenhum resultado encontrado.</td></tr>";
                                        }

                                    echo '
                                </tbody>
                            </table><br>';

                            echo '
                            <!-- TABELA Nail Art -->
                            <table style="width:100%">
                                <thead class="" id="nail_art">
                                    <tr>
                                        <th class="upercase" colspan="2">Nail Art</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <th> </th>
                                        <th>Preço</th>
                                    </tr>';
                                    
                                        // Query para buscar os dados da tabela
                                        $sql = "SELECT * FROM nail_art";
                                        $result = $conn->query($sql);
                                        
                                        // Verifica se a query retornou resultados
                                        if ($result->num_rows > 0) {
                                            // Exibe os dados em uma tabela
                                            while($row = $result->fetch_assoc()) {
                                                echo "<tr>";
                                                echo "<td>" . $row["nome"] . "</td>";
                                                echo "<td class='w3-center'>" . $row["preco"] . "€ </td>";
                                                echo "</tr>";
                                            }
                                        } else {
                                            echo "<tr><td colspan='2'>Nenhum resultado encontrado.</td></tr>";
                                        }
                                        
                                    echo '
                                </tbody>
                            </table><br>
                        </div>
                        <div class="w3-col m6 l6">';

                        echo '
                            <!-- TABELA Threading -->
                            <table style="width:100%">
                                <thead class="" id="threading">
                                    <tr>
                                        <th class="upercase" colspan="2">Threading</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <th> </th>
                                        <th>Preço</th>
                                    </tr>';
                                    
                                        // Query para buscar os dados da tabela
                                        $sql = "SELECT * FROM threading";
                                        $result = $conn->query($sql);
                                        
                                        // Verifica se a query retornou resultados
                                        if ($result->num_rows > 0) {
                                            // Exibe os dados em uma tabela
                                            while($row = $result->fetch_assoc()) {
                                                echo "<tr>";
                                                echo "<td>" . $row["nome"] . "</td>";
                                                echo "<td class='w3-center'>" . $row["preco"] . "€ </td>";
                                                echo "</tr>";
                                            }
                                            echo "<tr>";
                                            echo "<td>*inclui sobrancelha, buço, maçãs rosto, queixo.</td>";
                                            echo "</tr>";
                                            
                                        } else {
                                            echo "<tr><td colspan='2'>Nenhum resultado encontrado.</td></tr>";
                                        }

                                    echo '
                                </tbody>
                            </table><br>';

                            echo '
                            <!-- TABELA Manicure / Pedicure -->
                            <table style="width:100%">
                                <thead class="" id="manicure_pedicure">
                                    <tr>
                                        <th class="upercase" colspan="2">Manicure / Pedicure</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <th> </th>
                                        <th>Preço</th>
                                    </tr>';
                                    
                                        // Query para buscar os dados da tabela
                                        $sql = "SELECT * FROM manicure_pedicure";
                                        $result = $conn->query($sql);
                                        
                                        // Verifica se a query retornou resultados
                                        if ($result->num_rows > 0) {
                                            // Exibe os dados em uma tabela
                                            while($row = $result->fetch_assoc()) {
                                                echo "<tr>";
                                                echo "<td>" . $row["nome"] . "</td>";
                                                echo "<td class='w3-center'>" . $row["preco"] . "€ </td>";
                                                echo "</tr>";
                                            }
                                        } else {
                                            echo "<tr><td colspan='2'>Nenhum resultado encontrado.</td></tr>";
                                        }

                                    echo '
                                </tbody>
                            </table><br>';
                            
                            echo '
                            <!-- TABELA Tratamentos de Rosto -->
                            <table style="width:100%">
                                <thead class="" id="tratamentos_rosto">
                                    <tr>
                                        <th class="upercase" colspan="2">Tratamentos de Rosto</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <th> </th>
                                        <th>Preço</th>
                                    </tr>';
                                    
                                        // Query para buscar os dados da tabela
                                        $sql = "SELECT * FROM tratamentos_rosto";
                                        $result = $conn->query($sql);
                                        
                                        // Verifica se a query retornou resultados
                                        if ($result->num_rows > 0) {
                                            // Exibe os dados em uma tabela
                                            while($row = $result->fetch_assoc()) {
                                                echo "<tr>";
                                                echo "<td>" . $row["nome"] . "</td>";
                                                echo "<td class='w3-center'>" . $row["preco"] . "€ </td>";
                                                echo "</tr>";
                                            }
                                        } else {
                                            echo "<tr><td colspan='2'>Nenhum resultado encontrado.</td></tr>";
                                        }

                                    echo '
                                </tbody>
                            </table><br>';

                            echo '
                            <!-- TABELA Maquilhagem -->
                            <table style="width:100%">
                                <thead class="" id="maquilhagem">
                                    <tr>
                                        <th class="upercase" colspan="2">Maquilhagem</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <th> </th>
                                        <th>Preço</th>
                                    </tr>';
                                    
                                        // Query para buscar os dados da tabela
                                        $sql = "SELECT * FROM maquilhagem";
                                        $result = $conn->query($sql);
                                        
                                        // Verifica se a query retornou resultados
                                        if ($result->num_rows > 0) {
                                            // Exibe os dados em uma tabela
                                            while($row = $result->fetch_assoc()) {
                                                echo "<tr>";
                                                echo "<td>" . $row["nome"] . "</td>";
                                                echo "<td class='w3-center'>" . $row["preco"] . "€ </td>";
                                                echo "</tr>";
                                            }
                                        } else {
                                            echo "<tr><td colspan='2'>Nenhum resultado encontrado.</td></tr>";
                                        }

                                    echo '
                                </tbody>
                            </table><br>';
                            
                            echo '
                            <!-- TABELA Massagens -->
                            <table style="width:100%">
                                <thead class="" id="massagens">
                                    <tr>
                                        <th class="upercase" colspan="2">Massagens</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <th> </th>
                                        <th>Preço</th>
                                    </tr>';
                                    
                                        // Query para buscar os dados da tabela
                                        $sql = "SELECT * FROM massagens";
                                        $result = $conn->query($sql);
                                        
                                        // Verifica se a query retornou resultados
                                        if ($result->num_rows > 0) {
                                            // Exibe os dados em uma tabela
                                            while($row = $result->fetch_assoc()) {
                                                echo "<tr>";
                                                echo "<td>" . $row["nome"] . "</td>";
                                                echo "<td class='w3-center'>" . $row["preco"] . "€ </td>";
                                                echo "</tr>";
                                            }
                                        } else {
                                            echo "<tr><td colspan='2'>Nenhum resultado encontrado.</td></tr>";
                                        }

                                    echo '
                                </tbody>
                            </table><br>';

                            echo '
                            <!-- TABELA Tratamentos de Corpo -->
                            <table style="width:100%">
                                <thead class="" id="tratamentos_corpo">
                                    <tr>
                                        <th class="upercase" colspan="2">Tratamentos de Corpo</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <th> </th>
                                        <th>Preço</th>
                                    </tr>';
                                    
                                        // Query para buscar os dados da tabela
                                        $sql = "SELECT * FROM tratamentos_corpo";
                                        $result = $conn->query($sql);
                                        
                                        // Verifica se a query retornou resultados
                                        if ($result->num_rows > 0) {
                                            // Exibe os dados em uma tabela
                                            while($row = $result->fetch_assoc()) {
                                                echo "<tr>";
                                                echo "<td>" . $row["nome"] . "</td>";
                                                echo "<td class='w3-center'>" . $row["preco"] . "€ </td>";
                                                echo "</tr>";
                                            }
                                        } else {
                                            echo "<tr><td colspan='2'>Nenhum resultado encontrado.</td></tr>";
                                        }

                                    echo '
                                </tbody>
                            </table><br>';

                            echo '
                        </div>
                    </div>';
                }
            ?>
            <!-- End page content -->
        </div>

        <!-- MOSTRAR OS FILTROS -->
        <script>
            $(document).ready(function() {
            // esconder todos os tbody
            $('.hide').hide();
        
            // adicionar evento de clique para cada thead
            $('thead.toggle').click(function() {
                // encontrar o tbody correspondente usando o próximo elemento
                var tbody = $(this).next('tbody');
        
                // alternar o estado de exibição do tbody
                tbody.slideToggle(200);
        
                // adicionar / remover a classe 'ativo' ao elemento clicado
                $(this).toggleClass('ativo');
            });
            });
        </script>
        <!-- SCRIPT BARRA LATERAL-->
        <script>
            // Accordion
            function myAccFunc() {
                var x = document.getElementById("demoAcc");
                if (x.className.indexOf("w3-show") == -1) {
                    x.className += " w3-show";
                } else {
                    x.className = x.className.replace(" w3-show", "");
                }
            }

            // Open and close sidebar
            function w3_open() {
                document.getElementById("mySidebar").style.display = "block";
                document.getElementById("myOverlay").style.display = "block";
            }

            function w3_close() {
                document.getElementById("mySidebar").style.display = "none";
                document.getElementById("myOverlay").style.display = "none";
            }
        </script>
        <!-- SCRIPT PREÇOS 0,00€ -->
        <script src="../js/tabela_precos.js"></script>
        <!-- LOG OUT -->
        <script>
            function confirmLogout() {
                if (confirm("Você tem certeza que deseja sair?")) {
                    window.location.href = "../php/LogOut.php";
                }
            }
        </script>
    </body>
</html>
