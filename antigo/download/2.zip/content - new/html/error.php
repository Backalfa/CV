<?php
if (isset($_GET['success']) && $_GET['success'] == 1) {
    echo '<script>alert("Registro bem-sucedido!");</script>';
}

session_start(); // Iniciar a sessão

// Para saber se está logado
if (!isset($_SESSION['user_email'])) {
    echo '<script>console.log("Sem Sessão Iniciada!")</script>';
}else{
    echo '<script>console.log("Bem vindo, '. $_SESSION['user_email'] . '!")</script>';
    echo '<script>console.log("O user é '. $_SESSION['is_admin'] . ' !")</script>';
    echo '<script>console.log("1 é admin, 0 é user")</script>';
}

?>

<!DOCTYPE html>
<html>
    <head>
        <title>Beatriz Miranda Oriflame</title>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <!-- FALTA ADICIONAR PARA A PESQUISA-->
        <link rel="website icon" type="png" href="../imgs/icontab.png" />
        <link rel="stylesheet" href="../css/base_main/base_index.css" />
        <link rel="stylesheet" href="../css/base_main/main_index.css" />
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto" />
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <style>
            *{
                font-family: 'Merriweather', serif;
            }
        </style>
    </head>
    <body class="w3-content" style="max-width: 1200px;">
        <!-- Sidebar/menu -->
        <nav class="w3-sidebar w3-bar-block w3-white w3-collapse w3-top" style="z-index: 3; width: 250px;" id="mySidebar">
            <div class="w3-container w3-display-container w3-padding-16">
                <i onclick="w3_close()" class="fa fa-remove w3-hide-large w3-button w3-display-topright"></i>
                <img src="../imgs/LOGO.jpg" style="width: 100%;" />
            </div>
            <a class="w3-bar-item w3-button w3-padding" href="Index.php">Início</a>
            <a class="w3-bar-item w3-button w3-padding" href="#">Sobre Nós</a>
            <?php
                // Para saber se tem sessão
                if (!isset($_SESSION['user_email'])) {
                    // Sem Sessão
                }else{
                    // Para sair da sessão
                    echo '<a class="w3-bar-item w3-button w3-padding" href="tabela_precos.php">Serviços</a>';
                }
            ?>
            <a class="w3-bar-item w3-button w3-padding" href="#Contact">Contacte-nos</a>
            <a onclick="myAccFunc()" href="javascript:void(0)" class="w3-button w3-block w3-white w3-left-align" id="myBtn">
                Catálogo <i class="fa fa-caret-down"></i>
            </a>
            <div id="demoAcc" class="w3-bar-block w3-hide w3-padding-large w3-medium w3-show">
                <a href="catalogo.php?categoria=" class="w3-bar-item w3-button">Catálogo</a>
                <a href="https://pt.oriflame.com/products/digital-catalogue-current?PageNumber=1" class="w3-bar-item w3-button">Catálogo - Oriflame</a>
            </div>
            <a href="https://pt.oriflame.com/catalogue?cataloguecode=Norrsken%2F2023-norrsken-spring" class="w3-bar-item w3-button w3-padding" target="_blank">NORRSKEN - Jóias</a>
            <a href="https://pt.oriflame.com/catalogue?cataloguecode=FlyerC04&PageNumber=1" class="w3-bar-item w3-button w3-padding" target="_blank">Oportunidades</a>
        </nav>

        <!-- Top menu on small screens -->
        <header class="w3-bar w3-top w3-hide-large w3-black w3-xlarge">
            <div class="w3-bar-item w3-padding-24 w3-wide"></div>
            <a href="javascript:void(0)" class="w3-bar-item w3-button w3-padding-24 w3-right" onclick="w3_open()"><i class="fa fa-bars"></i></a>
        </header>

        <!-- Overlay effect when opening sidebar on small screens -->
        <div class="w3-overlay w3-hide-large" onclick="w3_close()" style="cursor: pointer;" title="close side menu" id="myOverlay"></div>

        <!-- !PAGE CONTENT! -->
        <div class="w3-main" style="margin-left: 250px;">
            <!-- Push down content on small screens -->
            <div class="w3-hide-large" style="margin-top: 83px;"></div>

            <!-- TOP HEADER / NAV BAR -->
            <header class="w3-container w3-xlarge">
                <p class="w3-right gap">
                    <script src="https://cdn.lordicon.com/bhenfmcm.js"></script>
                    <span style="position: relative; color: red;">
                    <!-- Conta Carrinho -->
                    <?php
                        if (isset($_SESSION["carrinho"])) {
                            if (count($_SESSION["carrinho"]) != 0) {
                                echo count($_SESSION["carrinho"]);
                            } else {
                                echo '';
                            }
                        } else {
                            echo '';
                        }
                        ?>
                    </span>
                    <?php
                    // Para saber se tem sessão
                    if (!isset($_SESSION['user_email'])) {
                        // Para fazer Log In
                        echo '<a class="nav-link" href="../login.html">Log In</a>';
                    } else {
                        // Para sair da sessão
                        echo '
                            <a href="main_carrinho.php" ><lord-icon
                                src="https://cdn.lordicon.com/lqsduwhb.json"
                                trigger="hover"
                                colors="primary:#000000"
                                style="width:40px;height:40px">
                            </lord-icon></a>
                            <a class="nav-link" href="#" onclick="confirmLogout()">Sair</a>';
                    }
                    ?>
                </p>
            </header>

            <!-- Image header -->
            <div class="w3-display-container w3-container">
                <img class="w3-hide-small" src="../imgs/404error.png" alt="logo_pagina_centro" style="width: 100%;" />
                <img class="w3-hide-large w3-hide-medium" src="../imgs/404error.png" alt="logo_pagina_centro" style="width: 100%;" />
                <div class="w3-display-topleft w3-text-black" style="padding: 24px 48px;">
                    <h1 class="w3-jumbo w3-hide-small">Página não encontrada!</h1>
                    <h1 class="w3-hide-large w3-hide-medium">Página não encontrada!</h1>
                </div>
            </div>

            <!-- Main Content -->
            
            <!-- End page content -->
        </div>

        
        <!-- Accordion -->
        <script>
            function myAccFunc() {
                var x = document.getElementById("demoAcc");
                if (x.className.indexOf("w3-show") == -1) {
                    x.className += " w3-show";
                } else {
                    x.className = x.className.replace(" w3-show", "");
                }
            }

            // Open and close sidebar
            function w3_open() {
                document.getElementById("mySidebar").style.display = "block";
                document.getElementById("myOverlay").style.display = "block";
            }

            function w3_close() {
                document.getElementById("mySidebar").style.display = "none";
                document.getElementById("myOverlay").style.display = "none";
            }
        </script>
        <!-- LOG OUT -->
        <script>
            function confirmLogout() {
                if (confirm("Você tem certeza que deseja sair?")) {
                    window.location.href = "../php/LogOut.php";
                }
            }
        </script>
        <!-- Slides PC -->
        <script>
            var myIndex = 0;
            carousel();

            function carousel() {
            var i;
            var x = document.getElementsByClassName("mySlides");
            for (i = 0; i < x.length; i++) {
                x[i].style.display = "none";  
            }
            myIndex++;
            if (myIndex > x.length) {myIndex = 1}    
            x[myIndex-1].style.display = "block";  
            setTimeout(carousel, 4000); // Change image every 4 seconds
            }
        </script>
        <!-- Slides Responsivo -->
        <script>
            var slideIndex = 1;
            showDivs(slideIndex);

            function plusDivs(n) {
                showDivs(slideIndex += n);
            }

            function showDivs(n) {
                var i;
                var x = document.getElementsByClassName("mySlidesSmall");
                if (n > x.length) {slideIndex = 1}
                if (n < 1) {slideIndex = x.length}
                for (i = 0; i < x.length; i++) {
                    x[i].style.display = "none";  
                }
                x[slideIndex-1].style.display = "block";  
            }
        </script>
        <!-- Admin Contacts -->
        <script>
            function myFunction(id) {
                var x = document.getElementById(id);

                if (x.className.indexOf("w3-show") == -1) {
                    x.className += " w3-show";
                } else { 
                    x.className = x.className.replace(" w3-show", "");
                }
            }
        </script>
    </body>
</html>
